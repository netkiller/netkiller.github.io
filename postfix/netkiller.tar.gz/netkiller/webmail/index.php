<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body>
<?
if(@$HTTP_POST_VARS['submit']=="�ĳ�"){
$mailfrom=$HTTP_POST_VARS['mailfrom'];
$sendto=$HTTP_POST_VARS['sendto'];
$subject=$HTTP_POST_VARS['subject'];
$content=$HTTP_POST_VARS['content'];
//$mailfrom="From:".$mailfrom."\r\n";
$mailfrom="From:".$mailfrom."\nReply-To: ".$mailfrom."\nX-Mailer: PHP/" . phpversion()."\r\n";
$mail=mail($sendto,$subject,$content,$mailfrom);
if($mail){
echo "�ʼ��ɹ��ĳ�";
}
else{
echo "�ʼ��ĳ�ʧ��";
}
}
?> 
<form name="form1" method="post" action="<? echo $HTTP_SERVER_VARS['PHP_SELF'];?>">
  <table align="center">
    <tr> 
      <td align="center">&nbsp;</td>
</tr>
<tr> 
      <td align="left">������ 
<input name="mailfrom" type="text" id="mailfrom">
</td>
</tr>
<tr> 
      <td align="left">������ 
        <input name="sendto" type="text" id="sendto" value="netkiller@9812.net">
</td>
</tr>
<tr> 
      <td align="left">������
<input name="subject" type="text" id="subject">
</td>
</tr>
<tr> 
      <td align="center" valign="baseline">
<p>�ȡ���</p>
        <p> 
          <textarea name="content" cols="60" rows="10" id="content"></textarea>
        </p></td>
</tr>
<tr>
<td align="center"> 
<input name="submit" type="submit" id="submit" value="�ĳ�">
        &nbsp; 
        <input name="reset" type="reset" id="reset" value="����">
</td>
</tr>
</table>
</form>

</body>
</html>
