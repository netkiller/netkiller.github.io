<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body>
<table width="100%" border="3" cellspacing="0" cellpadding="5" bgcolor="E0F0FF" class="t02" align="center" bordercolor="4FA7FF" height="0%">
  <tr valign="top"> 
    <td colspan="2" height="52"> <table width="100%" border="1" cellspacing="0" cellpadding="0" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF">
        <tr> 
          <td>
<?


		for($i=0;$i<=count($ldapTemplates["Outlook"]["Attribute"]);$i++){
				echo $ldapTemplates["Outlook"]["Attribute"][$i];
				echo $ldapTemplates["Outlook"]["Value"][$i];echo "<br>";
		}
		
		for($i=0;$i<count($ldapTemplates["ProFTPD"]["Attribute"]);$i++){
				echo $i;
				echo $ldapTemplates["ProFTPD"]["Attribute"][$i];
				echo $ldapTemplates["ProFTPD"]["Value"][$i];echo "<br>";
		}
		for($i=0;$i<count($ldapTemplates["Qmail"]["Attribute"]);$i++){
				echo $i;
				echo $ldapTemplates["Qmail"]["Attribute"][$i];
				echo $ldapTemplates["Qmail"]["Value"][$i];echo "<br>";
		}		

?>		  
		  </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
