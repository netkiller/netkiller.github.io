<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?
if (($Ok) AND ($photofile)) {
  copy($photofile, "chen.jpg");
  unlink($photofile);

  //header("Location: ../bbs/bbsdefault.php?id=$id\n");
  exit;
}
?> 
<form enctype="multipart/form-data" method="POST" action="<? echo $PHP_SELF?>">
  <table width="90%" border="0" align="center">
    <tr> 
      <td bgcolor="#333399" height="17"><font color="#FFFFFF">��ѡ����Ҫ�ϴ�����Ƭ�� ( 200x150��JPG��ʽ����Ƭ�ļ���С������80KB 
        )</font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td> 
        <div align="center">
          <input type="file" name="photofile">
          <input type="hidden" name="MAX_FILE_SIZE" value="100000">
          <input type="submit" name="Ok" value="��ʼ�ϴ�">
          <input type=hidden name=id value="<? echo $id; ?>">
        </div>
      </td>
    </tr>
    <tr> 
      <td bgcolor="#333399" height="19">&nbsp;</td>
    </tr>
  </table>
  </form>
<div class=wdBlack align=center></div>
<br>
<p>&nbsp;</p>
</body>
</html>
