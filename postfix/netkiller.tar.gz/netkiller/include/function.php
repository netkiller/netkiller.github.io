<script language=javascript>
function Openwin(url)
{
	window.open(url,'blank','toolbar=0,scrollbars=1');
}
function Messagebox(url,h,w)
{
	window.open(url,'blank','toolbar=0,scrollbars=1,height='+h+' width='+w);
}
function MessageDelete(dn)
{
	if(window.confirm("ȷ���Ƿ�ɾ����")){
		//location.href = 'ldapdelete.php?dn='+dn;
		this.ldap.action="ldap.php?dn="+dn;
		this.ldap.submit();
	}
	//return false;
}
function OpenType(pfn)
{
	if(window.confirm("���������Ա༭���Դ�\n������������Դ򿪣�"))
		fn='editcode.php?filename='+pfn;
	else
		fn=pfn;
	Openwin(fn);
}
function ldapModify(dn){
	//this.ldap.target="ldapmodify";
	this.ldap.action="ldapmodify.php?dn="+dn;
	this.ldap.submit();	
}
function ldapAddForm(isbind){
	this.ldap.action="ldapadd.php";
	this.ldap.submit();	
}
function ldapAddAttribute(){
	if(this.ldapadd.Attribute.value == '')
		alert("����û��д��");
	else if(this.ldapadd.Value.value == ''){
		alert("����ֵû��д��");
	}else{
		this.ldapadd.LDAPAction.value="AddAttributeAndValue";
		this.ldapadd.submit();	
	}
}
function ldapDelAttribute(key){
	this.ldapadd.LDAPAction.value="DelAttributeAndValue";
	this.ldapadd.Attribute.value = key;
	this.ldapadd.submit();	
}
function ldapAdd(){
	this.ldapadd.action="ldapadd.php";
	this.ldapadd.LDAPAction.value="Add";
	this.ldapadd.submit();	
}
function ldapAddBack(){
	this.ldapadd.action="ldap.php";
//	this.ldapadd.LDAPAction.value="Add";
	this.ldapadd.submit();	
}
</script>
<?php
$VERSION="<a href=http://www.kdeopen.com style=color:white><font face=System>Site Manager 2.1.0 Netkiller chen</font></a>";
function PutTextFile($filename){
	if(file_exists($filename)){
		$myfile = file($filename);
		for($num=0;$num<count($myfile);$num++)
			echo '<p>'.$myfile[$num].'</p>';
 		}else echo "The file does not exist ��";
}
function ShowTextFile($filename){
		$fp=fopen ($filename,"r"); 
	    	$buffers=fread ($fp,filesize($filename)); 
		//while(!feof($fp)){
		//$buffers = fgets($fp,filesize($filename));   		//echo $buffers.'<br>';
		print($buffers);
		fclose($fp);
}
function ShowCodeFile($filename){
	if(file_exists($filename)){
		$myfile = file($filename);
		echo "<pre>";
		for($num=0;$num<count($myfile);$num++)
			echo AnalyseCodes($myfile[$num])."<br>";
 		}else echo "The file does not exist ��";
		echo "</pre>";
}
function AnalyseCodes($code){
	$code=str_replace("<", "&lt;", $code);
	$code=str_replace(">", "&gt;", $code);	
	//switch($code){
	//  case "":
	return $code;
}
//------------------------------------------------------------------
function filelinktype($filepath,$filename){
	$ext=strtolower(strrchr($filename,'.'));
	switch($ext){
	  case ".jpg":
	  case ".gif":
  	  case ".bmp":
	  case ".png":	 
	  case ".tif":
	  case ".swf":
	  case ".mp3":
	  case ".rm": 
	  case ".ram":
	  case ".wav":
	  case ".mid":
	  case ".midi":
	  case ".au":
	  case ".asf":
	    $linkstr="<a href=javascript:Openwin('$filepath/$filename')>$filename</a>";
	    break;
	  case ".txt":
	  case ".css": 
	  case ".htm":
	  case ".html":
	  case ".shtml":
	  case ".phtml":
  	  case ".php":
  	  case ".php3":
	  case ".dwt":
	  case ".js":
	  case ".jsp":
	  case ".inc":
	  case ".xml":
	  case ".wml":
  	  case ".cgi":
  	  case ".pl":
  	  case ".sh":
	  	$linkstr="<a href=javascript:Openwin('editcode.php?filename=$filepath/$filename')>$filename</a>";
	    break;
	  case ".zip":
	  case ".tgz":
	  case ".tar":
	  case ".gz":
	  case ".rar":
	  case ".exe":
	  case ".com":
  	  case ".iso":
  	  case ".mdb":
	  	$linkstr="<a href=$filepath/$filename>$filename</a>";
    	break;
	  default:
	  	$linkstr="<a href=javascript:OpenType('$filepath/$filename')>$filename</a>";
    	break;

	};
	return $linkstr;
}
//------------------------------------------------------------------
function miniature($filepath,$filename){
	$ext=strtolower(strrchr($filename,'.'));
	switch($ext){
	  case ".jpg":
	  case ".gif":
  	  case ".bmp":
	  case ".png":	 
	  case ".tif":
	  case ".swf":
	  case ".ico":
	  case ".cur":
	  case ".ani":
	  case ".psd":
	    $icon="<img src='$filepath/$filename' width=46 height=46>";
	    break;	  
	  case ".htm":
	  case ".html":
	  	$icon="<font face=Wingdings size=6>]</font>";
	    break;
	  case ".txt":
	  case ".css":
  	  case ".htt":
	  case ".shtml":
	  case ".phtml":
	  case ".asp":
	  case ".asa":
  	  case ".php":
  	  case ".php3":
	  case ".dwt":
	  case ".js":
	  case ".jsp":
	  case ".java":
	  case ".inc":
	  case ".xml":
	  case ".wml":
  	  case ".cgi":
  	  case ".pl":
	  case ".c":
	  case ".h":
	  case ".cpp":
	  case ".rc":
	  case ".prg":
	  	$icon="<font face=Wingdings size=6>@</font>";
	    break;
	  case ".bat":
	  case ".exe":
	  case ".com":
	  case ".class":
	  case ".sh":
	  case ".o":
	  	$icon="<font face='Wingdings 2' size=6>4</font>";
    	break;	
	  case ".sys":
	  case ".dll":
	  case ".bin":
  	  case ".ini":
 	  case ".drv":
	  case ".inf":
	  case ".cfg":
	  case ".lib":
	  case ".nfo":
	  	$icon="<font face=Wingdings size=6>:</font>";
	    break;		
	  case ".log":
	  case ".tmp":
	  	$icon="<font face='Wingdings 2' size=6>3</font>";
    	break;		  
	  case ".zip":
  	  case ".z":
	  case ".tgz":
	  case ".tar":
	  case ".gz":
	  case ".rar":
	  case ".cab":
	  case ".arj":
	  case ".lha":
	  	$icon="<font face='Wingdings 2' size=6>1</font>";
	    break;	  
  	  case ".iso":
  	  	$icon="<font face='Wingdings 2' size=6>8</font>";
    	break;	
  	  case ".mdb":
  	  case ".xls":
	  case ".dbf":
	  	$icon="<font face=Wingdings size=6>4</font>";
	    break;
	  case ".pdf":
	  	$icon="<font face=Wingdings size=6>&</font>";
	    break; 
	  case ".mp3":
	  case ".wav":
	  case ".mid":
	  case ".midi":
	    $icon="<font face='Wingdings 2' size=6>9</font>";
	    break;	  
	  case ".rm": 
	  case ".ram":
	  case ".avi":
	  case ".au":
	  case ".asf":
	  case ".mov":
	  case ".mpeg":
	    $icon="<font face='Wingdings' size=6>></font>";
	    break;	
	  default:
	  	$icon="<font face=Webdings size=6>s</font>";
    	break;

	};
	return $icon;
}

function DirIco($filename){
	if($filename == '..')
		return "<font face='Wingdings 3' size=6>X</font>";
		if($filename == '.')return "<font face='Wingdings 3' size=6>Q</font>";
 	else 
		return "<font face=Wingdings size=5>1</font>";
}
?>