<?
//===========================================
//	Ftp Server
//===========================================
$ftp_host 		= "host";
$ftp_user		= "user";
$ftp_pass		= "psswd";

$username=	"User		 ";
$password=	"Password	 ";
$confirm=	"Confirm password";
$realname=	"Reamname	 ";
$security_mail=	"Security Mail	 ";
$virtualdomain=	"VirtualDomain";
$url =		"URL		 ";
$number =	"Number";
$host =		"Host";
$operate =	"Operate";
$edit = 	"Edit";
$delete = 	"Delete";
$addhost = 	"Add Host";
$adddomain =	"Add VirtualDomain";
$currentdomain ="$Current Domain";
$modify =	"Modify";
$logout =	"Logout";
$defaulthost =	"Default Host";
//===========================================
//	Button
//===========================================
$login_button 	= " Login ";
?>