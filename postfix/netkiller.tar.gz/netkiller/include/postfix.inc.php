<?php
// Postfix Admin
#require("../include/mysql.inc.php");
/*
// ===================== PostfixAdmin ========================
require("$inc_path/postfix.inc.php");
$pfx=new PostfixAdmin;

$pfx->appname		= "Postfix Admin";
$pfx->appshortname	= "Postfix Admin";
$pfx->server		= "localhost";
$pfx->user			= "PostfixAdmin";
$pfx->passwd			= "saovRPOzEzmL";
//$pfx->user			= "root";
//$pfx->passwd		= "";

$pfx->database		= "postfix";
$pfx->postfix_mailbox_table	= "postfix_users";
$pfx->postfix_mailbox_field	= "user, name, passwd, domain, uid, gid, home, maildir, imapok, quota";
$pfx->postfix_transport_table	= "postfix_transport";
$pfx->postfix_transport_field	= "domain, transport";
$pfx->postfix_aliases_table	= "postfix_aliases";	
$pfx->postfix_aliases_field	= "alias, rcpt,";
// auth: crypt md5 backend
$pfx->auth="crypt";
//$pfx->auth="md5";
//$pfx->auth="backend";
*/
	
class PostfixAdmin {

	var $isConnect 	= false;
	var $isLogin	= false;
	var $error   	= 0;
	var $isSuccess 	= false;
	var $auth		= "";
	
	var $postfix_mailbox_table		= "";
	var $postfix_mailbox_field		= "";
	var $postfix_transport_table	= "";
	var $postfix_transport_field	= "";
	var $postfix_aliases_table		= "";	
	var $postfix_aliases_field		= "";
	
	var $database	= "postfix";
	var $server 	= "localhost";
	var $user		= "";
	var $passwd		= "";

//-------------------------------------------------------------------------------------
	function Connect(){
		global $dbc;
		$dbc->database		= $this->database;
		$dbc->server		= $this->server;
		$dbc->user			= $this->user;
		$dbc->password		= $this->passwd;
		$dbc->appname		= "Postfix Admin";
		$dbc->appshortname	= "Postfix Admin";
		$dbc->connect();
	}
	function getPassword($pass){
		$result = "";
		switch ($this->auth){
			case "crypt":
				$result = "encrypt('$pass')";
				break;
			case "md5":
				$result = "md5('$pass')";
				break;			
			case "backend":
				$result = "password('$pass')";
				break;			
			default:
				$result = $pass;
				break;
		}
		return $result;
	}
	
	function getUseridField(){
		$user_field = strtok($this->postfix_mailbox_field ,",");
		return $user_field;
	}
	
	function getDomainField(){
		$domain_field = strtok($this->postfix_transport_field ,",");
		return $domain_field;
	}

	function check_user($user){
		global $dbc;
		$user_field = strtok($this->postfix_mailbox_field ,",");
		$SQL="SELECT  $this->postfix_mailbox_field FROM $this->postfix_mailbox_table where $user_field ='".$user."'";
		//echo $SQL;
		$resultss=$dbc->query($SQL);
		$count=mysql_numrows($resultss);
		if ($count>=1){
			return true;
			//����
		}else{
			return false;
			//������			
		}
	}
	
/*
�����û���
user 	: chen@gdfz.com
name	: chen
passwd 	: encrypt('your-passwd')
domain	: gdfz.com
maildir	: gdfz.com/chen/Maildir/
quota	: nKB (5000000 = 5MB)
*/	
function register($user,$name,$passwd,$domain,$quota) {
    // ע������
    global $dbc;
	$passwd 	= $this->getPassword($passwd);
	$uid 		= 1000;
	$gid 		= 1000;
	$home 		= "/var/mail";
	$maildir	= $domain."/".$name."/Maildir/";
	$imapok		= 1;
	
	$this->Connect();
   	if(!isset($user)){
		$check_result="<font face=Wingdings size=5 color=red>L</font>  <font color=red>����û�б���ֵ</font>";
		echo $check_result;
			return;
	}
	if($this->check_user($user)){
		echo "<font face=Wingdings size=5 color=red>L</font>  <font color=red>�û��Ѿ����ڣ�<a href='register.php'>����</a></font>";
		return;
	}
	$SQL="INSERT INTO $this->postfix_mailbox_table ($this->postfix_mailbox_field) values('$user','$name',$passwd,'$domain',$uid, $gid,'$home','$maildir','$imapok','$quota')";
	$dbc->query($SQL);
	echo "<font face=Wingdings size=5 color=red>J</font>  <font color=red>��ϲ��!ע��ɹ���<a href='http://www.gdfz.com/mail/'>��¼����</a></font>";
	@mail($user,"��ϲ��ע��ɹ�","http://www.gdfz.com","From:Webmaster<webmaster@gdfz.com>");
}
function getPostmasterQuota($user){
	global $dbc;
	$this->Connect();
	$user_field =  $this->getUseridField();
	$SQL = "Select quota from $this->postfix_mailbox_table where $user_field = '$user'";
	$result=$dbc->query($SQL);
	$count=mysql_numrows($result);
	if($count>0){
//			for ($i=0;$i<$count;$i++){
		//$quota=$dbc->fetch_row($result);
		$quota=$dbc->fetch_row($result);
//			}
	}
	return $quota[0];
}
function getTotleDomainUserQuota($domain){
	global $dbc;
	$this->Connect();
	$user_field =  $this->getUseridField();
	$SQL = "Select sum(quota) from $this->postfix_mailbox_table where domain='$domain'";
	$result=$dbc->query($SQL);
	$count=mysql_numrows($result);
	if($count>0){
		$quota=$dbc->fetch_row($result);
	}else{
		return 0;
	}
	return $quota[0];
}
function addMailbox($user,$name,$passwd,$domain,$quota){
	global $dbc;
	$this->Connect();
	if(getPostmasterQuota($user) <= getTotleDomainUserQuota($domain)){
		$this->register($user,$name,$passwd,$domain,$quota);
		$this->isSuccess 	= true;
	}else{
		$this->isSuccess 	= false;
	}
	return $this->isSuccess;
}
	function getDomainList(){
		global $dbc;
		$this->Connect();
		$domain_field = $this->getDomainField();
		$SQL = "Select $domain_field from $this->postfix_transport_table";
		$result=$dbc->query($SQL);
		$count=mysql_numrows($result);
		if($count>0){
			for ($i=0;$i<$count;$i++){
				$dl=$dbc->fetch_array($result);
				$domainlist[$i] = $dl["domain"];
				//echo $dl["domain"];
			}
		}else{
			return -1;
		}
		return $domainlist;
	}

	function getDomainUser($domain){
			global $dbc;
			$this->Connect();
			$domain_field = $this->getDomainField();
			$SQL = "Select * from $this->postfix_mailbox_table where $domain_field='$domain'";
			$result=$dbc->query($SQL);
			$count=mysql_numrows($result);
			if($count>0){
				for ($i=0;$i<$count;$i++){
					$du=$dbc->fetch_array($result);
					$domainuser[$i][0] = $du["user"];
					$domainuser[$i][1] = $du["name"];
					$domainuser[$i][2] = $du["quota"];
				}
			}else{
				return null;
			}
			return $domainuser;
	}
	
	function check_domain($domain){
		global $dbc;
		$domain_field = $this->getDomainField();
		$SQL="SELECT  $this->postfix_transport_field FROM $this->postfix_transport_table where $domain_field ='".$domain."'";
		$result=$dbc->query($SQL);
		$count=mysql_numrows($result);
		if ($count>=1){
			return true;
			//����
		}else{
			return false;
			//������			
		}
	}	
	
	function addDomain($domain,$transport,$desc,$begin,$end){
		global $dbc;
		$this->Connect();
		if($this->check_domain($domain)){
			echo "�������Ѿ����ڣ�";
		}else{
			$domain_field = $this->getDomainField();
			$sql="Insert into $this->postfix_transport_table( $this->postfix_transport_field,description,begin_date,end_date) values('$domain','$transport','$desc','$begin','$end')";
			$dbc->query($sql);
		}
	}
	function delDomain($domain){
		global $dbc;
		$this->Connect();
		$domain_field = $this->getDomainField();
		$sql="Delete From $this->postfix_transport_table where $domain_field = '$domain'";
		$dbc->query($sql);
	}
	function chDomain($domain,$newdomain,$desc,$begin,$end){
		global $dbc;
		$this->Connect();
		$domain_field = $this->getDomainField();
		$sql="Update $this->postfix_transport_table set domain='$newdomain' ,description='$desc',begin_date='$begin',end_date='$end' where $domain_field = '$domain'";
		$dbc->query($sql);
		
	}
	function delDomainUser($user){
		global $dbc;
		$this->Connect();
		$user_field = $this->getUseridField();
		$sql="Delete From $this->postfix_mailbox_table where $user_field='$user'";
		$dbc->query($sql);
	}
	function resetPasswd($user,$passwd){
		global $dbc;
		$this->Connect();
		$user_field = $this->getUseridField();
		$passwd=$this->getPassword($passwd);
		$sql="Update $this->postfix_mailbox_table set passwd=$passwd where $user_field='$user'";
		$dbc->query($sql);
	}
	function getDomainDetails($domain){
		global $dbc;
		$this->Connect();
		$domain_field = $this->getDomainField();
		$SQL="SELECT * FROM $this->postfix_transport_table where $domain_field ='".$domain."'";
		$result=$dbc->query($SQL);
		$count=mysql_numrows($result);
		if($count>0){
			for ($i=0;$i<$count;$i++){
				$dl=$dbc->fetch_array($result);
				//$domainlist[0] = $dl["domain"];
				//$domainlist[0] = $dl["domain"];
				//echo $dl["domain"];
			}
		}
		return $dl;		
	}
	function getDomainUserDetails($user){
		global $dbc;
		$this->Connect();
		//$domain_field = $this->getDomainField();
		$user_field = $this->getUseridField();
		$SQL = "Select * from $this->postfix_mailbox_table where $user_field='$user'";
		$result=$dbc->query($SQL);
		$count=mysql_numrows($result);
		if($count>0){
			for ($i=0;$i<$count;$i++){
				$du=$dbc->fetch_array($result);
				/*
				$domainuser[$i][0] = $du["user"];
				$domainuser[$i][1] = $du["name"];
				$domainuser[$i][2] = $du["quota"];
				*/
			}
		}else{
			return null;
		}
		return $du;
	}
	function chDomainUserDetails($user,$nuser,$name,$quota){
		global $dbc;
		$this->Connect();
		$user_field = $this->getUseridField();
		$SQL="Update $this->postfix_mailbox_table set user='$nuser',name='$name',quota='$quota' where $user_field ='".$user."'";
		$result=$dbc->query($SQL);
	}
function Authentication($user,$passwd){

}
function getDebug(){
	
}

function analyzer_error($err_list,$err) {
	$result = "";
	switch ($err){
		case "001":
    		$result = $err_list["Connect"];
		    break;
		case "002":
			$result = $err_list["Login"];
			break;			
		default:
		    $result = "Error!";
		    break;
	}
//	echo "> $err | $result";echo $ftpConnectError;echo "<BR>";
	return $result;
}
//////////////////////////////////////////////////////////////////////////////////
//	var $member_mailbox_table = "mailbox";
	function addMemberMail($uid,$mail,$isfree){
		global $dbc;
		$this->Connect();
		$sql="Insert into mailbox(uid,mail,isfree,begin_date,end_date) values($uid,'$mail','$isfree',now(),now())";
		$dbc->query($sql);
	}
	function getMemberMailCount($uid){
		global $dbc;
		$this->Connect();
		$sql="Select count(*) from mailbox where uid = $uid";
		$result=$dbc->query($sql);
		$count=mysql_numrows($result);
		if($count>0){
			$mc=$dbc->fetch_row($result);
		}else{
			return 0;
		}
		return $mc[0];
	}
	function getMemberMail($uid){
		global $dbc;
		$this->Connect();
		$sql="Select * from mailbox where uid = $uid";
		$result=$dbc->query($sql);
		$count=mysql_numrows($result);
		if($count>0){
			$maillist=$dbc->fetch_row($result);
		}else{
			return 0;
		}
		return $maillist;
	}

}
//////////////////////////////////////////////////////////////////////////////////

?>
