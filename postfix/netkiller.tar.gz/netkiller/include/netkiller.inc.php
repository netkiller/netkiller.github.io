<?
//***************����ַ����Ƿ�Ϊ��******************

function CheckEmptyString($C_char)
{ 
	if (!is_string($C_char)) return false;         
	if (empty($C_char)) return false;            
	if ($C_char=='') return false;                
	return true; 
}

function CheckEmailAddr($C_mailaddr)

{ 
if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$",$C_mailaddr))   
   { 
       return false; 
   } 
   return true; 
} 

function CheckPassword($C_passwd)   
{ 
   if (!$this->CheckLengthBetween($C_passwd, 4, 20)) return false; 
   if (!ereg("^[_a-zA-Z0-9]*$", $C_passwd)) return false; 
   return true; 
} 

function CheckLengthBetween($C_cahr, $I_len1, $I_len2=100)   

{ 
   $C_cahr = trim($C_cahr); 
   if (strlen($C_cahr) < $I_len1) return false; 
   if (strlen($C_cahr) > $I_len2) return false; 
   return true; 
} 

function TextFilter($str){
		$str = chop($str);
		$str = nl2br(htmlspecialchars( $str ));
		return $str;
}
?>