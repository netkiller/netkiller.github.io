<?
// ���ݿ��� for MySQL
class MySQL_Class {
  var $database = "";

  var $link_id  = 0;
  var $query_id = 0;
  var $record   = array();

  var $errdesc    = "";
  var $errno   = 0;
  var $reporterror = 1;

  var $server   = "localhost";
  var $user     = "root";
  var $password = "";
  var $appname  = "";
  var $appshortname = "";

?>