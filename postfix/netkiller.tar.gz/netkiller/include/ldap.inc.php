<?
class ldap{

	var	$gbAtts = array(
			"cn",
			"sn",
			"description"
		);
			
	var $ldapTemplates = array(
        "person" => array(
				"Attribute" => array(
					"objectClass",
			  		"cn",
					"sn"
					),
				"Value" => array(
					"person",
					"",
					""
				)
		),
		
		"organizationalUnit" => array(
				"Attribute" => array(
					"objectClass",
			  		"ou"
					),
				"Value" => array(
					"organizationalUnit",
					""
				)
		),
		
        "Outlook" => array(
			"Attribute" => array(
				"objectclass",		
				"cn", 				//Name
				"givenname",		//First name
				"sn",				//Last Name
				"mail", 			//Email address
			
				"homephone",		//Home phone number  
				"mobile",			//Home cellphone number
				"homepostaladdress",//Home postal address

				"telephoneNumber",	//Business phone number
				"facsimiletelephonenumber",//Business fax number
				"otherfacsimiletelephonenumber",	//Home fax number
				"otherpager",		//Business pager number can be "pager" too? 
				"organizationname",	//Company name
				"department",		//Business department
				"physicaldeliveryofficename",//Location of office at work			
				"title",			//Job title
				"c",				//Business country
				"st",				//Business state/province
				"l",				//Business city
				"postaladdress",	//Business postal address
				"postalcode",		//Business postal code
				"url",				//Business web page
			
				"info"				//Notes			
			),
			"Value" => array(
				"","","","","","","","","","","","",""
			),
		),//initials Initials

        "ProFTPD" => array(
				"Attribute" => array(
					"objectclass",
			  		"cn",
					"uid", 
					"uidNumber", 
					"gidNumber",
					"userPassword",
					"homeDirectory",
					"loginShell"
					),
				"Value" => array(
					"posixAccount",
					"",
					"",
					"",
					"",
					"{crypt}",
					"/home",
					"/bin/bash"
				)
		),
		
       	"PureFTPD" => array(
				"Attribute" => array(
					"objectClass",
			  		"cn",
					"uid", 
					"uidNumber", 
					"gidNumber",
					"userPassword",
					"homeDirectory",

					"objectClass",
					"FTPStatus",
					"FTPQuotaFiles",
					"FTPQuotaMBytes",
					"FTPDownloadBandwidth",
					"FTPUploadBandwidth",
					"FTPDownloadRatio",
					"FTPUploadRatio"
					),
				"Value" => array(
					"posixAccount",
					"",
					"",
					"",
					"",
					"{crypt}",
					"/home",
					"PureFTPdUser",
					"enabled",
					"0",
					"0",
					"0",
					"0",
					"0",
					"0"
				)
		),	
		
        "Qmail" => array(
				"Attribute" => array(
					"objectClass",
					"cn",
					"sn",
					"uid",
					"userPassword",
					"mail",
					"mailHost",
					"mailMessageStore",
					"mailQuota"	
				),
				"Value" => array(
					"qmailUser",
					"",
					"",
					"",
					"",
					"",
					"",
					"/home/*/Maildir/",									
					"1000000S,100C"
				)
		),
		
        "Postfix" => array(
				"Attribute" => array(
					"objectClass",
					"cn",
					"sn",
					"uid",
					"userPassword",
					"mail",
					"maildrop",
					"mailacceptinggeneralid"
				),
				"Value" => array(
					"person",
					"",
					"",
					"",
					"{crypt}",
					"",
					"",
					""
				)
		),
			
        "Samba" => array(
				"Attribute" => array(
					"objectClass",
					"objectClass",
					"objectClass",
					"objectClass",
					"objectClass",
					"acctflags",
					"userpassword",
					"ntpassword",
					"lmpassword",
					"uid",
					//"gid",
					"uidnumber",
					"gidnumber",
					"cn",
					"ntuid",
					"rid",
					"grouprid",
					"gecos",
					"loginshell",
					"smbhome",
					"profile",
					"homedrive",
					"script",
					"homedirectory",
					"logontime",
					"logofftime",
					"kickofftime",
					"pwdlastset",
					"pwdcanchange",
					"pwdmustchange",
					"shadowmax",
					"shadowwarning",
					"shadowlastchange"
				),
				"Value" => array(
					"account",
					"posixAccount",
					"top",
					"shadowAccount",
					"sambaAccount",
					"[U          ]",
					"{crypt}",
					"A763993FC42F396664EBD053BA326D41",
					"F6818657596D3B35AAD3B435B51404EE",
					"",					
					"",
					"",					
					"",
					"",
					"",
					"",
					"",
					"/bin/bash",
					"\\homes\\",
					"\\\\arena\\profiles\\default",
					"O:",
					"scripts\\startup.bat",
					"/home/",
					"00000000",
					"00000000",
					"00000000",
					"3A561FEC",
					"3A2CEBFF",
					"FFFFFFFF",
					"99999",
					"7",
					"11270"
				)
		)
					
	);
	
/*
dn: uid=manea,ou=Students,dc=sci,dc=univr,dc=it
objectclass: account
objectclass: posixAccount
objectclass: top
objectclass: shadowAccount
objectclass: sambaAccount
acctflags: [U          ]
userpassword: {crypt}$1$LjbaxE00$g7.4JsK6qfEalTny7XpDc/
ntpassword: A763993FC42F396664EBD053BA326D41
lmpassword: F6818657596D3B35AAD3B435B51404EE
uid: manea
uidnumber: 1002
gidnumber: 1992
cn: manea
ntuid: manea
rid: 2712
grouprid: 201
gecos: Mirko Manea
loginshell: /bin/bash
smbhome: \\arena\homes
profile: \\arena\profiles\default
homedrive: H:
script: scripts\startup.bat
homedirectory: /home/info93/manea
logontime: 00000000
logofftime: 00000000
kickofftime: 00000000
pwdlastset: 3A561FEC
pwdcanchange: 3A2CEBFF
pwdmustchange: FFFFFFFF
shadowmax: 99999
shadowwarning: 7
shadowlastchange: 11270
*/


//objectClass: inetOrgPerson
			
	function iconvs($from,$to,$gb){
		$fp = popen( "echo \"$gb\" | iconv -f $from -t $to", "r" );
		while (!feof($fp)) {
			$buffer .= fgets($fp, 4096);
		}
		pclose($fp);
		return $buffer;
	}
	
	function gb18030_utf8($gb){
		$encode = $this->iconvs("GB18030","UTF-8",$gb);
		return $encode;	
	}
	
	function utf8_gb18030($gb){
		$encode = $this->iconvs("UTF-8","GB18030",$gb);
		return $encode;			
	}

	function get_gb_value($att,$val){
		for($i=0;$i<count($this->gbAtts);$i++){
			if($this->gbAtts[$i] == $att){
				$value = $this->utf8_gb18030($val);
				break;
			}
		}
		if(!isset($value)){
			$value = $val;
		}
		return $value;
	}

	function get_utf_value($att,$val){
		for($i=0;$i<count($this->gbAtts);$i++){
			if($this->gbAtts[$i] == $att){
				$value = $this->gb18030_utf8($val);
				break;				
			}
		}
		if(!isset($value)){
			$value = $val;
		}
		return $value;
	}
	
}
/**
ANSI_X3.4-1968 ANSI_X3.4-1986 ASCII CP367 IBM367 ISO-IR-6 ISO646-US ISO_646.IRV:1991 US US-ASCII CSASCII
UTF-8
ISO-10646-UCS-2 UCS-2 CSUNICODE
UCS-2BE UNICODE-1-1 UNICODEBIG CSUNICODE11
UCS-2LE UNICODELITTLE
ISO-10646-UCS-4 UCS-4 CSUCS4
UCS-4BE
UCS-4LE
UTF-16
UTF-16BE
UTF-16LE
UTF-32
UTF-32BE
UTF-32LE
UNICODE-1-1-UTF-7 UTF-7 CSUNICODE11UTF7
UCS-2-INTERNAL
UCS-2-SWAPPED
UCS-4-INTERNAL
UCS-4-SWAPPED
C99
JAVA
CP819 IBM819 ISO-8859-1 ISO-IR-100 ISO_8859-1 ISO_8859-1:1987 L1 LATIN1 CSISOLATIN1
ISO-8859-2 ISO-IR-101 ISO_8859-2 ISO_8859-2:1987 L2 LATIN2 CSISOLATIN2
ISO-8859-3 ISO-IR-109 ISO_8859-3 ISO_8859-3:1988 L3 LATIN3 CSISOLATIN3
ISO-8859-4 ISO-IR-110 ISO_8859-4 ISO_8859-4:1988 L4 LATIN4 CSISOLATIN4
CYRILLIC ISO-8859-5 ISO-IR-144 ISO_8859-5 ISO_8859-5:1988 CSISOLATINCYRILLIC
ARABIC ASMO-708 ECMA-114 ISO-8859-6 ISO-IR-127 ISO_8859-6 ISO_8859-6:1987 CSISOLATINARABIC
ECMA-118 ELOT_928 GREEK GREEK8 ISO-8859-7 ISO-IR-126 ISO_8859-7 ISO_8859-7:1987 CSISOLATINGREEK
HEBREW ISO-8859-8 ISO-IR-138 ISO_8859-8 ISO_8859-8:1988 CSISOLATINHEBREW
ISO-8859-9 ISO-IR-148 ISO_8859-9 ISO_8859-9:1989 L5 LATIN5 CSISOLATIN5
ISO-8859-10 ISO-IR-157 ISO_8859-10 ISO_8859-10:1992 L6 LATIN6 CSISOLATIN6
ISO-8859-13 ISO-IR-179 ISO_8859-13 L7 LATIN7
ISO-8859-14 ISO-CELTIC ISO-IR-199 ISO_8859-14 ISO_8859-14:1998 L8 LATIN8
ISO-8859-15 ISO-IR-203 ISO_8859-15 ISO_8859-15:1998
ISO-8859-16 ISO-IR-226 ISO_8859-16 ISO_8859-16:2000
KOI8-R CSKOI8R
KOI8-U
KOI8-RU
CP1250 MS-EE WINDOWS-1250
CP1251 MS-CYRL WINDOWS-1251
CP1252 MS-ANSI WINDOWS-1252
CP1253 MS-GREEK WINDOWS-1253
CP1254 MS-TURK WINDOWS-1254
CP1255 MS-HEBR WINDOWS-1255
CP1256 MS-ARAB WINDOWS-1256
CP1257 WINBALTRIM WINDOWS-1257
CP1258 WINDOWS-1258
850 CP850 IBM850 CSPC850MULTILINGUAL
862 CP862 IBM862 CSPC862LATINHEBREW
866 CP866 IBM866 CSIBM866
MAC MACINTOSH MACROMAN CSMACINTOSH
MACCENTRALEUROPE
MACICELAND
MACCROATIAN
MACROMANIA
MACCYRILLIC
MACUKRAINE
MACGREEK
MACTURKISH
MACHEBREW
MACARABIC
MACTHAI
HP-ROMAN8 R8 ROMAN8 CSHPROMAN8
NEXTSTEP
ARMSCII-8
GEORGIAN-ACADEMY
GEORGIAN-PS
KOI8-T
MULELAO-1
CP1133 IBM-CP1133
ISO-IR-166 TIS-620 TIS620 TIS620-0 TIS620.2529-1 TIS620.2533-0 TIS620.2533-1
CP874 WINDOWS-874
VISCII VISCII1.1-1 CSVISCII
TCVN TCVN-5712 TCVN5712-1 TCVN5712-1:1993
ISO-IR-14 ISO646-JP JIS_C6220-1969-RO JP CSISO14JISC6220RO
JISX0201-1976 JIS_X0201 X0201 CSHALFWIDTHKATAKANA
ISO-IR-87 JIS0208 JIS_C6226-1983 JIS_X0208 JIS_X0208-1983 JIS_X0208-1990 X0208 CSISO87JISX0208
ISO-IR-159 JIS_X0212 JIS_X0212-1990 JIS_X0212.1990-0 X0212 CSISO159JISX02121990
CN GB_1988-80 ISO-IR-57 ISO646-CN CSISO57GB1988
CHINESE GB_2312-80 ISO-IR-58 CSISO58GB231280
CN-GB-ISOIR165 ISO-IR-165
ISO-IR-149 KOREAN KSC_5601 KS_C_5601-1987 KS_C_5601-1989 CSKSC56011987
EUC-JP EUCJP EXTENDED_UNIX_CODE_PACKED_FORMAT_FOR_JAPANESE CSEUCPKDFMTJAPANESE
MS_KANJI SHIFT-JIS SHIFT_JIS SJIS CSSHIFTJIS
CP932
ISO-2022-JP CSISO2022JP
ISO-2022-JP-1
ISO-2022-JP-2 CSISO2022JP2
CN-GB EUC-CN EUCCN GB2312 CSGB2312
CP936 GBK
GB18030
ISO-2022-CN CSISO2022CN
ISO-2022-CN-EXT
HZ HZ-GB-2312
EUC-TW EUCTW CSEUCTW
BIG-5 BIG-FIVE BIG5 BIGFIVE CN-BIG5 CSBIG5
CP950
BIG5-HKSCS BIG5HKSCS
EUC-KR EUCKR CSEUCKR
CP949 UHC
CP1361 JOHAB
ISO-2022-KR CSISO2022KR
**/

/*
		for($i=0;$i<=count($ldapTemplates["Outlook"]["Attribute"]);$i++){
				echo $ldapTemplates["Outlook"]["Attribute"][$i];
				echo $ldapTemplates["Outlook"]["Value"][$i];echo "<br>";
		}
		
		for($i=0;$i<count($ldapTemplates["ProFTPD"]["Attribute"]);$i++){
				echo $i;
				echo $ldapTemplates["ProFTPD"]["Attribute"][$i];
				echo $ldapTemplates["ProFTPD"]["Value"][$i];echo "<br>";
		}
		for($i=0;$i<count($ldapTemplates["Qmail"]["Attribute"]);$i++){
				echo $i;
				echo $ldapTemplates["Qmail"]["Attribute"][$i];
				echo $ldapTemplates["Qmail"]["Value"][$i];echo "<br>";
		}
*/
?>