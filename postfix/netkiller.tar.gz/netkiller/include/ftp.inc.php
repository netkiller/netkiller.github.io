<?php
// Ftp Class

class FTP {
	var $host   	= "localhost";
	var $user     	= "anonymous";
	var $pass		= "";
	var $port    	= 21;	
	var $ftp_stream = null;
	var $isConnect 	= false;
	var $isLogin	= false;
	var $ftppwd		= "~";
	var $ftplist   	= array();
	var $error   	= 0;
	var $isSuccess 	= false;
	var $ftppath	= "";
	var $systype = "";
//-------------------------------------------------------------------------------------
function ftpConnect() {
    // ����FTP������
	$this->ftp_stream = @ftp_connect($this->host,$this->port);
	if(!$this->ftp_stream){
		$this->error = "001";		
		$this->isConnect = false;
	}else{
		$this->isConnect = true;
	}
	return $this->isConnect;
}

function getConnect(){
	return $this->ftp_stream;
}

function ftpLogin() {
	// ��¼FTP������
		$this->isLogin = @ftp_login($this->ftp_stream,$this->user,$this->pass);
		if(!$this->isLogin){
			$this->error = "002";
			$this->isLogin = false;
		}else{
			$this->isLogin = true;
		}
	return $this->isLogin;
}

function ftpPwd() {
	$this->ftppwd = ftp_pwd($this->ftp_stream);
	return $this->ftppwd;
}

function ftpChdir($chdir) {
	$this->isSuccess=@ftp_chdir($this->ftp_stream,$chdir);
}

function ftpCdup() {
	$this->isSuccess = ftp_cdup($this->ftp_stream);
}

function ftpMakedir($mkdir) {
	$this->isSuccess = @ftp_mkdir($this->ftp_stream,$mkdir);
	return $this->isSuccess;
}

function ftpDelete($deldir) {
	$this->isSuccess = @ftp_rmdir($this->ftp_stream,$deldir);
	return $this->isSuccess;
}

function ftpnList($dir) {
	$this->ftplist = ftp_nlist($this->ftp_stream,$dir);
}

function ftprawList($dir) {
	$this->ftplist = ftp_rawlist($this->ftp_stream,$dir);
}

function ftpPut($remote_file,$local_file,$mode) {
	$this->isSuccess = @ftp_put($this->ftp_stream,$remote_file,$local_file,$mode);
}

function ftpClost() {
	ftp_quit($this->ftp_stream);
}

function ftpError() {
	return $this->error;
}

function ftpSysType() {
	$this->systype = @ftp_systype($this->ftp_stream);
	return $this->systype;
}


function analyzer_error($err_list,$err) {
	$result = "";
	switch ($err){
		case "001":
    		$result = $err_list["Connect"];
		    break;
		case "002":
			$result = $err_list["Login"];
			break;			
		default:
		    $result = "Error!";
		    break;
	}
//	echo "> $err | $result";echo $ftpConnectError;echo "<BR>";
	return $result;
}


}
//////////////////////////////////////////////////////////////////////////////////

?>