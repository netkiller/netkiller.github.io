<html>
<head>
<title>Site Manager</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<frameset cols="128,665" rows="*" frameborder="YES" bordercolor="#333399" border="1" framespacing="1"> 
  <frame src="tree.php" scrolling="NO" name="tree" marginwidth="2" marginheight="5" >
  <frame name="main" src="main.html">
</frameset>
<noframes> 
<body bgcolor="#FFFFFF" text="#000000">
</body>
</noframes> 
</html>
