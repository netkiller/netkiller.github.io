<html>
<head>
<title>Show coding...</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>
<body bgcolor="#A29DD0" text="#000000">
<?
	require('../function.php');
	$filename=$HTTP_GET_VARS['filename'];
	$file = basename($filename);
?>
<div align="left"><font color=white> ��ǰ�ļ��� 
  <?print $file?>
  </font></div>
<form name="code" method="post" action="writecode.php">
  <div align="center"> <br>
    <table border='0' cellpadding='3' cellspacing='1' bgcolor='#000000' align='center' width="90%">
      <tr > 
        <td bgcolor="#9999CC"> 
          <?showcodefile($filename);?>
        </td>
      </tr>
      <tr > 
        <td bgcolor="#9999CC"> 
          <div align="center"> 
            <input type="button" name="close2" value="�رմ���" onClick="self.close()">
          </div>
        </td>
      </tr>
    </table>
  </div>
</form>
</body>
</html>
