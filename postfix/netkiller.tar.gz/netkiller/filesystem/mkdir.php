<?
	session_start(); 
	session_register("path"); 
?>
<html>
<head>
<title>make directory</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?
	$dirname = $HTTP_POST_VARS['dirname'];
	$dirmod = $HTTP_POST_VARS['mod'];
	if($dirname){
	if(mkdir($path."/".$dirname,$dirmod))$path=$dirname; else echo "NO";//$newfilename;
	}
?>
<form name="mkdir" method="post" action="">
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="3" bgcolor="#333399" height="17"><font color="#FFFFFF">����Ŀ¼</font><font color="#FFFFFF">: 
        <?echo $path?>
        </font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td width="29%" height="2">��Ŀ¼����</td>
      <td width="49%" height="2"> 
        <input type="text" name="dirname" size="25" value="">
      </td>
      <td width="22%" height="2">&nbsp; </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2">Ŀ¼Ȩ�ޣ�</td>
      <td height="2">
        <input type="text" name="textfield" maxlength="4" size="8" value="0755">
      </td>
      <td height="2">&nbsp;</td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2"> 
        <div align="center"></div>
      </td>
      <td height="2"> 
        <div align="center"> 
          <input type="submit" name="Submit" value="Submit">
        </div>
      </td>
      <td height="2">&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="3" bgcolor="#333399" height="2"> 
        <div align="center"><font color="#FFFFFF" onClick="self.close()" class="hand">���رմ��ڡ�</font></div>
      </td>
    </tr>
  </table>
</form>
</body>
</html>
