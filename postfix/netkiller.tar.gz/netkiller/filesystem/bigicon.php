<?
	session_start(); 
	session_register("path"); 
?>
<html>
<head>
<title>Site Manager</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="5" topmargin="5">
<?
	require('../include/function.php');
	$path=$HTTP_GET_VARS['path'];
	if(!$path)$path='.';
	$count=0;
	$columns=0;

?>
<table width="100%" border="0">
  <tr bgcolor="#333399"> 
    <td colspan="2"><b> 
      <?echo $VERSION?>
      </b> </td>
  </tr>
  <tr> 
    <td> 
      <form name=directory>
        <table width="100%" border="3" cellspacing="0" cellpadding="5" bgcolor="E0F0FF" class="t02" align="center" bordercolor="4FA7FF" height="0%">
          <tr valign="top"> 
            <td colspan="2" height="52"> 
              <table width="100%" border="1" cellspacing="0" cellpadding="0" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" height="7%">
                <tr> 
                  <td>
                <?
		$handle=opendir($path);
		rewinddir($handle);
		chdir($path);
		echo "Path:<input type=text name=path value=\"$path\" size=70 onFocus=this.select() onMouseOver=this.focus()>";
		echo "<input type=button name=\"own\" value=\" ~ \" onclick=\"location.href='list.php?path=.'\">";
		echo "<input type=button name=\"root\" value=\" / \" onclick=\"location.href='list.php?path=/'\">";
		echo "<input type=button name=\"home\" value=\"/home\" onclick=\"location.href='list.php?path=/home'\">";
		echo "<input type=button name=\"etc\" value=\"/etc\" onclick=\"location.href='list.php?path=/etc'\">";
		echo "<input type=button name=\"usr\" value=\"/usr\" onclick=\"location.href='list.php?path=/usr'\">";
		echo "<input type=button name=\"var\" value=\"/var\" onclick=\"location.href='list.php?path=/var'\">";
		echo "<input type=button name=\"mnt\" value=\"/mnt\" onclick=\"location.href='list.php?path=/mnt'\">";
?>
				</td>
                </tr>
				<tr><td>
				<table width="100%" border="1" cellspacing="0" cellpadding="0" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF">
<?				
		while ($file=readdir($handle)) {

			if(is_dir("$file")){
				//$ico="<font face=Wingdings size=5>1</font>";
				$ico=DirIco($file);
				$filelink="<a href=bigicon.php?path=$path/$file>�� ".$file." ��</a>";//��".$file."����".$file."��
			 }else{
				$ico="<font face=Wingdings size=6>2</font>";
				$filelink=filelinktype($path,$file);
			 }

		if($columns == 6){
			echo "</tr>";
			$columns=0;
		}else if ($columns == 0){
			echo "<tr>";	
				
		}
		$columns++;
		echo "<td><center>$ico<br>$filelink</center></td>";
		$count++;
		}
		?>
		</table>
		</td>
                </tr>
                <tr> 
                  <td> 
                    <div align="right">OICQ:13721218 , ICQ:101888222 , Email:<a href="mailto:netkiller@xaid.net">netkiller@xaid.net</a></div>
                  </td>
                </tr>
                <tr> 
                  <td>&nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </form>
      <?
	clearstatcache();
	closedir($handle);
?>
    </td>
  </tr>
  <tr> 
    <td> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td><a href=javascript:messagebox('updatefile.htm','100',500)>�ļ��ϴ�</a> 
            | <a href=javascript:messagebox('mkdir.php','150','500')>����Ŀ¼</a> 
            | 
            <input type="button" name="chdir" value="ˢ��" onClick="location.href='bigicon.php?path='+directory.path.value">
          </td>
          <td> 
            <div align="right"> 
              <select name="select" onChange="location.href = this.options[this.selectedIndex].value;" style="font-size: 10pt; width: 130; background-color: E0F0FF; color: rgb(0,0,0); font-weight: 200" size="1">
                <option selected>�鿴��ʽ</option>
                <option value="list.php">��ϸ����</option>
                <option value="bigicon.php">��ͼ��</option>
                <option value="miniature.php">����ͼ</option>
              </select>
            </div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td bgcolor="#333399"><font color="#FFFFFF">��ǰ�ܼƣ� 
      <?echo $count?>
      ��ǰĿ¼��ʣ����ÿռ䣺 
      <?echo "".diskfreespace('/');?>
      byte</font></td>
  </tr>
</table>
<!--    Html End              -->
</body>
</html>
<?exit;?>
