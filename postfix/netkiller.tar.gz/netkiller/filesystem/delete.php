<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?
	$filename=$HTTP_GET_VARS[filename];
?>
<form name="rename" method="post" action="<? echo $PHP_SELF; ?>">
  <table width="60%" border="0" align="center">
    <tr> 
      <td bgcolor="#333399" height="17"><font color="#FFFFFF">ɾ��Ŀ��: 
        <?echo $filename;?>
        </font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td>
	  	<?
		if(!unlink($filename))
			echo "<div align=center>ɾ������ʧ�ܣ�</div>";
		else
			echo "<div align=center>ɾ�������ɹ���</div>";
		?>
      </td>
    </tr>
    <tr> 
      <td bgcolor="#333399">
        <div align="right"><a href="javascript:self.close();"><font color="#FFFFFF">�� 
          �رմ��ڡ�</font></a></div>
      </td>
    </tr>
  </table>
  </form>
</body>
</html>
