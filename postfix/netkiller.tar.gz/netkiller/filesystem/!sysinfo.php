<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body>
<?
	$deletedn = urldecode($dn);
?>
<form method=post action="<?echo $PHP_SELF?>">
  <p>&nbsp;</p>
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="2" bgcolor="#333399" height="17"><font color="#FFFFFF">DES���빤��: 
        <?echo $deletedn?> </font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td width="15%" height="2" align="center">Apache</td>
      <td width="85%" height="2"> 
        <?php
$headers = getallheaders();
while (list($header, $value) = each($headers)) {
  echo "$header: $value<br>\n";
}
?>
      </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp;</td>
      <td height="2"> 
        <?php
		echo get_current_user();
echo getmyuid();
		?>
      </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp;</td>
      <td height="2"> 
        <?php
echo "��ҳ����޸�ʱ��: ".date("F d Y H:i:s.", getlastmod());
?>
      </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp;</td>
      <td height="2">
        <?php
echo getmyinode()
?>
      </td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td height="2" align="center">PID</td>
      <td height="2">
        <?php
echo getmypid();
?>
      </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp; </td>
      <td height="2">
<?php
$dat = getrusage();
echo $dat["ru_nswap"];         // Swaps ��
echo $dat["ru_majflt"];        // ��ҳ��
echo $dat["ru_utime.tv_sec"];  // ʹ��ʱ�� (��)
echo $dat["ru_utime.tv_usec"]; // ʹ��ʱ�� (����)
?> 
<?php
$dat = getrusage(2);
echo $dat["ru_nswap"];         // Swaps ��
echo $dat["ru_majflt"];        // ��ҳ��
echo $dat["ru_utime.tv_sec"];  // ʹ��ʱ�� (��)
echo $dat["ru_utime.tv_usec"]; // ʹ��ʱ�� (����)
?> 	  
	  </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">phpinfo</td>
      <td height="2">
        <?php
//echo phpinfo();?>
      </td>
    </tr>    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp; </td>
      <td height="2">
<?php
echo "��վʹ�� PHP �汾Ϊ: ".phpversion();
?> 	  
	  </td>
    </tr>    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp; </td>
      <td height="2">&nbsp; </td>
    </tr>    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp; </td>
      <td height="2">&nbsp; </td>
    </tr>    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp; </td>
      <td height="2">&nbsp; </td>
    </tr>	
    <tr> 
      <td colspan="2" bgcolor="#333399" height="2"> <div align="center"> 
          <input type="submit" name="Submit" value="Submit">
        </div></td>
    </tr>
  </table>
  <p>&nbsp; </p>
</form>
<script>
//history.back();
//location.href = ldap.php;
</script>
</body>
</html>
