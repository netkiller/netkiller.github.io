<?
if (($Ok) AND ($photofile)) {
  copy($photofile, "photo/chen.jpg");
  unlink($photofile);

  //header("Location: ../bbs/bbsdefault.php?id=$id\n");
  exit;
}
?> 
<FORM ENCTYPE="multipart/form-data" METHOD="POST" ACTION="<? echo $PHP_SELF?>">
<TABLE border=0 width=95% align=center bgcolor=<? echo $BODY_COLOR; ?> class=wdBlack>
  <TR>
    <TD colspan=4 bgcolor=<? echo $HEADER_COLOR; ?>>&nbsp;</TD>
  </TR>
  <TR>
    <TD>
        ��ѡ����Ҫ�ϴ�����Ƭ�� ( 200x150��JPG��ʽ����Ƭ�ļ���С������80KB )<BR>
        <INPUT TYPE="file" NAME="photofile">
        <INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="100000">
    </TD>
  </TR>
  <TR>
    <TD>
      <INPUT TYPE="submit" NAME="Ok" VALUE=" ��ʼ�ϴ� ">
      <INPUT type=hidden name=id value="<? echo $id; ?>">
    </TD>
  </TR>
</TABLE>
</FORM>

<DIV class=wdBlack align=center></DIV>
<BR>

</BODY>
</HTML>