<?
	session_start(); 
	session_register("path"); 
?>
<html>
<head>
<title>Site Manager</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?
	require('../function.php');
	$path=$HTTP_GET_VARS['path'];
	//echo strlen($path);
	if(!$path)$path='.';
	$count=0;
	$fifo=0;
	$char=0;
	$dir=0;
	$block=0;
	$link=0;
	$files=0;
	$unknowns=0;

?>
<table width="100%" border="0">
  <tr bgcolor="#333399"> 
    <td><b><font size="4" color="#FFFFFF" face="System"><a href="http://www.9812.net" class="wlink">Site 
      Manager 1.0.0 Netkiller chen </a></font></b></td>
    <td>
      <div align="right"><a href="telnet://<?echo $REMOTE_ADDR;?>"><font color=white><b><?echo $REMOTE_ADDR;?></b></font></a></div>
    </td>
  </tr>
  <tr> 
    <td height="45" colspan="2">
	<form name=directory>
        <table width="100%" border="0">
          <tr bgcolor="#aaaaaa"> 
            <td height="2">ͼ��</td>
            <td height="2">����</td>
            <td height="2">��|inode</td>
            <td height="2">���� </td>
            <td height="2">�޸�ʱ��</td>
            <td height="2">GID,OWN</td>
            <td height="2"> 
              <p>����</p>
            </td>
          </tr>
          <?
		$handle=opendir($path);
		rewinddir($handle);
		chdir($path);
		echo "Handle: ".$handle."<br>\n";
		echo "Path:<input type=text name=path value=\"$path\" size=70 onFocus=this.select() onMouseOver=this.focus()><input type=\"button\" name=\"chdir\" value=\"ת��\" onclick=\"location.href='list.php?path='+directory.path.value\"><input type=\"button\" name=\"chdir\" value=\"Home\" onclick=\"location.href='list.php?path=.'\">";
		while ($file=readdir($handle)) {
			
			if(is_dir("$file")){
				$type="�ļ���";
				$ico="<font face=Wingdings >1</font>";
				$filelink="<a href=list.php?path=$path/$file>�� ".$file." ��</a>";//��".$file."����".$file."��
				$delete="<a href=javascript:messagebox('rmdir.php?dirname=$path/$file','100',500)>ɾ��</a>";
			 }else{
			 	$type="�ļ�";
				$ico="<font face=Wingdings size=3>2</font>";
				//$dir_file="<a href=javascript:openwin('showcode.php?filename=$path/$file')>$file</a>";
				$filesize=filesize($file);
				$filelink=filelinktype($path,$file);
				$rename="<a href=javascript:messagebox('rename.php?filename=$path/$file','100',500)>����</a>";
				$delete="<a href=javascript:messagebox('delete.php?filename=$path/$file','100',500)>ɾ��</a>";
			 }
			$fileinode=fileinode($file);
			$filemodtime = date("F j Y h:i:s A", filemtime($file));
			$filegroup=filegroup($file);
			$fileowner=fileowner($file);
			$fileperms=fileperms($file);
			$filetype=filetype($file);
			$count++;
			switch($filetype){
			  case "fifo":
			    $fifo++;
			    break;
			  case "char":
			    $char++;
			    break;
			  case "dir":
			  	$dir++;
				break;
			  case "block":
			 	$block++;
				break;
			  case "link":
			  	$link++;
				break;
			  case "file":
			  	$files++;
				break;
			  case "unknown":
			    $unknowns++;
				break;
			 };
    	echo "
        <tr bgcolor=#cccccc> 
		  <td><center>$ico</center></td>
          <td>$filelink</td>
          <td>$filesize|$fileinode</td>
          <td>$type | $filetype</td>
          <td>$filemodtime</td>
		  <td>$filegroup|$fileowner</td>
		  <td>$rename|$delete</td>
        </tr>";
		}
		?>
        </table>
      </form>
	  <a href=javascript:messagebox('updatefile.htm','100',500)>�ļ��ϴ�</a> | <a href=javascript:messagebox('mkdir.php','150','500')>����Ŀ¼</a></td>
  </tr>
  <tr> 
    <td bgcolor="#333399" height="2" colspan="2"><font color=white>��ǰĿ¼��ʣ����ÿռ䣺 
      <?echo "".diskfreespace('/');?>
      byte </font></td>
  </tr>
</table>
<?
	clearstatcache();
	closedir($handle);
?>
<br><!--    Html End              -->
<table width="100%" border="3" cellspacing="0" cellpadding="5" bgcolor="E0F0FF" class="t02" align="center" bordercolor="4FA7FF" height="0%">
  <tr valign="top"> 
    <td colspan="2" height="52"> 
      <table width="100%" border="1" cellspacing="0" cellpadding="0" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" height="7%">
        <tr> 
          <td colspan="8"> 
            <div align="center">��ǰͳ�� </div>
          </td>
        </tr>
        <tr> 
          <td width="15%" height="2">dir</td>
          <td width="16%" height="2"> 
            <?echo $dir?>
          </td>
          <td rowspan="4" width="2%">&nbsp; </td>
          <td width="18%" height="2">file</td>
          <td width="14%" height="2"> 
            <?echo $files?>
          </td>
          <td rowspan="4" width="2%">&nbsp;</td>
          <td width="14%" height="2">link</td>
          <td width="19%" height="2"> 
            <?echo $link?>
          </td>
        </tr>
        <tr> 
          <td width="15%" height="2">block</td>
          <td width="16%" height="2"> 
            <?echo $block?>
          </td>
          <td width="18%" height="2">char</td>
          <td width="14%" height="2"> 
            <?echo $char?>
          </td>
          <td width="14%" height="2">fifo</td>
          <td width="19%" height="2"> 
            <?echo $fifo?>
          </td>
        </tr>
        <tr> 
          <td width="15%">unknown</td>
          <td width="16%"> 
            <?echo $unknowns?>
          </td>
          <td width="18%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
          <td width="19%">&nbsp;</td>
        </tr>
        <tr> 
          <td width="15%" height="2">&nbsp;</td>
          <td width="16%" height="2">&nbsp; </td>
          <td width="18%" height="2">&nbsp;</td>
          <td width="14%" height="2">&nbsp; </td>
          <td width="14%" height="2">&nbsp;</td>
          <td width="19%" height="2">&nbsp;</td>
        </tr>
        <tr> 
          <td colspan="8"> ��ǰ�ܼƣ� 
            <?echo $count?>
          </td>
        </tr>
        <tr>
          <td colspan="8">
            <div align="right">OICQ:13721218 , ICQ:101888222 , Email:<a href="mailto:netkiller@xaid.net">netkiller@xaid.net</a></div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?exit;?>