<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?
	$filename=$HTTP_GET_VARS[filename];
	//chdir(dirname($filename));
	$newname = $HTTP_POST_VARS['newname'];
	$oldname = $HTTP_POST_VARS['oldname'];
	if($newname){
	if(rename($oldname,dirname($oldname)."/".$newname))$filename=dirname($oldname)."/".$newname; else echo "NO";//$newfilename;
	}
	//echo dirname($oldname).$newname;
	//echo $oldname."<br>";
?>
<form name="rename" method="post" action="<? echo $PHP_SELF; ?>">
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="3" bgcolor="#333399" height="17"><font color="#FFFFFF">������:<?echo $filename;?></font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td width="29%">����Ϊ��</td>
      <td width="49%"> 
        <input type="text" name="newname" size="25">
      </td>
      <td width="22%"> 
        <input type="submit" name="Submit" value="Submit">
      </td>
    </tr>
    <tr> 
      <td colspan="3" bgcolor="#333399" height="13"> 
        <div align="center"><font color="#FFFFFF" onClick="self.close()" class="hand">���رա�</font></div>
      </td>
    </tr>
  </table>
  <input type="hidden" name="oldname" value="<?echo $filename;?>">
</form>
</body>
</html>
