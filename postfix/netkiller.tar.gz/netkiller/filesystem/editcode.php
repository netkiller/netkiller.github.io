<html>
<head>
<title>Edit Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>
<body bgcolor="#A29DD0" text="#000000">
<?
	require('../function.php');
	$filename=$HTTP_GET_VARS['filename'];
	$file = basename($filename);
?>
<div align="left"><font color=white> ��ǰ�ļ��� 
  <?print $file?>
  </font></div>
<form name="code" method="post" action="writecode.php">
  <table border='0' cellpadding='3' cellspacing='1' bgcolor='#000000' align='center'>
    <tr > 
      <td bgcolor="#9999CC"> 
        <div align="center"> 
          <textarea name="content" cols="90" rows="25"><?showtextfile($filename);?></textarea>
          <input type="hidden" name="filename" value="<?echo $filename?>">
        </div>
      </td>
    </tr>
    <tr >
      <td bgcolor="#9999CC"> 
        <div align="center">
          <input type="submit" name="Submit" value="�������">
          <input type="button" name="showcode" value="��������" onClick="location.href='showcode.php?filename=<?echo $filename?>'">
          <input type="button" name="RUN" value="����Ԥ��" onClick="location.href='<?echo $filename?>'">
          <input type="button" name="Clear" value="��մ���" onClick=code.content.value=''>
          <input type="button" name="close" value="�رմ���" onClick="self.close()">
        </div>
      </td>
    </tr>
  </table>
</form>
</body>
</html>
