<?
session_start(); 
require("../include/global.inc.php");
require("privileges.inc.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�޸�����</title>
<SCRIPT language=JavaScript>
<!--
function Submits()
{
	/*if(document.mail.user.value == "" || document.mail.user.value.length < 5)
	{
		alert("�������û���,�û���5���ַ����ϣ�");
		return false;
	}else */
	if(document.mail.password.value.length < 4 || document.mail.password.length < 10){
		alert("���������ĸ��ַ�");
		return false;
	}else if(document.mail.password.value != document.mail.confirm.value){
		alert("������������벻ͬ��");
		return false;
	}
	else{document.mail.submit();}
}
//-->
</Script>
</head>

<body>
<form name="mail" method="post" action="postfixadmin.php" onSubmit="return Submits();">
  <table width="75%" border="0">
    <tr>
      <td>���� </td>
      <td><input name="user" type="text" disabled value="<? echo $mail?>"></td>
    </tr>
    <tr>
      <td>������</td>
      <td><input name="password" type="password" maxlength="20"></td>
    </tr>
    <tr>
      <td>ȷ������</td>
      <td><input name="confirm" type="password" maxlength="20">
        <input name="op" type="hidden" id="op" value="resetpasswd">
        <input name="mail" type="hidden" id="mail" value="<? echo $mail?>"></td>
    </tr>
  </table>

    <input type="submit" name="Submit" value="�ύ">
  <input type="button" name="Submit2" value="��ť" onClick="window.close();">
</form>
</body>
</html>
