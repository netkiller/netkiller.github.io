<?
	session_start(); 
	//session_register("session_name","session_level","session_userid");
	require("../include/global.inc.php");
	require("privileges.inc.php");
	$img = "3b.jpg";
	//echo "$session_level | $session_name | $session_userid| $session_mailnum";
?>
<html><!-- InstanceBegin template="/Templates/Common.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<!-- InstanceBeginEditable name="doctitle" -->
<title>����ע��</title>
<!-- InstanceEndEditable --> <!-- InstanceBeginEditable name="head" -->
<SCRIPT language=JavaScript>
<!--
function Submits()
{
	if(document.mail.user.value == "" || document.mail.user.value.length < 5)
	{
		return alert("�������û���,�û���5���ַ����ϣ�");
	}else if(document.mail.password.value.length < 4 || document.mail.password.length < 4){
		return alert("�û������������ַ�����������û���̫����");
	}else if(document.mail.password.value != document.mail.confirm.value){
		return alert("������������벻ͬ��");
	}
	else{document.mail.submit();}
}
//-->
</Script>
<!-- InstanceEndEditable -->
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="179"><img src="images/1.jpg" width="179" height="64"></td>
    <td width="248" background="images/bg1.jpg">&nbsp;</td>
    <td width="283"><img src="images/2.jpg" width="283" height="64"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><img src="images/<? echo $img?>" width="710" height="41"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="324"><img src="images/4.jpg" width="324" height="137"></td>
    <td width="327" valign="top" bgcolor="DEFEB3"> <!-- InstanceBeginEditable name="EditRegion" --> 
      <?
//		$session_mailnum
	if(isset($op) && $op == "register"){
		if($password == $confirm){
			if(isset($user)){
				$userid = $user."@".$domain;
				$quota	= "5000000";
				$pfx->register($userid,$user,$password,$domain,$quota);
				$pfx->addMemberMail($session_userid,$userid,$isfree);
				//echo "<script>location.href='http://www.gdfz.com/mail';<script>";
			}else{
				echo "�û�������Ϊ�գ�";
			}
		}else{
			echo "������������벻ͬ��";
		}
	}else{

?>
<?
	$mailcount 	= $pfx->getMemberMailCount($session_userid);
/*				switch($session_level){
					case "advance":
						break;
					case "au":
						break;
					case "":
						break;
				}
*/		
	$isfree = "false";
	if($mailcount == $session_mailnum){
		$error_msg = "��������Ѿ����꣡<br>��Ҫע��your@gdfz.com�շ�������";
	}else if($mailcount < $session_mailnum){
		$isfree = "true";
		$num = $session_mailnum-$mailcount;
		$error_msg = "������ $num ��������䣡";
	}else{
		$error_msg = "��Ҫע��your@gdfz.com�շ�������";
	}
	echo $error_msg;

?>
      <form name="mail" method="post" action="">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td>�û�</td>
            <td><input name="user" type="text" size="15">
              @ gdfz.com 
              <input name="domain" type="hidden" id="domain" value="gdfz.com"></td>
          </tr>
          <tr> 
            <td>����</td>
            <td><input name="password" type="password" id="password" size="15">
              *��������4λ</td>
          </tr>
          <tr> 
            <td>ȷ������</td>
            <td><input name="confirm" type="password" id="confirm" size="15"> 
              <input name="op" type="hidden" id="op" value="register">
              <input name="isfree" type="hidden" id="isfree" value="<? echo $isfree; ?>"></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><input type="button" name="Submit" value="ȷ��" onclick="Submits()"></td>
          </tr>
        </table>
      </form>
      <SCRIPT language=JavaScript>
<!--
	document.mail.user.focus();
//-->
</Script>
<?}?>
      <!-- InstanceEndEditable --> </td>
    <td width="59"><img src="images/5.jpg" width="59" height="137"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><img src="images/6.jpg" width="710" height="37"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="382" valign="middle" background="images/bg2.jpg"><!-- InstanceBeginEditable name="Address" --> 
      <table width="75%" border="0">
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2">&nbsp; </td>
        </tr>
        <tr> 
          <td width="17%">&nbsp;</td>
          <td width="17%"><font color="#0000FF">POP3</font></td>
          <td width="66%"><font color="#0000FF">pop3.gdfz.com</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><font color="#0000FF">SMTP</font></td>
          <td><font color="#0000FF">smtp.gdfz.com (SMTP��Ҫ��֤)</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><font color="#0000FF">IMAP</font></td>
          <td><font color="#0000FF">imap.gdfz.com</font></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <!-- InstanceEndEditable --></td>
    <td width="328"><img src="images/7.jpg" width="328" height="240"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><img src="images/8.jpg" width="710" height="100"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="689"><div align="left"><img src="images/9.jpg" width="686" height="32" border="0" usemap="#Map"></div></td>
  </tr>
</table>
<map name="Map">
  <area shape="rect" coords="438,7,596,23" href="http://www.cnwwwcn.com" target="_blank">
</map>
</body>
<!-- InstanceEnd --></html>
