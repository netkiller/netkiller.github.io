<?
session_start(); 
require("../include/global.inc.php");
require("privileges.inc.php");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
<title>Postfix Admin</title>
</head>

<body>

<?
if($op != null){
 	switch($op){
		case "adddomain":
			$pfx->addDomain($maildomain,$transport,$desc,$begin,$end);
			break;
		case "rmdomain":
			$pfx->delDomain($domain);
			$domain = null;
			break;
		case "rmmail":
			$pfx->delDomainUser($mail);
			break;
		case "chdomain":
			$pfx->chDomain($domain,$ndomain,$desc,$begin,$end);
			break;
		case "chmailbox":
			$pfx->chDomainUserDetails($userid,$mailbox,$name,$quota);
			break;
		case "resetpasswd":
			$pfx->resetPasswd($mail,$password);
			echo "�����޸ĳɹ���";
			break;
		case "mailq":
			$fp = popen("mailq -v", "r");
			echo "<pre>";
			while (!feof($fp)) {
				$data = fgets ($fp,1024);
				$data = str_replace("\n", "<br>", $data);
				echo $data;
			}
			echo "</pre>";
			pclose ($fp);		
			break;
		
	}
}
?>

<?
if($domain != null){
?>
<font size="7"><strong><em><? echo $domain ?> -<font size="6">������ </font></em></strong></font> 
<br>
<?
}
?>
<button onclick="location.href='adddomain.php'">����������</button>
<?
if($domain != null){
?>
<button onclick="location.href='addmailbox.php?domain=<? echo $domain?>'">��������</button>
<?
}
?>

<table width="100%" border="1">
  <tr> 
    <td width="17%" valign="top"> 
    <? 
	$dl = $pfx->getDomainList();
	$count = count($dl);
	for ($i=0;$i<$count;$i++){
		$domainlist = $dl[$i];
		echo "<a href=?domain=".$domainlist.">".$domainlist."</a><br>";
	}
	?>	
</td>
    <td width="83%" colspan="2" valign="top"> 
	<table width="100%" border="1">
        <tr>
		  <td width="7%">���&nbsp;</td>
		  <td width="23%">����&nbsp;</td>
		  <td width="22%">����&nbsp;</td>
          <td width="22%">�û���&nbsp;</td>
          <td width="26%">����&nbsp;</td>
        </tr>
      <?
	$du = $pfx->getDomainUser($domain);
	$count = count($du);
	for ($i=0;$i<$count;$i++){
		$mail = $du[$i][0];
		$name = $du[$i][1];
		$quota = $du[$i][2];
		$quota /=1000000;
		//echo $mail;
		
		$table = "<tr>";
		$table .= "<td>".($i+1)."</td>";
		$table .= "<td><a href='chmailbox.php?domain=$domain&mailbox=$mail'>�޸ļ�¼</a> <a href='chpasswd.php?domain=$domain&mail=$mail'>��������</a> <a href='?op=rmmail&domain=$domain&mail=$mail'>ɾ��</a></td>";
		$table .= "<td>".$mail."</td>";
		$table .= "<td>".$name."</td>";
		$table .= "<td>".$quota."M</td>";
		$table .= "</tr>";
		echo $table;
	}	
	
	?>
      </table>
	</td>
  </tr>
</table>
  
  


<button onclick="location.href='<? echo $PHP_SELF; ?>?op=mailq'">
<p>�ʼ���Ϣ�ж�</p>
</button>	 
<BUTTON onclick="window.external.ShowBrowserUI('LanguageDialog', null)"></BUTTON>
<BUTTON onclick="window.external.ShowBrowserUI('OrganizeFavorites', null)"></BUTTON>
<!--
<script>
 function OpenDialog(objectfile)
 {
  // Dialog.aspx������Ҫģ̬��ʾ��Web Form
  window.showModelessDialog("adddomain.php","od","dialogTop: 50px; dialogLeft: 200px; center: Yes; help: No; resizable: No; status: No;");
 }
</script>
<INPUT style="Z-INDEX: 110; LEFT: 246px; WIDTH: 200px; POSITION: absolute; 
TOP: 449px; HEIGHT: 38px"  type="button" value="Show Dialog" onclick="OpenDialog()">
-->
<?
$domaindetails = $pfx->getDomainDetails($domain);
?>
<table width="75%" border="1">
  <tr> 
    <td width="27%">������</td>
    <td width="37%">ע������</td>
    <td width="36%">��������</td>
  </tr>
  <tr> 
    <td><a href="index.php?domain=<? echo $domaindetails[domain];?>" target="login"><? echo $domaindetails[domain];?></a>&nbsp;</td>
    <td><? echo $domaindetails[begin_date];?>&nbsp;</td>
    <td><? echo $domaindetails[end_date];?>&nbsp;</td>
  </tr>
  <tr> 
    <td>����</td>
    <td colspan="2"><? echo "<pre>".$domaindetails[description]."</pre>";?>&nbsp;</td>
  </tr>
  <tr align="center"> 
    <td colspan="3"><? echo "<button onclick=\"location.href='?op=rmdomain&domain=$domain'\">ɾ��</a><button onclick=\"location.href='chdomain.php?op=chdomain&domain=$domain'\">�޸�</a>"?>&nbsp;</td>
  </tr>
</table>
</body>
</html>
