<?
session_start(); 
require("../include/global.inc.php");
require("privileges.inc.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�޸�����</title>
</head>

<body>
<?
	$userdetails = $pfx->getDomainUserDetails($mailbox);
?>
<form name="form1" method="post" action="postfixadmin.php">
  <p>&nbsp;</p>
  <table width="75%" border="1">
    <tr> 
      <td>���䣺</td>
      <td><input name="mailbox" type="text" id="mailbox" value="<? echo $userdetails["user"] ?>"></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>�û�����</td>
      <td><input name="name" type="text" id="name" value="<? echo $userdetails["name"] ?>"></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>������ </td>
      <td> 
        <select name="quota" id="quota">
          <option value="2000000" selected>2M</option>
          <option value="5000000">5M</option>
          <option value="8000000">8M</option>
          <option value="10000000">10M</option>
          <option value="20000000">20M</option>
          <option value="50000000">50M</option>
          <option value="80000000">80M</option>
          <option value="100000000">100M</option>
        </select>
        <? echo $userdetails["quota"]/1000000 ?> MB</td>
      <td>��λ(MB)</td>
    </tr>
    <tr>
      <td><input type="submit" name="Submit" value="�ύ"></td>
      <td> <input name="op" type="hidden" id="op2" value="chmailbox"> <input name="userid" type="hidden" id="userid2" value="<? echo $userdetails["userid"] ?>"> 
      </td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
</body>
</html>
