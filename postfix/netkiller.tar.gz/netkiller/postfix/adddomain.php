<?
session_start(); 
require("../include/global.inc.php");
require("privileges.inc.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�ޱ����ĵ�</title>
</head>

<body>


  <fieldset>
  <legend>����������</legend>
<form action="postfixadmin.php" method="post" name="domain" id="domain">
  <table width="75%" border="1">
    <tr> 
      <td>������</td>
      <td><input name="maildomain" type="text" id="maildomain2" size="20"> </td>
      <td><font color="#FF0000">example.com</font></td>
    </tr>
    <tr> 
      <td>��ʼ����</td>
      <td><input name="begin" type="text" id="begin" value="<? echo date("Y-m-d"); ?>"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>��������</td>
      <td><input name="end" type="text" id="end"></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>����</td>
      <td><textarea name="desc" cols="40" rows="5" id="desc"></textarea></td>
      <td>��˾���ơ���ַ��</td>
    </tr>
    <tr> 
      <td colspan="3"><input type="submit" name="Submit" value="�ύ"> <input name="op" type="hidden" id="op2" value="adddomain"> 
        <input name="transport" type="hidden" id="transport2" value="virtual:"> 
      </td>
    </tr>
  </table>
</form>
  
</fieldset>
</body>
</html>
