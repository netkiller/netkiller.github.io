<?
session_start();
require("../include/global.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>��ҵ�ʾ�</title>
<SCRIPT language=JavaScript>
<!--
function Submits()
{
	if(document.logon.user.value == "")
	{
		alert("�������û�");
		return false;
	}else if(document.logon.password.value == ""){
		alert("����������");
		return false;
	}
	//else if(document.logon.password.value.length < 4 || document.logon.password.length < 4){
	//	alert("�û������������ַ�����������û���̫����");
	//	return false;
	//}
	//else if(document.logon.password.value != document.logon.confirm.value){
	//	return alert("������������벻ͬ��");
	//}
	else{
		document.logon.username.value = document.logon.user.value+"@"+document.logon.domain.value;
		document.logon.submit();
	}
}
//-->
</Script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<?
if(empty($domain)){
	$domain = "gdfz.com";
}
	$domaindetails = $pfx->getDomainDetails($domain);
//$domain = "meikai-cn.com";

?>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="179"><img src="images/1.jpg" width="179" height="64"></td>
    <td width="248" background="images/bg1.jpg">&nbsp;</td>
    <td width="283"><img src="images/2.jpg" width="283" height="64"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/3.jpg" width="710" height="41"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="324"><img src="images/4.jpg" width="324" height="137"></td>
    <td width="327" valign="top" bgcolor="DEFEB3">
	<form action="http://202.103.190.130/cgi-bin/webmail/sqwebmail" method="post" name="logon" id="logon" onSubmit="return Submits();">
        <br>
        <table width="100%" border="0" align="center" cellpadding="2" cellspacing="0" class=csmtype>
          <tr> 
            <td>�û�: 
              <input name="user" type="text" class=myinput id="user" style='font-family:tahoma' size="15">
              @<? echo $domain?></td>
          </tr>
          <tr> 
            <td colspan=2>����: 
              <input type="password" name="password" class=myinput size="15" style='font-family:tahoma'> 
            </td>
          </tr>
          <tr> 
            <td colspan=2><input type="checkbox" checked="checked" name="sameip">
              ��ȫ��¼</td>
          </tr>
          <tr> 
            <td colspan=2 align="center">
<input type="submit" name="do.login" value="��¼" >
              <input type="reset" name="Submit2" value="����">
              <input type="hidden" name="domain" value="<? echo $domain?>">
              <input name="username" type="hidden" id="username"> </td>
          </tr>
        </table>
      </form></td>
    <td width="59"><img src="images/5.jpg" width="59" height="137"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/6.jpg" width="710" height="37"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="382" valign="middle" background="images/bg2.jpg"> 
      <!--
	<table width="76%" border="0">
        <tr> 
          <td width="17%">&nbsp;</td>
          <td width="17%"><font color="#0000FF">POP3</font></td>
          <td width="66%"><font color="#0000FF">pop3.gdfz.com</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><font color="#0000FF">SMTP</font></td>
          <td><font color="#0000FF">smtp.gdfz.com (SMTP��Ҫ��֤)</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><font color="#0000FF">IMAP</font></td>
          <td><font color="#0000FF">imap.gdfz.com</font></td>
        </tr>
      </table>
      <p>kkk</p>
	  -->
      <table width="75%" border="0">
        <tr> 
          <td width="7%">&nbsp;</td>
          <td width="93%" colspan="3"><? echo "<pre>".$domaindetails[description]."</pre>";?></td>
        </tr>
      </table></td>
    <td width="328"><img src="images/7.jpg" width="328" height="240"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/8.jpg" width="710" height="100"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="689"><div align="left"><img src="images/9.jpg" width="686" height="32" border="0" usemap="#Map"></div></td>
  </tr>
</table>
<SCRIPT language=JavaScript>
<!--
	document.logon.user.focus();
//-->
</Script>
<map name="Map">
  <area shape="rect" coords="438,7,596,23" href="http://www.cnwwwcn.com" target="_blank">
</map>
</body>
</html>
