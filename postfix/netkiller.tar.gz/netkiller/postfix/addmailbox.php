<?
	require("../include/global.inc.php");
	$img = "3b.jpg";
?>
<html><!-- InstanceBegin template="/Templates/Common.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<!-- InstanceBeginEditable name="doctitle" -->
<title>��������</title>
<!-- InstanceEndEditable --> <!-- InstanceBeginEditable name="head" -->
<SCRIPT language=JavaScript>
<!--
function Submits()
{
	if(document.mail.user.value == "")
	{
		return alert("�������û���");
	}else if(document.mail.password.value.length < 4 || document.mail.password.length < 4){
		return alert("�û������������ַ�����������û���̫����");
	}else if(document.mail.password.value != document.mail.confirm.value){
		return alert("������������벻ͬ��");
	}
	else{document.mail.submit();}
}
//-->
</Script>
<!-- InstanceEndEditable -->
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="179"><img src="images/1.jpg" width="179" height="64"></td>
    <td width="248" background="images/bg1.jpg">&nbsp;</td>
    <td width="283"><img src="images/2.jpg" width="283" height="64"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><img src="images/<? echo $img?>" width="710" height="41"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="324"><img src="images/4.jpg" width="324" height="137"></td>
    <td width="327" valign="top" bgcolor="DEFEB3"> <!-- InstanceBeginEditable name="EditRegion" -->
<?
//	echo $pfx->getPostmasterQuota("postmaster@9812.net")
//echo $pfx->getPostmasterQuota("test@9812.net");
//echo $pfx->getTotleDomainUserQuota("9812.net");

?>
<?
	//$domain = "gdfz.com";
	//$domain = "meikai-cn.com";
	if(isset($op) && $op =="addmail"){
		if($password == $confirm){
			if(isset($user)){
				$userid = $user."@".$domain;
				//$quota	= "5000000";
				$pfx->register($userid,$user,$password,$domain,$quota);
			}else{
				echo "�û�������Ϊ�գ�";
			}
		}else{
			echo "������������벻ͬ��";
		}
		echo "<a href=''>����</a>";
	}else{
?>
<form name="mail" method="post" action="">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td>�û�</td>
      <td><input type="text" name="user">
        @ <? echo $domain;
			echo "<input name='domain' type='hidden' id='domain' value='$domain'>";
		?> 
        
		</td>
    </tr>
    <tr> 
      <td>����</td>
      <td><input name="password" type="password" id="password"></td>
    </tr>
    <tr> 
      <td>ȷ������</td>
      <td><input name="confirm" type="password" id="confirm"></td>
    </tr>
    <tr> 
      <td>��������</td>
      <td><select name="quota" id="quota">
          <option value="2000000" selected>2M</option>
          <option value="5000000">5M</option>
          <option value="8000000">8M</option>
          <option value="10000000">10M</option>
          <option value="20000000">20M</option>
          <option value="50000000">50M</option>
          <option value="80000000">80M</option>
          <option value="100000000">100M</option>
        </select></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input name="op" type="hidden" id="op2" value="addmail">
        *��������4λ</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="button" name="Submit" value="ȷ��" onClick="Submits()"></td>
    </tr>
  </table>
</form>
<SCRIPT language=JavaScript>
<!--
	document.mail.user.focus();
//-->
</Script>
<? 
	}
?>
<!-- InstanceEndEditable --> </td>
    <td width="59"><img src="images/5.jpg" width="59" height="137"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><img src="images/6.jpg" width="710" height="37"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="382" valign="middle" background="images/bg2.jpg"><!-- InstanceBeginEditable name="Address" -->
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <!-- InstanceEndEditable --></td>
    <td width="328"><img src="images/7.jpg" width="328" height="240"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><img src="images/8.jpg" width="710" height="100"></td>
  </tr>
</table>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="689"><div align="left"><img src="images/9.jpg" width="686" height="32" border="0" usemap="#Map"></div></td>
  </tr>
</table>
<map name="Map">
  <area shape="rect" coords="438,7,596,23" href="http://www.cnwwwcn.com" target="_blank">
</map>
</body>
<!-- InstanceEnd --></html>
