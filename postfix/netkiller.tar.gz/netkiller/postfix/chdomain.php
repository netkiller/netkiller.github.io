<?
session_start(); 
require("../include/global.inc.php");
require("privileges.inc.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�ޱ����ĵ�</title>
</head>

<body>
<?
$domaindetails = $pfx->getDomainDetails($domain);
?>

<form name="form1" method="post" action="postfixadmin.php">
  <table width="75%" border="1">
    <tr> 
      <td>&nbsp;</td>
      <td><input name="ndomain" type="text" id="ndomain" value="<? echo $domaindetails[domain];?>"></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input name="begin" type="text" id="begin" value="<? echo $domaindetails[begin_date];?>"></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input name="end" type="text" id="end" value="<? echo $domaindetails[end_date];?>"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td> <textarea name="desc" cols="50" rows="5" id="desc"><? echo $domaindetails[description];?></textarea>
        <input name="domain" type="hidden" id="domain" value="<? echo $domaindetails[domain];?>">
        <input name="op" type="hidden" id="op" value="chdomain"></td>
      <td>&nbsp;</td>
    </tr>
  </table>

  <p>&nbsp; </p>
  <p> 
    <input type="submit" name="Submit" value="�ύ">
  </p>
</form>
</body>
</html>
