<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>Ⱥ���ʼ�</title>
</head>

<body>
<?
	if($op == "send" && (isset($title) && isset($select) && isset($content))){
		$fp = fopen("/tmp/file.txt", "w");
			fputs($fp,$content);
		fclose($fp);

		$cmd = "/usr/bin/fastmail \"". $title . "\" " . $select ." \"/tmp/file.txt\"";
		//echo $cmd;
		echo system($cmd);
		echo "<script>alert('�ʼ����ͳɹ���')</script>";
	}else if($op == "mailq"){
		$fp = popen("mailq -v", "r");
		    echo "<pre>";
		    while (!feof($fp)) {
            $data = fgets ($fp,1024);
			$data = str_replace("\n", "<br>", $data);
     	    echo $data;
	    }
	    echo "</pre>";
    	pclose ($fp);		
	}else if($op == "length"){
		$fp = popen("mailq|wc -l", "r");
		    echo "<pre>";
		    while (!feof($fp)) {
            $data = fgets ($fp,1024);
			$data = str_replace("\n", "<br>", $data);
     	    echo $data;
	    }
	    echo "</pre>";
    	pclose ($fp);	
	}
?>
<fieldset>
<legend>Ⱥ���ʼ�</legend>
<form name="form1" method="post" action="<? echo $PHP_SELF; ?>">

    <input name="op" type="hidden" id="op" value="send">

  <table width="75%" border="1">
    <tr> 
      <td>���� subject:</td>
      <td><input name="title" type="text" size="50" maxlength="100"></td>
    </tr>
    <tr> 
      <td>Ŀ����� object:</td>
      <td><select name="select">
          <option value="all" selected>�����û�</option>
          <option value="au">au</option>
          <option value="cu">cu</option>
          <option value="ag">ag</option>
          <option value="normal">normal</option>
          <option value="free">free</option>
          <option value="advance">advance</option>
          <option value="��Ӫ��ҵ">��Ӫ��ҵ</option>
          <option value="˽Ӫ��ҵ">˽Ӫ��ҵ</option>
        </select></td>
    </tr>
    <tr> 
      <td>����content: </td>
      <td><textarea name="content" cols="50" rows="10"></textarea></td>
    </tr>
    <tr>
      <td><input type="submit" name="Submit" value="�����ʼ��б�"></td>
      <td>&nbsp;</td>
    </tr>
  </table>

</form>
<p>
<button onclick="location.href='<? echo $PHP_SELF; ?>?op=mailq'">�ʼ��ж�</button>
<button onclick="location.href='<? echo $PHP_SELF; ?>?op=length'">�жӳ���</button>
</p>
</fieldset>

</body>
</html>
