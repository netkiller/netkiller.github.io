<html>
<head>
<title>Site Manager</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="style.css" type="text/css">
<script language=javascript>
function Openwin(url)
{
	window.open(url,'blank','toolbar=0,scrollbars=1');
}
function Messagebox(url,h,w)
{
	window.open(url,'blank','toolbar=0,scrollbars=1,height='+h+' width='+w);
}
</script>
<base target="main">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<div align="center">
  <p><img src="images/logo.gif" width="32" height="32"> </p>
  <table width="100%" border="3" cellspacing="0" cellpadding="5" bgcolor="E0F0FF" class="t02" align="center" bordercolor="4FA7FF" height="0%">
    <tr valign="top"> 
      <td colspan="2" height="52"> 
        <table width="100%" border="1" cellspacing="0" cellpadding="2" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" height="7%">
        <tr> 
          <td> <div align="center"><font size="3" face="System">Site Manager 2.1</font></div></td>
        </tr>
        <tr> 
          <td><a href="filesystem/list.php" target="main">վ�������</a> </td>
        </tr>
        <tr> 
          <td height="18"> <a href="ldap/ldap.php" target="main">OpenLDAP</a></td>
        </tr>
        <tr> 
          <td height="18"> <a href="domain/login.php" target="main">Virtual Domain Name</a></td>
        </tr>
        <tr> 
          <td height="18"> <a href="mysql/" target="main">Mysql User Admin</a></td>
        </tr>
        <tr> 
          <td height="18"><a href="postfix/postfixadmin.php">Postfix Admin</a></td>
        </tr>
        <tr> 
          <td height="18"><a href="endes.php" target="main">����/���빤��</a></td>
        </tr>
        <tr>
          <td height="18"><a href="ftp/login.php">WebFtpClient</a></td>
        </tr>
        <tr> 
          <td height="18"><a href="webmail/index.php">Bug Report</a></td>
        </tr>
        <tr> 
          <td height="18"><a href="docs/readme.html">ʹ�ð���</a></td>
        </tr>
        <tr> 
          <td height="18">&nbsp;</td>
        </tr>
        <tr> 
          <td height="18">ICQ��101888222</td>
        </tr>
        <tr> 
          <td height="18">OICQ��13721218</td>
        </tr>
        <tr> 
          <td height="18">netkiller@9812.net</td>
        </tr>
      </table>
      </td>
    </tr>
  </table>
<!--  
<table border='0' cellspacing='0' cellpadding='0' width='200'><tr><td align='center' style='background-color: #E0ECE2; border-top: 1px solid Black; border-left: 1px solid Black; border-right: 1px solid Black;'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold;'>Netkiller <img src='http://web.icq.com/whitepages/online?icq=101888222&img=5' border='0' width='18' height='18' align='absmiddle'> 101888222</span></td></tr><tr><td><a href='http://go.icq.com' target='icq2go'><img src='http://public.icq.com/public/panels/icq2go/images/start_button2.gif' width='200' height='38' border='0'></a><br><a href='http://web.icq.com/whitepages/add_me?uin=101888222&action=add'><img src='http://public.icq.com/public/panels/icq2go/images/add.gif' width='100' height='32' border='0'></a><a href='http://web.icq.com/whitepages/about_me?Uin=101888222' target='icq2go'><img src='http://public.icq.com/public/panels/icq2go/images/about.gif' width='100' height='32' border='0'></a><br><a href='http://web.icq.com/whitepages/message_me?uin=101888222&action=message'><img src='http://public.icq.com/public/panels/icq2go/images/message.gif' width='100' height='30' border='0'></a><a href='http://web.icq.com/wwp?Uin=101888222#pager' target='icq2go'><img src='http://public.icq.com/public/panels/icq2go/images/page.gif' width='100' height='30' border='0'></a><br></td></tr>
  <tr> 
    <td align='center'>&nbsp;</td>
</tr>
</table>
-->
</body>
</html>
