<?
session_start();
//session_register("ldaprecord");
//session_register("newinfo");
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<? 
$LDAProotpw = base64_decode($LDAProotpw);
//echo $LDAProotpw;
//echo $ldapadddn;
require("../include/ldap.inc.php");
require('../function.php');


if(!$ldapadddn && $key0){
	$ldapadddn = $key0."=".$var0.",".$LDAPDNInfo;
}

if($LDAPAction == "Add"){
	$ldapencode = new ldap;
	$QueryCount = count($HTTP_POST_VARS);
	for ($i=0;$i<$QueryCount;$i++){

		$key = $HTTP_POST_VARS["key".$i];
		$var = $HTTP_POST_VARS["var".$i];		
		if(!$key)break;
		//echo $i. " " .$key."|".$var."<br>";
		switch($key){
			case "dn":
				$newinfo[$key] = base64_encode($ldapencode->gb18030_utf8($var));
				break;
			default:
				$newinfo[$key] = $ldapencode->get_utf_value($key,$var);
		}
	}
/*	
	while (list($key,$var) = each($newinfo)){
		echo $i. " " .$key."|".$var."<br>";
		$i++;
	}
*/	
	$ds=ldap_connect($LDAPServer);  // ���� LDAP ������	l
	if ($ds) {
		$r=ldap_bind($ds,$LDAProotdn , $LDAProotpw);// ϵסǡ���� dn
		$isSuccess=@ldap_add($ds, $ldapadddn , $newinfo);
		if(!$isSuccess){
			echo "<strong>������Ŀʧ�ܣ�</strong>";
		}
		$newinfo = null;		
  		ldap_close($ds);
	} else {
  		echo "��Ǹ���޷����� LDAP ��������"; 
	}


}
?>
<form action="<?echo $PHP_SELF?>" method=post name="ldapadd" id="ldapadd">
  <input type="hidden" name="LDAPServer" value="<?echo $LDAPServer?>">
    <input type="hidden" name="LDAPSearch" value="<?echo $LDAPSearch?>">
    <input type="hidden" name="LDAPDNInfo" value="<?echo $LDAPDNInfo?>">
    <input type="hidden" name="LDAProotdn" value="<?echo $LDAProotdn?>">
    <input type="hidden" name="LDAProotpw" value="<?echo base64_encode($LDAProotpw)?>"> 
    <input type="hidden" name="LDAPAction" value="<?echo $LDAPAction?>"></p>
  <input name="Schema" type="hidden" id="Schema" value="none">
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="2" bgcolor="#333399" height="17"><font color="#FFFFFF">���� DN 
        : <?echo $LDAPDNInfo?> </font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td colspan="2" height="17"> DN : 
        <input name="ldapadddn" type="text" id="dn" value="<?echo $ldapadddn?>" size="50"></td>
    </tr>	
<!--	
	<tr bgcolor='#CCCCCC'>
		<td><input type='text' name='key0' value='objectclass'></td>
		<td><input type='text' name='var0' value='<?echo $var0?>'></td>
	</tr>
-->	
<?
if($Schema == "none"){
//�Զ�������
	$newinfo = array();
	$QueryCount = count($HTTP_POST_VARS);
	if($LDAPAction == "AddAttributeAndValue"){
		for ($i=0;$i<$QueryCount;$i++){
			$key = $HTTP_POST_VARS["key".$i];
			$var = $HTTP_POST_VARS["var".$i];		
			if(!$key)break;
			//echo $i. " " .$key."|".$var."<br>";		
			$newinfo[$key] = $var;		
		}
		$newinfo[$Attribute] = $Value;	
	}else if($LDAPAction == "DelAttributeAndValue"){
		for ($i=0;$i<$QueryCount;$i++){
			$key = $HTTP_POST_VARS["key".$i];
			$var = $HTTP_POST_VARS["var".$i];		
			if(!$key)break;
			if($key == $Attribute)continue;
			$newinfo[$key] = $var;		
		}
	}
	if(isset($LDAPAction)){
	$i=0;
	while (list($key,$var) = each($newinfo)){
		echo "<tr bgcolor='#CCCCCC'>";
    	echo "  <td>&nbsp;<input type='text' name='key$i' value='$key'></td>";
	    echo "  <td><input type='text' name='var$i' value='$var' size='50'>";
		echo "      <input type='button' name='Submit2' value='��' onClick=\"ldapDelAttribute('$key')\"> <input type='button' name='setkey' value='��' onClick=\"ldapadddn.value =ldapadd.key$i.value+ '=' +ldapadd.var$i.value+','+'$LDAPDNInfo'\"></td>";
	    echo "</tr>";
		$i++;
	}
	}
}else{
		$ldapSchema = new ldap;
		for($i=0;$i<count($ldapSchema->ldapTemplates[$Schema]["Attribute"]);$i++){
			$key = $ldapSchema->ldapTemplates[$Schema]["Attribute"][$i];
			$var = $ldapSchema->ldapTemplates[$Schema]["Value"][$i];
			echo "<tr bgcolor='#CCCCCC'>";
		   	echo "  <td>&nbsp;<input type='text' name='key$i' value='$key'></td>";
	    	echo "  <td><input type='text' name='var$i' value='$var' size='50'>";
			echo "      <input type='button' name='Submit2' value='��' onClick=\"ldapDelAttribute('$key')\"> <input type='button' name='setkey' value='��' onClick=\"ldapadddn.value =ldapadd.key$i.value+ '=' +ldapadd.var$i.value+','+'$LDAPDNInfo'\"></td>";
			echo "</tr>";
		}
}

?>		
    <tr bgcolor="#CCCCCC"> 
      <td width="20%" >&nbsp;<input name="Attribute" type="text" id="Attribute2"></td>
      <td width="77%" > 
        <input name="Value" type="text" id="Value" size="50">
        <input type="button" name="Submit2" value="��" onClick="ldapAddAttribute()"> </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">&nbsp; </td>
      <td height="2">&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2" bgcolor="#333399" height="2"> <div align="center"> 
          <input type="button" name="Button" value=" �� �� " onClick="ldapAdd()">
          &nbsp; 
          <input type="button" name="Button" value=" �� �� " onClick="ldapAddBack()">
        </div></td>
    </tr>
  </table>
  
  <p>&nbsp; </p>
</form>
  

</body>
</html>
