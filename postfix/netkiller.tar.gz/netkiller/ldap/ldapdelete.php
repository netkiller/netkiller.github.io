<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<?
	$deletedn = urldecode($dn);
?>
<form method=post action="<?echo $PHP_SELF?>">
<p>&nbsp;</p>
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="2" bgcolor="#333399" height="17"><font color="#FFFFFF">DES���빤��: 
        <?echo $deletedn?> </font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td width="15%" height="2" align="center">���룺</td>
      <td width="85%" height="2"> 
        <input name=passwd type=text size=20> </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center"> DES����</td>
      <td height="2"> 
<?php
/*
$ds=ldap_connect("localhost");  // ���� LDAP ������
if ($ds) {
  // ϵסǡ���� dn
  $r=ldap_bind($ds,"cn=manager,dc=xuser,dc=net", "secret");
  // Ԥ��׼��������Ŀ������
  $isSuccess=ldap_delete($ds, "uid=chen,dc=xuser,dc=net");
	if($isSuccess){
		echo "ɾ���ɹ�";
	}else{
		echo "δɾ��";
	}
  ldap_close($ds);
} else {
  echo "��Ǹ���޷����� LDAP ��������"; 
}
*/
?> 
      </td>
    </tr>
    <tr> 
      <td colspan="2" bgcolor="#333399" height="2"> <div align="center"> 
          <input type="submit" name="Submit" value="Submit">
        </div></td>
    </tr>
  </table>
  <p>&nbsp; </p>
</form>
<script>
//history.back();
location.href = ldap.php;
</script>
</body>
</html>
