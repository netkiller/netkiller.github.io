<?
	session_start(); 
	session_register("info"); 
	session_register("isBind"); 
	require('../include/function.php');
	require("../include/ldap.inc.php");
	$LDAProotpw = base64_decode($LDAProotpw);	
?>
<html>
<head>
<title>OpenLDAP</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="5" topmargin="5">

<form name="ldap" method="post" action="<?echo $PHP_SELF?>">
<table width="100%" border="0">
  <tr bgcolor="#333399"> 
    <td><a name="TOP"><b><font size="4" color="#FFFFFF" face="System"><a href="http://www.9812.net" class="wlink">Site 
      Manager - OpenLDAP</a></font></b></a></td>
    <td>
      <div align="right"><a href="telnet://<?echo $REMOTE_ADDR;?>"><font color=white><b><?echo $REMOTE_ADDR;?></b></font></a></div>
    </td>
  </tr>
</table>

  LDAP������ 
  <input name="LDAPServer" type="text" id="LDAPServer" value="<?echo $LDAPServer?>" size="15">
  Search 
  <input name="LDAPSearch" type="text" id="LDAPSearch" value="<?echo $LDAPSearch?>">
  DN 
  <input name="LDAPDNInfo" type="text" id="LDAPDNInfo" value="<?echo $LDAPDNInfo?>">
  <input type="submit" name="Submit" value=" �� �� "><br>
  <?
if($LDAProotdn){
	$isBind=True;
}else{
	$isBind=False;
}

if($LDAPAction == "Modify"){
	$ldapencode = new ldap;	
	$QueryCount = count($HTTP_POST_VARS);
	for( $intIndex = 0 ; list( $key, $val ) = each( $HTTP_POST_VARS ); $intIndex++ ){//$intIndex < sizeof($newinfo)
		if($intIndex > 6 && $intIndex < $QueryCount-1){
		//echo $key."=".$val."<br>";
		$newinfo[$key] = $ldapencode->get_utf_value($key,$val);
		}
	}
/*	
	while ( list( $key, $val ) = each( $newinfo ) ) {
		echo "$key => $val<br>";
	}
*/
}

$ds=ldap_connect($LDAPServer);  // ��������Ч�� LDAP ������
if ($ds) { 

	$ldapbind=@ldap_bind($ds,$LDAProotdn,$LDAProotpw);          // ������ bind��Ϊֻ������
	if(!$ldapbind){
		echo "<strong>�󶨳�����rootdn��rootpw����ȷ���˴β�ѯΪ������ bind</strong>";
		$isBind = False;
	}
	// LDAP Modify
	if($LDAPAction == "Modify"){
		ldap_modify($ds, $LDAPModifyDn , $newinfo);
	}

	// LDAP Delete
	if($dn && $isBind){
		$dn = base64_decode($dn);
		$isSuccess=ldap_delete($ds, $dn);
		if($isSuccess){
			echo "$dn �Ѿ�ɾ��";
		}else{
			echo "$dn δ��ɾ��";
		}
	}
	
    $sr=@ldap_search($ds,$LDAPDNInfo, $LDAPSearch);  
	$LDAPCount = @ldap_count_entries($ds,$sr);
	
	$entry = @ldap_first_entry($ds, $sr);
	if($entry){
		$attrs = @ldap_get_attributes($ds, $entry);
		$LDAPAttrsCount = $attrs["count"];
	}else{
		$LDAPAttrsCount = 0;
		echo "<p><strong>��Ŀ�����ڣ�</strong>";
	}
    $info = @ldap_get_entries($ds, $sr);

	if($checkbox) {
?>
<br>
  <?php
	//echo ldap_first_entry($ds, $sr);
	//echo ldap_next_entry($ds, ldap_first_entry($ds, $sr));	
	
    for ($i=0; $i<$info["count"]; $i++) {
		$LDAPDN = $info[$i]["dn"];
		echo "# " . $LDAPDN ."<br>";		
		//echo "#-----------------------------------<br>";		
		echo "dn : " . $LDAPDN ."<br>";		
		for($j=0;$j<$info[$i]["count"];$j++){
			$Att = $info[$i][$j];
			$Value = $info[$i][$Att][0];//[$j];
			echo "  ". $Att ."	:	" . $Value ."<br>";
		}
		echo "<p>";
    }
?>
  <?	}else{?>
  <table width="100%" border="0">
    
    <tr bgcolor="#aaaaaa"> 
      <td width="7%" height="2" align="center" bgcolor="#aaaaaa">���</td>
      <td width="71%" align="center" bgcolor="#aaaaaa">LDAPDN</td>
	  <?
		if($isBind){
	   		echo "<td width='22%' height='2' colspan='2' align='center'>����</td>";
		}
	  ?>	  
    </tr>
    <?

    for ($i=0; $i<$info["count"]; $i++) {
	$LDAPDN = $info[$i]["dn"];
	$EncodeStr=urlencode($LDAPDN);
	$Base64code = base64_encode($LDAPDN);
	//echo $Base64code;
	echo "<tr bgcolor=#cccccc> ";
    echo "  <td align='center'>".($i+1)."</td>";
    echo "  <td align='left'><a href='ldapdetails.php?dn=".$EncodeStr."' target=details>". $LDAPDN ."&nbsp;<a></td>";
	if($isBind){
	    echo "  <td align='center'><a href=\"javascript:ldapModify('$Base64code')\">�޸�<a></td>";
    	echo "  <td align='center'><a href=\"javascript:MessageDelete('$Base64code')\">ɾ��<a></td>";
	}
    echo "</tr>";
	if(!($info["count"]==1 || ($i+1)==$info["count"])){
	$i++;
	$LDAPDN = $info[$i]["dn"];
	$EncodeStr=urlencode($LDAPDN);
	$Base64code = base64_encode($LDAPDN);	
    echo "<tr bgcolor=#eeeeee> ";
    echo "  <td align='center'>".($i+1)."</td>";	
//    echo "  <td align='left'>". $LDAPDN ."&nbsp;</td>";
    echo "  <td align='left'><a href='ldapdetails.php?dn=".$EncodeStr."' target=details>". $LDAPDN ."&nbsp;<a></td>";
	if($isBind){
	    echo "  <td align='center'><a href=\"javascript:ldapModify('$Base64code')\">�޸�<a></td>";
    	echo "  <td align='center'><a href=\"javascript:MessageDelete('$Base64code')\">ɾ��<a></td>";
	}
    echo "</tr>";
	}
    }
	?>
  </table>
  <?
	}
ldap_close($ds);
} else {
   	echo "<h4>�޷����ӵ� LDAP ������</h4>";
}

?></p>
  <table width="100%" border="1" bordercolor="#99CCFF">
    <tr bgcolor=#FFFFFF> 
      <td height="26" align="center">Search 
        <select name="select" onChange="ldap.LDAPSearch.value = this.options[this.selectedIndex].value+'=*';" >
          <?
		echo "<option selected value=".$attrs[0].">".$attrs[0]."</option>";
		for ($i=1; $i<$attrs["count"]; $i++) {
			echo "<option value='".$attrs[$i]."'>".$attrs[$i]."</option>";
		}
?>
        </select>
      </td>
      <td align="center"><input type="checkbox" name="checkbox" value="false" onClick="this.value=true">
        ���� ldif </td>
    </tr>
    <tr bgcolor=#FFFFFF> 
      <td align="center"> rootdn 
        <input name="LDAProotdn" type="text" id="LDAProotdn" value="<? echo $LDAProotdn?>" size="40"></td>
      <td align="center">rootpw 
        <input name="rootpw" type="password" id="rootpw" onclick="this.value=''" value="<?echo $rootpw?>">
        <input name="LDAProotpw" type="hidden" id="LDAProotpw" value="<? if($rootpw)echo base64_encode($rootpw); else echo base64_encode($LDAProotpw)?>"></td>
    </tr>
  </table>
    
  <div align="center">
  	<?if($isBind && $ds){?>
    <select name="Schema" id="Schema">
      <option value="none" selected>�Զ���...</option>
      <option value="person">person</option>
      <option value="organizationalUnit">ou</option>
      <option value="Outlook">Outlook</option>
      <option value="ProFTPD">ProFTPD</option>
      <option value="PureFTPD">PureFTPD</option>
      <option value="Qmail">Qmail</option>
      <option value="Postfix">Postfix</option>
      <option value="Samba">Samba</option>
    </select>
    <input type="button" name="Submit3" value=" �� �� " onclick="ldapAddForm()">
	<?}?>
    &nbsp; 
    <input name="LDAPBind" type="submit" id="LDAPBind" value=" �� �� " onclick="if(LDAProotdn.value==''){alert('����дrootdn��rootpw����\nrootdn:cn=mananger,'+LDAPDNInfo.value+'\nrootpw:secret');LDAProotdn.value='cn=manager,'+LDAPDNInfo.value;rootpw.value='secret'}">
  </div>
  <table width="100%" border="0">
  <tr bgcolor="#333399"> 
      <td>
	  <a href="#TOP">
	  <font color="#FFFFFF">�� TOP ��</font>
	  </a>
	  <?echo "<a href=ldap://$LDAPServer/$LDAPDNInfo??sub?(&$LDAPSearch)><font color=#FFFFFF>�� ldap://$LDAPServer/$LDAPDNInfo ��</font></a>" ?>
	  </td>
  </tr>
</table>
</form>
  <!--    Html End              -->
</p>
<table width="100%" border="3" cellspacing="0" cellpadding="5" bgcolor="E0F0FF" class="t02" align="center" bordercolor="4FA7FF" height="0%">
  <tr valign="top"> 
    <td colspan="2" height="52"> <table width="100%" border="1" cellspacing="0" cellpadding="0" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" height="7%">
        <tr> 
          <td colspan="8"> <div align="center">��ǰͳ�� </div></td>
        </tr>
        <tr> 
          <td width="15%" height="2">LDAP������</td>
          <td width="16%" height="2"> <?echo $LDAPServer?> &nbsp;</td>
          <td rowspan="4" width="2%">&nbsp; </td>
          <td width="18%" height="2">Search</td>
          <td width="14%" height="2"><?echo $LDAPSearch?> &nbsp;</td>
          <td rowspan="4" width="2%">&nbsp;</td>
          <td width="14%" height="2">DN</td>
          <td width="19%" height="2"> <?echo $LDAPDNInfo?> &nbsp;</td>
        </tr>
        <tr> 
          <td width="15%" height="2">���</td>
          <td width="16%" height="2"> <?echo $ds?> &nbsp;</td>
          <td width="18%" height="2">���ر���</td>
          <td width="14%" height="2"><? echo $LDAPCount ?> &nbsp;</td>
          <td width="14%" height="2">����</td>
          <td width="19%" height="2"> <?echo $LDAPAttrsCount?> &nbsp;</td>
        </tr>
        <tr> 
          <td width="15%">Bind���</td>
          <td width="16%"> <?echo $ldapbind?> &nbsp;</td>
          <td width="18%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
          <td width="19%">&nbsp;</td>
        </tr>
        <tr> 
          <td width="15%" height="2">Search���</td>
          <td width="16%" height="2"><?echo $sr?> &nbsp;</td>
          <td width="18%" height="2">&nbsp;</td>
          <td width="14%" height="2">&nbsp; </td>
          <td width="14%" height="2">&nbsp;</td>
          <td width="19%" height="2">&nbsp;</td>
        </tr>
        <tr> 
          <td colspan="8">&nbsp; </td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
<?exit;?>
