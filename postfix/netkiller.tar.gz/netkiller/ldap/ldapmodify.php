<?
	session_start(); 
	session_register("info"); 
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<?
require("../include/ldap.inc.php");
	//$ldap_dn = urldecode($dn);
	$ldap_dn = base64_decode($dn);
	$LDAProotpw = base64_decode($LDAProotpw);
	$ldapencode = new ldap;
	
?>

<form method=post action="ldap.php">
  <input type="hidden" name="LDAPServer" value="<?echo $LDAPServer?>">
  <input type="hidden" name="LDAPSearch" value="<?echo $LDAPSearch?>">
  <input type="hidden" name="LDAPDNInfo" value="<?echo $LDAPDNInfo?>">
  <input type="hidden" name="LDAProotdn" value="<?echo $LDAProotdn?>">
  <input type="hidden" name="LDAProotpw" value="<?echo base64_encode($LDAProotpw)?>"> 
  <input type="hidden" name="LDAPAction" value="Modify"> 
  <input type="hidden" name="LDAPModifyDn" value="<?echo $ldap_dn?>">    

  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="2" bgcolor="#333399" height="17"><font color="#FFFFFF">�޸� </font><font color="#FFFFFF">DN 
        : <?echo $ldap_dn?> </font></td>
	  </tr>
	<?

    for ($i=0; $i<$info["count"]; $i++) {
		$LDAPDN = $info[$i]["dn"];
		if($LDAPDN==$ldap_dn){
			for($j=0;$j<$info[$i]["count"];$j++){
				$Attribute = $info[$i][$j];
				$Value = $ldapencode->get_gb_value($Attribute,$info[$i][$Attribute][0]);
	 			echo "<tr bgcolor=#eeeeee> ";
			    echo "<td>$Attribute</td>";
      			echo "<td><input type=text name='$Attribute' value='$Value' size='50'> </td>";
				echo "</tr>";
			}
		}			
    }
	?>

    <tr> 
      <td colspan="2" bgcolor="#333399" height="2"> <div align="center"> 
          <input type="submit" name="Submit" value=" �� �� ">
        </div></td>
    </tr>
  </table>
</form>
</body>
</html>
