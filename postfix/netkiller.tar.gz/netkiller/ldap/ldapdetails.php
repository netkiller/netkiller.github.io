<?
	session_start(); 
	session_register("info"); 
	require('../function.php');
	
	$urldn = urldecode($dn);
	$DecodeStr = $urldn;	
?>
<html>
<head>
<title>LDAP - <?echo $DecodeStr?></title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<?
require("../include/ldap.inc.php");
	$ldapencode = new ldap;
    for ($i=0; $i<$info["count"]; $i++) {
		$LDAPDN = $info[$i]["dn"];
		if($LDAPDN==$urldn){
			for($j=0;$j<$info[$i]["count"];$j++){
				$Atts[$j] = $info[$i][$j];
				$Values[$j] = $ldapencode->get_gb_value($Atts[$j],$info[$i][$Atts[$j]][0]);
			}
		}			
    }
	$colspan = $j;
?>
<form method=post action="<?echo $PHP_SELF?>">
<p>&nbsp;</p>
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="<?echo $colspan?>" bgcolor="#333399" ><font color="#FFFFFF">��ϸ 
        DN: <?echo $urldn?> </font></td>
    </tr>
    <?php
		
			echo "<tr bgcolor=#CCCCCC>";
			for($i=0;$i<count($Atts);$i++){
	    		echo "  <td align=center>$Atts[$i]</td>";				
			}
	    	echo "</tr>";
			
			echo "<tr bgcolor=#EEEEEE>";
			for($i=0;$i<count($Values);$i++){
    			echo "  <td align=center>$Values[$i]</td>";				
			}
    		echo "</tr>";		
?>
	<tr> 
      <td height="2" colspan="<?echo $colspan?>" align="center" bgcolor="#333399"><font color="#FFFFFF" onClick="self.close()" class="hand">���رմ��ڡ�</font></td>
    </tr>
  </table>
  <p>&nbsp; </p>
</form>
<?
/*
    for ($i=0; $i<$info["count"]; $i++) {
		$LDAPDN = $info[$i]["dn"];
		if($LDAPDN==$urldn){
			for($j=0;$j<$info[$i]["count"];$j++){
				$Atts[$j] = $info[$i]["objectclass"][$j];
				$Values[$j] = $info[$i][$Atts[$j]][0];
				echo "$Atts[$j] | $Values[$j] <br>";
			}
		}			
    }
*/	
?>
</body>
</html>
