<?php
include ("include/global.php");
if(!$Online){
header("location:error.php");
}
?>
<html>
<head>
<title>�������б�</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="domain.css" type="text/css">
</head>

<body bgcolor="#D0DCE0" text="#000000">
<div align="center"> 
  <p><img src="images/logo.gif" width="32" height="32"> <br>
<?php
if($Addvirtualdomain){
	$VD->AddDomains($OnlineUser,$Addvirtualdomain);
}
?>
  </p>
</div>
<table border=1 bordercolor=#333333 style='HEIGHT: 29px; WIDTH:100%'>
  <tr> 
    <td> 
      <div align="center"><b><font color="#0000FF"> 
        <?echo $virtualdomain;?>
        </font></b></div>
    </td>
  </tr>
  <?php $VD->ShowOwnerDomain($OnlineUser,$Addvirtualdomain);?>
  <tr> 
    <td><a href="total.php" target="mainFrame"><b>������Ϣ</b></a></td>
  </tr>
  <tr>
    <td>      <div align="center"><a href="logout.php" target="_parent"> <b>
        <?echo $logout?>
        </b> </a></div></td>
  </tr>
</table>
</body>
</html>
