<?include ("include/global.php");?>
<html>
<head>
<title>������Ч</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body bgcolor="#D0DCE0" text="#000000">
<?php
echo $Virtualdomain;
	if($Password==$Confirm){
	$VD->register_save($Username,$Password,$Realname,$Email,$Virtualdomain,$Url);
	if($freeback){
		echo $freeback;
	}
	}else{
		echo "������������벻һ����<a href='#' onclick='javascript:history.go(-1)'>����</a>";
	}
	$VD->showcopyright();
?>
</body>
</html>
