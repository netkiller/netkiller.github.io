<?include ("include/global.php");?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body bgcolor="#FFFFFF" text="#000000" background="../images/home_34_06.gif">
<table align=center border=0 cellpadding=0 cellspacing=0 width=89% height="158">
  <tbody> 
  <tr> 
    <td height="2" width="0%"><img src="../images/conner_01.gif"></td>
    <td background="../images/conner_02.gif" height="2" width="98%"><img alt=../images/conner_02.gif 
      src="../images/conner_02.gif" width="138" height="11"></td>
    <td height="2" width="2%"><img src="../images/conner_03.gif"></td>
  </tr>
  <tr> 
    <td background="../images/conner_04.gif" height="150" width="0%">&nbsp;</td>
    <td height="150" valign="middle" width="98%">       <div align="center"> 
      <?
$VirtualDomain =	$Vdomain;
$Vdomain=$VD->DomainStrReplace($Vdomain);
if($VD->check_host($Host,$Vdomain)){
?>

        <p><font face=Wingdings size=5 color=red>L</font><font color="#FF0000">�Բ��������Դ���!</font> 
          <?
}else{
?>
          <font face=Wingdings size=5 color=red>J</font><font color="#FF0000"></font><font color="#FF0000">��ϲ���ˣ���������ûע��</font> 
		          
        <form name="register" method="post" action="register.php">
          <input type="hidden" name="Host" value="<?echo $Host?>">
          <input type="hidden" name="VirtualDomain" value="<?echo $VirtualDomain?>">
          <input type="submit" name="Submit" value="��ͬ��">
          <input type="button" name="Submit2" value="��ͬ��" onclick='history.back();'>
        </form>
          <?
          echo $VirtualDomain;
}
?>
          <br>
          <br>
          <br>
        9812.net��������ע���������
<p>1.����������������</p>
        <p>2.������ɫ�飬����</p>
      </div>
    </td>
    <td background="../images/conner_06.gif" height="150" width="2%">&nbsp;</td>
  </tr>
  <tr>
    <td background="../images/conner_04.gif" width="0%">&nbsp;</td>
    <td width="98%"> 
      <div align="center"></div>
    </td>
    <td background="../images/conner_06.gif" width="2%">&nbsp;</td>
  </tr>
  <tr> 
    <td width="0%"><img src="../images/conner_07.gif"></td>
    <td background="../images/conner_08.gif" width="98%"><img alt=../images/conner_08.gif 
      src="../images/conner_08.gif" width="138" height="12"></td>
    <td width="2%"><img 
src="../images/conner_09.gif"></td>
  </tr>
  </tbody> 
</table>

<div align="center"><?echo $copyright; ?></div>
</body>
</html>
