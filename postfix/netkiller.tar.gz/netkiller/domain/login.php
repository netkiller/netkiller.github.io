<?
//include ("include/global.php");
session_start(); 
session_register("Online"); 
session_register("OnlineUser");
$Online=false;

if(PHP_OS != "WINNT" || $Online==false){
	header("Location: validate.php?op=http");
}
?>
?>
<html>
<head>
<title>ע����������</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<META HTTP-EQUIV="pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate">
<META HTTP-EQUIV="expires" CONTENT="0">
</head>

<body bgcolor="#D0DCE0" text="#000000">
<div align="center"><a href="http://www.9812.net"><img src="<?echo $Banner;?>" border="0"></a> 
</div>
<? 
if(PHP_OS=="WINNT"){
?>
<form name="domain" method="post" action="validate.php" target="_parent">
  <table border="0" align="center" width="50%">
    <tr> 
      <td width="184"> 
        <?echo $username; ?>
        : </td>
      <td width="308"> 
        <input type="text" name="Username" maxlength="10">
      </td>
    </tr>
    <tr> 
      <td width="184"> 
        <?echo $password; ?>
        :</td>
      <td width="308"> 
        <input type="password" name="Password">
      </td>
    </tr>
    <tr> 
      <td colspan="2"> 
        <div align="center"> 
          <input type="submit" name="Submit" value=" ��¼ ϵͳ ">
          <input type="reset" name="Submit2" value="�Ժ���˵��">
        </div>
      </td>
    </tr>
  </table>
  </form>
<?}?>

<?echo $copyright; ?>
</body>
</html>
