<?include ("include/global.php");?>
<html>
<head>
<title>Banner</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="domain.css" type="text/css">
</head>

<body bgcolor="#F5F5F5" text="#000000">
<div align="center"><a href="http://www.9812.net" target="_parent"><img src="<?echo $Banner;?>" border="0"></a> 
</div>
</body>
</html>
