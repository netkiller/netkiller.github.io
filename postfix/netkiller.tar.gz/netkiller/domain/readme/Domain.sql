# phpMyAdmin MySQL-Dump
# http://phpwizard.net/phpMyAdmin/
#
# Host: localhost Database : domain

# --------------------------------------------------------
#
# Table structure for table '9812_net'
#

DROP TABLE IF EXISTS 9812_net;
CREATE TABLE 9812_net (
   ID int(10) unsigned NOT NULL auto_increment,
   Host varchar(20) DEFAULT '0' NOT NULL,
   Url varchar(255) DEFAULT '9812.net' NOT NULL,
   Owner varchar(10) DEFAULT '9812.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   KEY TD (ID, Host)
);

#
# Dumping data for table '9812_net'
#

INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '1', 'netkiller', 'http://www.9812.net', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '2', 'bbs', 'http://www.9812.net/bbs', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '3', 'pic', 'http://www.9812.net/picture', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '4', 'telnet', 'telnet://www.9812.net', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '5', 'gb', 'http://www.9812.net/cutebook', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '6', 'count', 'http://', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '7', 'dns', 'http://www.9812.net/domain', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '8', 'domain', 'http://www.9812.net/domain', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '9', 'linux', 'http://www.kdeopen.com', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '10', 'freebsd', 'http://', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '11', 'mysql', 'http://www.9812.net/phpMyAdmin', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '12', 'phpMyAdmin', 'http://www.9812.net/phpMyAdmin', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '13', 'news', 'http://', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '14', 'admin', 'http://www.9812.net/manager', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '15', 'webmail', 'http://www.9812.net/squirrelmail', 'netkiller');
INSERT INTO 9812_net (ID, Host, Url, Owner) VALUES ( '16', 'freemail', 'http://www.9812.net/squirrelmail', 'netkiller');

# --------------------------------------------------------
#
# Table structure for table 'domainuser'
#

DROP TABLE IF EXISTS domainuser;
CREATE TABLE domainuser (
   ID int(10) unsigned NOT NULL auto_increment,
   UserName varchar(10) binary DEFAULT '0' NOT NULL,
   Password varchar(50) binary DEFAULT '0' NOT NULL,
   RealName varchar(10) DEFAULT '0' NOT NULL,
   Email varchar(40) DEFAULT '0' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID,UserName),
   KEY DU (UserName,Password)
);

#
# Dumping data for table 'domainuser'
#

INSERT INTO domainuser (ID, UserName, Password, RealName, Email) VALUES ( '1', 'netkiller', 'a1a8887793acfc199182a649e905daab', '�¾���', 'netkiller@9812.net');

# --------------------------------------------------------
#
# Table structure for table 'ownerdomain'
#

DROP TABLE IF EXISTS ownerdomain;
CREATE TABLE ownerdomain (
   ID int(10) unsigned NOT NULL auto_increment,
   UserName varchar(10) DEFAULT '0' NOT NULL,
   VirtualDomain varchar(20) DEFAULT '9812.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   KEY OD (ID, UserName)
);

#
# Dumping data for table 'ownerdomain'
#

INSERT INTO ownerdomain (ID, UserName, VirtualDomain) VALUES ( '1', 'netkiller', '9812.net');

# --------------------------------------------------------
#
# Table structure for table 'virtualdomain'
#

DROP TABLE IF EXISTS virtualdomain;
CREATE TABLE virtualdomain (
   ID int(10) unsigned NOT NULL auto_increment,
   VirtualDomain varchar(20) DEFAULT '9812.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   KEY VD (ID, VirtualDomain)
);

#
# Dumping data for table 'virtualdomain'
#

INSERT INTO virtualdomain (ID, VirtualDomain) VALUES ( '1', '9812.net');

# --------------------------------------------------------
#
# Table structure for table 'xuser_net'
#

DROP TABLE IF EXISTS xuser_net;
CREATE TABLE xuser_net (
   ID int(10) unsigned NOT NULL auto_increment,
   Host varchar(20) DEFAULT '0' NOT NULL,
   Url varchar(50) DEFAULT 'xuser.net' NOT NULL,
   Owner varchar(10) DEFAULT 'xuser.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   KEY TD (ID, Host)
);

#
# Dumping data for table 'xuser_net'
#

INSERT INTO xuser_net (ID, Host, Url, Owner) VALUES ( '4', 'bbs', 'http://', 'net');
INSERT INTO xuser_net (ID, Host, Url, Owner) VALUES ( '2', 'wsui', 'http://', 'netkiller');
INSERT INTO xuser_net (ID, Host, Url, Owner) VALUES ( '3', 'netkiller', 'http://', 'netkiller');
INSERT INTO xuser_net (ID, Host, Url, Owner) VALUES ( '6', 'net', 'http://', 'net');
