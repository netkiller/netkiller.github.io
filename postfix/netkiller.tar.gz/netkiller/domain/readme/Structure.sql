# ���ݿ� domain
#
# ����: localhost ���ݿ� : domain
# Create Database;

GRANT ALL PRIVILEGES
           ON domain.*
           TO domain@localhost
           IDENTIFIED BY 'Virtual';

GRANT SELECT
           ON domain.*
           TO HostSearch@localhost
           IDENTIFIED BY 'VHostSearch';

FLUSH PRIVILEGES;

# --------------------------------------------------------
#
# ���ݱ��Ľṹ 'domainuser'
#

DROP TABLE IF EXISTS DomainUser;
CREATE TABLE DomainUser (
   ID int(10) UNSIGNED NOT NULL auto_increment,
   UserName	varchar(10) binary DEFAULT '0' NOT NULL,
   Password	varchar(50) binary DEFAULT '0' NOT NULL,
   RealName	varchar(10) DEFAULT '0' NOT NULL,
   Email	varchar(40) DEFAULT '0' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   INDEX DU (UserName,Password)
);


# --------------------------------------------------------
#
# ���ݱ��Ľṹ 'virtualdomain'
#

DROP TABLE IF EXISTS VirtualDomain;
CREATE TABLE VirtualDomain (
   ID int(10) UNSIGNED NOT NULL auto_increment,
   VirtualDomain varchar(20) DEFAULT '9812.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   INDEX VD (ID,VirtualDomain)
);


# --------------------------------------------------------
#
# ���ݱ��Ľṹ 'ownerdomain'
#

DROP TABLE IF EXISTS OwnerDomain;
CREATE TABLE OwnerDomain (
   ID int(10) UNSIGNED NOT NULL auto_increment,
   UserName	 varchar(10) DEFAULT '0' NOT NULL,
   VirtualDomain varchar(20) DEFAULT '9812.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   INDEX OD (ID,UserName)
);

# --------------------------------------------------------
#
# ���ݱ��Ľṹ '9812_net'
#
DROP TABLE IF EXISTS 9812_net;
CREATE TABLE 9812_net (
   ID int(10) UNSIGNED NOT NULL auto_increment,
   Host		varchar(20) DEFAULT '0' NOT NULL,
   Url		varchar(80) DEFAULT '9812.net' NOT NULL,
   Owner	varchar(10) DEFAULT '9812.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   INDEX TD (ID,Host)
);

DROP TABLE IF EXISTS domain;
CREATE TABLE domain (
   ID int(10) UNSIGNED NOT NULL auto_increment,
   Host		varchar(20) DEFAULT '0' NOT NULL,
   Url		varchar(80) DEFAULT 'xuser.net' NOT NULL,
   Owner	varchar(10) DEFAULT 'xuser.net' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE id (ID),
   INDEX TD (ID,Host)
);
