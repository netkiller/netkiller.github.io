<?php
include ("include/global.php");
if(!$Online){
header("location:error.php");
}
?>
<html>
<head>
<title>Version</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<script language="JavaScript" type="text/javascript">
<!--
function DeleteVirtualDomain(domain){
	if(window.confirm("���Ҫɾ��������¼��"))
	//domain=document.Adddomain.Addvirtualdomain.value;
	location.href="version.php?VirtualDomain="+domain
		
}
parent.leftFrame.location.href="domaintree.php";
//-->
</script>
</head>

<body bgcolor="#F5F5F5" text="#000000">
<?php
if($VirtualDomain){
	$VD->DeleteDomains($OnlineUser,$VirtualDomain);
}
?>
      <form name="Adddomain" method="post" action="domaintree.php" target="leftFrame">
  <div align="center"><?echo $virtualdomain?>��<select name="Addvirtualdomain">
      <?php $VD->ShowVirtualDomain();?>
    </select>
    <input type="submit" name="Submit" value="<? echo $adddomain?>">
    <input type="button" name="ɾ��" value="<?echo $delete?>" onclick="DeleteVirtualDomain(document.Adddomain.Addvirtualdomain.value)">
    <?php $VD->showcopyright();?>
  </div>
</form>
</body>
</html>
