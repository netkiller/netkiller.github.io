<html>
<head>
<title>Bar</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="home.css">
</head>

<body bgcolor="#CCCCCC" text="#000000" background="images/bar.jpg" leftmargin="0" topmargin="0">
<table border="0" width="100%" cellpadding="5" cellspacing="4" >
  <tr valign="middle"> 
    <td height="30" ><a href="http://www.9812.net/squirrelmail/index.php">�����ʾ�</a></td>
    <td height="30"><a href="http://dns.9812.net">�������</a></td>
    <td height="30"><a href="http://www.9812.net/cutebook/register.php">������Բ�</a><a href="domain/register.php"></a></td>
    <td height="30">����ͳ��</td>
  </tr>
</table>
</body>
</html>
