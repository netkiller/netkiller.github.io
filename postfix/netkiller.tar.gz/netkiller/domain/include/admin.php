<?php

class Admin {

//======================== validate user==========================
function validate($username,$password){

}

function post_save($userid,$name,$post_color,$address,$sex,$email,$homepage,$emotion,$post_body)

{

	global $Domain_DB;

	

	//��������Ϸ���

	$check_boolean=true;

	if($this->CheckEmptyString($email)){

		if(!$this->CheckEmailAddr($email)){

			$check_result="- E-mail��ַ���Ϸ�";

			$check_boolean=false;

		}

	}else{

		$emamil=$this->TextFilter($email);

	}



	if(!$this->CheckEmptyString($name)){

		$check_result="- ����û����д";

		$check_boolean=false;

	}else{

		$name=$this->TextFilter($name);

	}



	if(!$this->CheckEmptyString($post_body)){

		$check_result="- û����д��������";

		$check_boolean=false;

	}else{

		$post_body=$this->TextFilter($post_body);

	}



	if (!$this->check_user($userid)){

		$check_result="- �Ƿ��û�ID";

		$check_boolean=false;

	}

	

	$homepage=$this->TextFilter($homepage);

	//�ۺϼ��

	if(!$check_boolean){

		$check_result.="&nbsp;<a href='#' onclick='javascript:history.go(-1)'>���ؼ��</a>";

		$this->freeback_template("",false,$check_result);

	}else{	

		$post_time=date("Y-m-d H:i:s");

		$SQL="INSERT INTO content(father_id,userid,name,sex,address,email,homepage,emotion,post_body,post_time,post_color) ";

	$SQL=$SQL."values('null','$userid','$name','$sex','$address','$email','$homepage','$emotion','$post_body','$post_time','$post_color')";

		$Domain_DB->query($SQL);

		$this->freeback_template("showposts.php?userid=$userid",true,"лл�������!(3�������)");

	}

}





//**********************************************************************************���Խ������

function freeback_template($redirect_to,$redirect_boolean,$freeback_result){

	global $freeback;

	$freeback="<html><head>\n";

	if ($redirect_boolean){

		$freeback.="<meta http-equiv=\"refresh\" content=\"3; url=".$redirect_to."\">\n";

	}else{

		$freeback.="<title>������ģ��</title>\n";

	}

	$freeback.="</head><body>\n";

	$freeback.="<table width=745 border=0 cellspacing=0 cellpadding=0 align=center>\n";

	$freeback.="<tr><td bgcolor=#CCCCCC>\n";

	$freeback.="<table width=100% border=0 cellspacing=1 cellpadding=5>\n";

	$freeback.="<tr bgcolor=#eeeeee><td><b><div style=\"font-family:'����';font-size:12px;color:#000000\">������</div></b></td>\n";

	$freeback.="</tr>\n";

	$freeback.="<tr bgcolor=#FFFFFF>\n";

	$freeback.="<td valign=top>\n";

	$freeback.="<div style=\"font-family:'����';font-size:12px;color:#9898BA\">";

	$freeback.=$freeback_result;

	$freeback.="</div></td></tr>\n";

	$freeback.="</table>\n";

	$freeback.="</td></tr></table>\n";

	$freeback.="</body></html>";

}



//************************************************************************��ʾ���Ӻ���

function showposts($userid){

    global $Domain_DB,$page,$freeback;

    

	//����Ƿ�userid��Ч,���Ƿ��д��û�

	if(!$this->check_user($userid)){

		$this->freeback_template("",false,"�Ƿ�ID!!");

		echo $freeback;

	}else{

		$pagesize=10;//ÿҳ��ʾ��Ŀ

		if (!isset($userid)){

			$userid=1;

		}

		//ȡ����ҳ��

		$SQL="SELECT id from content where userid=".$userid." and father_id='null'";

		$totalss=$Domain_DB->query($SQL);

		$total=mysql_numrows($totalss);

		$pagecount=ceil($total/$pagesize);

		//

		if (!isset($page)){

			$page=1;

			$startP=0;//�趨Ĭ�ϼ�¼��ʼ��

		}elseif ($page>0 and $page<=$pagecount){

			$startP=($page-1)*$pagesize;//��Ӧҳ���һ��	

			$startP=$startP-1;//��������

			if ($startP<0){

			$startP=0;

			}

		}else{

			$startP=0;

			$page=1;

		}



	    $SQL="SELECT * from content where userid=".$userid." ";

		$SQL.="and father_id='null' order by id DESC LIMIT $startP,$pagesize";

		$postss=$Domain_DB->query($SQL);

	    $count=mysql_numrows($postss);

	    if($count>0){

			for ($i=0;$i<$count;$i++){

			$posts=$Domain_DB->fetch_array($postss);

			$id[$i]=$posts[id];

			$father_id[$i]=$posts[fatherid];

			$name[$i]=stripslashes($posts[name]);

			$sex[$i]=$posts[sex];

			$address[$i]=stripslashes($posts[address]);

			$email[$i]=stripslashes($posts[email]);

			$homepage[$i]=stripslashes($posts[homepage]);

			$emotion[$i]=$posts[emotion];

			$post_body[$i]=stripslashes($posts[post_body]);

			$post_time[$i]=$posts[post_time];

			$post_color[$i]=$posts[post_color];

		}

	    }

		echo "<table width=745 border=0 cellspacing=0 cellpadding=0 align=center>\n";

		echo "<tr>\n";

		echo "<td align=left><a href=post.php?userid=".$userid."><img src='images/newthread.gif' border=0></a><td>";

		echo "<td align=right><a href=register.php>�������԰�</a></td>";

		echo "<tr><table>\n";

		echo "<table width=745 border=0 cellspacing=0 cellpadding=0 align=center>\n";

		echo "<tr>\n";

		echo "<td bgcolor=#CCCCCC>\n";

		echo "<table width=100% border=0 cellspacing=1 cellpadding=5>\n";



		//��ʼѭ����ʾ����

		$i=0;

	    while($i<$count){

			echo "<tr bgcolor=#eeeeee>\n";

			echo "<td colspan=3>���Ա��( ".$id[$i]." )</td>\n";

			echo "</tr>\n";

			echo "<tr bgcolor=#FFFFFF>\n";

			echo "<td rowspan=3 valign=top width=21% align=center>\n";

			echo $name[$i]."<br><br>"; 

			if ($sex[$i]==1){

				echo "<img src=images/man.gif><br><br>";

			}else{

				echo "<img src=images/woman.gif><br><br>";

			}

			echo "����:".$address[$i];

			echo "</td>\n";

			echo "<td><img src=./images/emotion/".$emotion[$i].".gif height=18 width=18 align=ABSCENTER>\n"; 

			echo $post_time[$i]."&nbsp;д��:";

			echo "<td bgcolor=#FFFFFF width=30% align=right>";

			echo "<img src=images/replynow.gif>";

			echo "&nbsp;<a href=reply.php?userid=".$userid."&id=".$id[$i]."><font color=#000000>�����ظ�</font></a>";

			echo "&nbsp;&nbsp;<img src=images/delnow.gif>";

			echo "&nbsp;<a href=del.php?userid=".$userid."&id=".$id[$i]."><font color=#000000>ɾ������</font></a>";

			echo "</td></tr><tr><td bgcolor=#FFFFFF colspan=2><font color=".$post_color[$i].">";

//			$this->AutoWrap($post_body[$i],94);
			echo $post_body[$i];

			echo "</font>";

			$this->get_reply($userid,$id[$i]);

			echo "</td></tr><tr>\n"; 

			echo "<td bgcolor=#FFFFFF width=49%> ��&nbsp;&nbsp;&nbsp;&nbsp;ҳ:&nbsp;".$homepage[$i]."</td>\n";

			echo "<td bgcolor=#FFFFFF width=30%>�����ʼ�:&nbsp;".$email[$i]."</td></tr>\n";

			$i++;

		}

	

		//End



		echo "</table>\n";

		echo "</td>\n";

		echo "</tr>\n";

		echo "</table>\n";

   

		//��ҳ����

		echo "<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width=745\n>";

		echo "<TR>\n";

		echo "<form action=showposts.php?userid=".$userid." method=post name=jumpto>\n";

		echo "<TD align=left>\n";

		echo "����".$total."ƪ&nbsp;&nbsp;";

		echo "ҳ��:".$page."/".$pagecount."&nbsp;&nbsp;";

		echo "ÿҳ:".$pagesize."��&nbsp;&nbsp;";

		if ($pagecount==1){

			#do nothing

		}else{

			if ($page==1){

				echo "<a href=\"$php_self?userid=".$userid."&page=2\">��һҳ</a>";

			}elseif ($page==$pagecount){

				echo "<a href=$php_self?userid=".$userid."&page=".($page-1).">��һҳ</a>";

			}else{

				echo "<a href=$php_self?userid=".$userid."&page=".($page-1).">��һҳ</a>";

				echo "&nbsp;&nbsp;";

				echo "<a href=$php_self?userid=".$userid."&page=".($page+1).">��һҳ</a>";

			}

		}		

		echo "&nbsp;&nbsp;";

		echo "<input type=text value=1 size=4 name=page>\n";

		echo "<input type=submit value=ת��>\n";

		echo "</TD>\n";

		echo "</form>\n";

		echo "<TD align=right>\n";

		echo "</TD></TR>\n";

		echo "</FORM>\n";

		echo "</TABLE>\n";

	}

}

	//************************************************************************����������ظ���Ϣ����

    function get_reply($userid,$id)

    {

	   global $Domain_DB;   

       $SQL="SELECT * FROM content where userid=".$userid." and father_id='".$id."'";

       $replyss=$Domain_DB->query($SQL);

       $count=mysql_numrows($replyss);

       if($count>0){

 	        $replys=$Domain_DB->fetch_array($replyss);

	        $reply_post_body=stripslashes($replys[post_body]);

	        $reply_post_time=$replys[post_time];

	        $reply_emotion=$replys[emotion];

			$reply_color=$replys[post_color];

			echo "<hr width=99% size=0 color=#000000>";

			echo "<img src=./images/emotion/".$reply_emotion.".gif height=18 width=18 align=ABSCENTER>";

			echo "&nbsp;������&nbsp;".$reply_post_time."&nbsp;�ظ�:<br><br>&nbsp;&nbsp;";

			echo "<font color=".$reply_color.">";

//			$this->AutoWrap($reply_post_body,94);
			echo $reply_post_body;
			echo "</font>";

		}

   	}



	//***********************************************************************************����ظ�����

	function reply_save($userid,$id,$emotion,$post_body,$post_color,$password){

		global $Domain_DB;



		//��ʼ������������д�Ϸ���

		$check_boolean=true;

		if(!$this->CheckEmptyString($password)){

			$check_result="- ����û����д.<br>";

			$check_boolean=false;

		}



		if(!$this->CheckEmptyString($post_body)){

			$check_result="- �ظ�����û����д";

			$check_boolean=false;

		}else{

			$post_body=$this->TextFilter($post_body);

		}



		if(!$this->check_user($userid)){

			$check_result="- �Ƿ��û�ID";

			$check_boolean=false;

		}

		

		if(!$this->check_manager($userid,$password)){

			$check_result="- �ظ��������!!";

			$check_boolean=false;

		}

		

		//���ݼ�����		

		

		if(!$check_boolean){//������պϷ���

				$check_result.="<a href='#' onclick='javascript:history.go(-1)'>���ؼ��</a>";

				$this->freeback_template("",false,$check_result);

		}else{

			

			

			//����Ƿ��лظ�



			if ($this->check_reply($userid,$id)){

				$reply_time=date("Y-m-d H:i:s");

				$SQL="UPDATE content SET post_body='".$post_body."',post_time='".$reply_time."'";	

				$SQL.=",post_color='".$post_color."'  where userid='".$userid."' and father_id='".$id."'";

					$result=$Domain_DB->query($SQL);

				if ($result){

					$this->freeback_template("showposts.php?userid=$userid",true,"�ظ��ɹ�!(3�������)");

				}

			}else{

				$reply_time=date("Y-m-d H:i:s");

				$SQL="INSERT INTO content(father_id,userid,name,sex,address,email,homepage,emotion,post_body,post_time,post_color) ";

				$SQL=$SQL."values('$id','$userid','','','','','','$emotion','$post_body','$reply_time','$post_color')";

				$result=$Domain_DB->query($SQL);

				if ($result){

					$this->freeback_template("showposts.php?userid=$userid",true,"�ظ��ɹ�!(3�������)");

				}

			}

		}

	}



//*******************************************************************************ɾ������

function delnow($userid,$id,$password){

	global $Domain_DB;



	//��ʼ������������д�Ϸ���

	$check_boolean=true;

		if(!$this->CheckEmptyString($password)){

			$check_result="- ����û����д.<br>";

			$check_boolean=false;

		}

	

		if(!$this->check_user($userid)){

			$check_result="- �Ƿ��û�ID";

			$check_boolean=false;

		}

		

		if(!$this->check_manager($userid,$password)){

			$check_result="- ɾ���������!!";

			$check_boolean=false;

		}

	//������

	if(!$check_boolean){

				$check_result.="<a href='#' onclick='javascript:history.go(-1)'>���ؼ��</a>";

				$this->freeback_template("",false,$check_result);

	}else{

	//ɾ��������

		$SQL="delete from content where userid=".$userid." and id='".$id."'";

		$result1=$Domain_DB->query($SQL);

		$SQL="delete from content where userid=".$userid." and id='".$id."'";

		$result2=$Domain_DB->query($SQL);

		if ($result1 and $result2){

			$this->freeback_template("showposts.php?userid=$userid",true,"ɾ�������ɹ�!(3�������)");

		}

	}

}



//************************************************** ****************************�û��������԰庯����ʼ 

	function register_save($username,$password,$sitename,$siteurl){

		global $Domain_DB,$cutebook_location;

		//���������ݺϷ���
		$check_boolean=true;

		if(!$this->CheckEmptyString($username)||!$this->CheckPassword($password)){
			$check_result="��ȷ���������Ϸ�(4-20λ����,��ĸ�����)!";	
			$check_boolean=false;
		}

		if(!$this->CheckEmptyString($sitename)){
			$check_result="��վ����û����д";	
			$check_boolean=false;
		}

		if(!$this->CheckEmptyString($siteurl)){
			$check_result="��վ��ַû����д";	
			$check_boolean=false;
		}

		if(!$this->CheckEmptyString($username)||!$this->check_username($username)){
			$check_result="�û���û����д!";	
			$check_boolean=false;
		}

		if(!$this->check_username($username)){
			$check_result="�û����Ѿ�����!";
			$check_boolean=false;
		}

		if(!$check_boolean){
			$check_result.="&nbsp;<a href='#' onclick='javascript:history.go(-1)'>�����޸�</a>";
			$this->freeback_template("",false,$check_result);
		}else{
			$SQL="INSERT INTO user (UserName, Passord, RealName, Email) values ";
			$SQL.="('$username','".md5($password)."','$realname','$email')";
			$result=$Domain_DB->query($SQL);
			if ($result){
				$yourid=$Domain_DB->insert_id();//ע��õ���id
				$this->freeback_template("",false,"ע��ɹ�!������԰�ĵ�ַΪ:".$cutebook_location."showposts.php?userid=".$yourid."<br>");
			}
		}
	}

//*************************************����û�ID�����Ƿ����,(�Ƿ�ע��),��ֹ�����û�ֱ����д����

	function check_user($userid){

		global $Domain_DB;

		$SQL="SELECT username FROM user where id=".$userid."";

		$resultss=$Domain_DB->query($SQL);

		$count=mysql_numrows($resultss);

		if ($count!=1){

			return false;//������

		}else{

			return true;//����

		}

	}

	

//*************************************����û�ID�����Ƿ����,(�Ƿ�ע��),��ֹ�����û�ֱ����д����

	function check_username($username){

		global $Domain_DB;

		$SQL="SELECT username FROM user where username='".$username."'";

		$resultss=$Domain_DB->query($SQL);

		$count=mysql_numrows($resultss);

		if ($count!=1){

			return true;//������

		}else{

			return false;//����

		}

	}

	

	

//************************************�ظ���麯��(�Ƿ��ǰ���ظ�����)



	function check_manager($userid,$password){

		global $Domain_DB;

		$SQL="SELECT username FROM user where id=".$userid." and password='".md5($password)."'";

		$resultss=$Domain_DB->query($SQL);

		$count=mysql_numrows($resultss);

		if ($count!=1){

			return false;//�û��������벻ƥ��!

		}else{

			return true;//�û���������ƥ��!

		}

	}

//************************************����Ƿ��Ѿ��лظ�

	function check_reply($userid,$id){

	global $Domain_DB;

		$SQL="SELECT * FROM content where userid=".$userid." and father_id='".$id."'";

			$replyss=$Domain_DB->query($SQL);

			$count=mysql_numrows($replyss);

			if ($count!=1){

				return false; //û�лظ�

			}else{

				return true; //�лظ�

			}

	}



//*********************************����ַ����Ƿ�Ϊ��

function CheckEmptyString($C_char)

{ 

	if (!is_string($C_char)) return false;         

	if (empty($C_char)) return false;            

	if ($C_char=='') return false;                

	return true; 

}





function CheckEmailAddr($C_mailaddr)   

{ 

if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$",$C_mailaddr))   

   { 

       return false; 

   } 

   return true; 

} 



function CheckPassword($C_passwd)   

{ 

   if (!$this->CheckLengthBetween($C_passwd, 4, 20)) return false; 

   if (!ereg("^[_a-zA-Z0-9]*$", $C_passwd)) return false; 

   return true; 

} 





function CheckLengthBetween($C_cahr, $I_len1, $I_len2=100)   

{ 

   $C_cahr = trim($C_cahr); 

   if (strlen($C_cahr) < $I_len1) return false; 

   if (strlen($C_cahr) > $I_len2) return false; 

   return true; 

} 



function showcopyright(){

	global $cutebook_copyright;	

	echo $cutebook_copyright;

}



function AutoWrap($in_WrapString,$out_WrapSize){

	$out_WrapString="";

	if ($out_WrapSize>=strlen($in_WrapString)){	

		$out_WrapString=$in_WrapString;

	}else{

		for ($i=0;$i<=strlen($in_WrapString);$i=$i+$out_WrapSize){

			$in_WrapStringLinePart=substr($in_WrapString,$i,$out_WrapSize);

			if(strpos($in_WrapStringLinePart,chr(32))==0 || strpos($in_WrapStringLinePart,chr(13)+chr(10))==0){

				$out_WrapString=$out_WrapString." ".substr($in_WrapString,$i,$out_WrapSize);

			}else{

				$out_WrapString=$out_WrapString.substr($in_WrapString,$i,$out_WrapSize);

			}

		}	

	}

	echo $out_WrapString;

}



function TextFilter($str){

		$str = chop($str);

		$str = nl2br(htmlspecialchars( $str ));

		return $str;

}

}

?>