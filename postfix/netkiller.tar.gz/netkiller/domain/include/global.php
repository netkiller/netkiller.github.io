<?php
/*
$noheader=1;
$nocache=0;

// get rid of slashes in get / post / cookie data
if (get_magic_quotes_gpc()==1 and is_array($GLOBALS)==1) {
  while(list($key,$val)=each($GLOBALS)) {
    if (is_string($val)==1) {
      $GLOBALS[$key]=stripslashes($val);
    }
  }
}

set_magic_quotes_runtime(0);

error_reporting(7);

if (isset($noheader)==0 or $noheader==0) {
  // default headers
  header("HTTP/1.0 200 OK");
  header("HTTP/1.1 200 OK");
  header("Content-type: text/html");
}
if ($nocache==1) {
  // no caching
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT"); // always modified
  header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
  header("Pragma: no-cache");                                   // HTTP/1.0
}
*/
// ###################### ��ʼ�� #######################
require("./include/config.php");

// ###################### �������԰� #######################
require("./include/language/$Language");

//###################### �����������ݿ��� #################
require("./include/mysql.php");
$Domain_DB=new MySQL_Class;

$Domain_DB->appname="DomainName";
$Domain_DB->appshortname="DomainName";
$Domain_DB->database=$dbname;
$Domain_DB->server=$servername;
$Domain_DB->user=$dbusername;
$Domain_DB->password=$dbpassword;

$Domain_DB->connect();

//##################### ���� DomainName �� ########################
require ("./include/domain.php");
$VD=new VirtualDomain;
?>