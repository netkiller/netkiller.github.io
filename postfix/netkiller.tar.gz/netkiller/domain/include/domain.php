<?php
/*
*
*title:��������ϵͳ
*author:netkiller
*date:2003-6
*
*/

class VirtualDomain {

function freeback_template($redirect_to,$redirect_boolean,$freeback_result){

	global $freeback;

	$freeback="<html><head>\n";

	if ($redirect_boolean){
		$freeback.="<meta http-equiv=\"refresh\" content=\"3; url=".$redirect_to."\">\n";
	}else{
		$freeback.="<title>������ģ��</title>\n";
	}
	$freeback.="</head><body>\n";
	$freeback.="<table width=745 border=0 cellspacing=0 cellpadding=0 align=center>\n";
	$freeback.="<tr><td bgcolor=#CCCCCC>\n";
	$freeback.="<table width=100% border=0 cellspacing=1 cellpadding=5>\n";
	$freeback.="<tr bgcolor=#eeeeee><td><b><div style=\"font-family:'����';font-size:12px;color:#000000\">������</div></b></td>\n";
	$freeback.="</tr>\n";
	$freeback.="<tr bgcolor=#FFFFFF>\n";
	$freeback.="<td valign=top>\n";
	$freeback.="<div style=\"font-family:'����';font-size:12px;color:#9898BA\">";
	$freeback.=$freeback_result;
	$freeback.="</div></td></tr>\n";
	$freeback.="</table>\n";
	$freeback.="</td></tr></table>\n";
	$freeback.="</body></html>";
}

//******************************** �û����뺯��  ****************************

	function register_save($username,$password,$realname,$email,$virtualdomain,$url){

		global $Domain_DB,$cutebook_location;

		//���������ݺϷ���
		$check_boolean=true;

		if(!$this->CheckEmptyString($username)||!$this->CheckPassword($password)){
			$check_result="��ȷ���������Ϸ�(4-20λ����,��ĸ�����)!";	
			$check_boolean=false;
		}


		if(!$this->CheckEmptyString($realname)){
			$check_result="��ʵ����û����д";	
			$check_boolean=false;
		}

		if(!$this->CheckEmailAddr($email)){
			$check_result="��ȫ�����ʼ�û����д";
			$check_boolean=false;
		}

		if(!$this->CheckEmptyString($username)||!$this->check_username($username)){
			$check_result="�û���û����д!";	
			$check_boolean=false;
		}

		if(!$this->check_username($username)){
			$check_result="�û����Ѿ�����!";
			$check_boolean=false;
		}
		if(!$this->CheckEmptyString($url)){
			$check_result="��û����д�����ҳ��ַ!";
			$check_boolean=false;
		}
		if(!$check_boolean){
			$check_result.="&nbsp;<a href='#' onclick='javascript:history.go(-1)'>�����޸�</a>";
			$this->freeback_template("",false,$check_result);
		}else{
			$SQL="INSERT INTO domainuser (UserName, Password, RealName, Email) values ";
			$SQL.="('$username','".md5($password)."','$realname','$email')";
			$result=$Domain_DB->query($SQL);
			$SQL="INSERT INTO ownerdomain (UserName,VirtualDomain) values('$username','$virtualdomain')";
			$Domain_DB->query($SQL);
			$VD=$this->DomainStrReplace($virtualdomain);
			$SQL="INSERT INTO $VD (Host,Url,Owner) values('$username','$url','$username')";
			$Domain_DB->query($SQL);
			$RegMsg="ע��ɹ�!<br>�û�: $username <br>��ע�������Ϊ��<a href=http://$username.$virtualdomain>$username.$virtualdomain</a><br><a href='login.php'>��¼</a>";
			if ($result){
				$this->freeback_template("",false,$RegMsg);
			}
		}
	}

function validate($username,$password){

}

function ShowHosts($virtualdomain,$username){

    global $Domain_DB,$freeback,$edit,$delete,$OnlineUser,$defaulthost;
    
	$virtualdomain=$this->DomainStrReplace($virtualdomain);
	if(!$this->check_username($username)){

		$this->freeback_template("",false,"���û�û������������!");

		echo $freeback;

	}else{

		$SQL="SELECT * from $virtualdomain where owner='$username'";

		$result=$Domain_DB->query($SQL);

	    	$count=mysql_num_rows($result);

	    if($count>0){

			for ($i=0;$i<$count;$i++){

			$hosts=$Domain_DB->fetch_array($result);

			$id[$i]=$hosts[id];

			$host[$i]=$hosts[host];

			$url[$i]=$hosts[url];

		}

	    }
		$i=0;
		$boolean=0;
	    while($i<$count){
		if($boolean){
		echo "<tr bgcolor=#CCCCCC>";
		$boolean=0;
		}else{
		echo "<tr bgcolor=#DDDDDD>";
		$boolean=1;
		}
		$serialnnumber=$i+1;
		echo "<td align=center>$serialnnumber</td>";
		echo "<td>$host[$i]</td>";
		echo "<td>$url[$i]</td>";
		echo "<td><a href=\"javascript:EditHost('$virtualdomain','$id[$i]')\">$edit</a></td>";
		if($host[$i]==$OnlineUser){
			echo "<td>$defaulthost</td>";
		}else{
			echo "<td><a href=\"javascript:DelRecord('$virtualdomain','$id[$i]')\">$delete</a></td>";
		}

			$i++;

		}

	}

}

function AddHosts($host,$vdomain,$url,$username){

    global $Domain_DB;
    	
    	$vdomain=$this->DomainStrReplace($vdomain);
    	if($this->check_host($host,$vdomain)){
			$check_result="<font face=Wingdings size=5 color=red>L</font>  <font color=red>��Բ��� $host �����Ա�������ע!</font>";
			echo $check_result;
			return;
	}
	$SQL="INSERT INTO $vdomain (host,url,owner) values('$host','$url','$username')";
	//echo $SQL;
	$Domain_DB->query($SQL);
	echo "<font face=Wingdings size=5 color=red>J</font>  <font color=red>��ϲ��!�������Ӳ����ɹ���</font>";

}

function DeleteHosts($id,$vdomain){

    global $Domain_DB,$OnlineUser;
    	
    	$vdomain=$this->DomainStrReplace($vdomain);
  	
	$SQL="DELETE From $vdomain where id='$id' and owner='$OnlineUser'";

	$Domain_DB->query($SQL);
	echo "<font face=Wingdings size=5 color=red>L</font>  <font color=red> $host �����Ա�ɾ��!</font>";

}

function EditHosts($id,$vdomain,$url){

    global $Domain_DB,$OnlineUser;
    	
    	$vdomain=$this->DomainStrReplace($vdomain);
  	
	$SQL="Update $vdomain set url='$url' Where id='$id' and owner='$OnlineUser'";

	$Domain_DB->query($SQL);
	echo "<font face=Wingdings size=5 color=red>J</font>  <font color=red> $host URL���ĳɹ�!</font>";

}

//*************************************����û�ID�����Ƿ����,(�Ƿ�ע��),��ֹ�����û�ֱ����д����

	function check_user($userid){
		global $Domain_DB;
		$SQL="SELECT username FROM domainuser where id=".$userid."";
		$resultss=$Domain_DB->query($SQL);
		$count=mysql_num_rows($resultss);
		if ($count!=1){
			return false;//������
		}else{
			return true;//����
		}
	}

//*************************************����û�ID�����Ƿ����,(�Ƿ�ע��),��ֹ�����û�ֱ����д����

	function check_username($username){

		global $Domain_DB;

		$SQL="SELECT username FROM domainuser where username='$username.'";
		$resultss=$Domain_DB->query($SQL);
		$count=mysql_num_rows($resultss);
		if ($count!=1){
			return true;//������
		}else{
			return false;//����
		}
	}
	function check_host($host,$vdomain){

		global $Domain_DB;
		//$vdomain=$this->DomainStrReplace($vdomain);
		$SQL="SELECT host FROM $vdomain where host='$host'";
		//echo $SQL;
		$result=$Domain_DB->query($SQL);
		$count=mysql_num_rows($result);
		if ($count>=1){
			return true;//������
		}else{
			return false;//����
		}
	}
	function check_ownerdomain($username,$vdomain){

		global $Domain_DB;
		$SQL="SELECT * FROM ownerdomain where username='$username' and virtualdomain='$vdomain'";
		$result=$Domain_DB->query($SQL);
		$count=mysql_num_rows($result);
		if ($count>=1){
			return true;//����
		}else{
			return false;//������
		}
	}
	
//***************����ַ����Ƿ�Ϊ��******************

function CheckEmptyString($C_char)
{ 
	if (!is_string($C_char)) return false;         
	if (empty($C_char)) return false;            
	if ($C_char=='') return false;                
	return true; 
}

function CheckEmailAddr($C_mailaddr)   

{ 
if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$",$C_mailaddr))   
   { 
       return false; 
   } 
   return true; 
} 

function CheckPassword($C_passwd)   
{ 
   if (!$this->CheckLengthBetween($C_passwd, 4, 20)) return false; 
   if (!ereg("^[_a-zA-Z0-9]*$", $C_passwd)) return false; 
   return true; 
} 

function CheckLengthBetween($C_cahr, $I_len1, $I_len2=100)   

{ 
   $C_cahr = trim($C_cahr); 
   if (strlen($C_cahr) < $I_len1) return false; 
   if (strlen($C_cahr) > $I_len2) return false; 
   return true; 
} 

function showcopyright(){

	global $copyright;	
	echo $copyright;

}

function TextFilter($str){

		$str = chop($str);
		$str = nl2br(htmlspecialchars( $str ));
		return $str;
}
function DomainStrReplace($vdstr){

	$vdstr = str_replace(".","_",$vdstr);
	return $vdstr;

}


    function ShowVirtualDomain(){
	
	global $Domain_DB,$page;
	$SQL="SELECT * from virtualdomain ";
	$result=$Domain_DB->query($SQL);
	$count=mysql_num_rows($result);

        if($count>0){
		for ($i=0;$i<$count;$i++){
			$vd=$Domain_DB->fetch_array($result);
			$virtualdomainid[$i]=$vd[id];
			$virtualdomainlist[$i]=$vd[virtualdomain];
		}
        }

	//��ʼѭ����ʾ������
	$i=0;
	echo "<option value=$virtualdomainlist[$i] selected>$virtualdomainlist[$i]</option>\n";
	$i=1;
	while($i<$count){
		echo "<option value=$virtualdomainlist[$i]>$virtualdomainlist[$i]</option>\n";
	$i++;
	}
    }
    
function AddDomains($username,$vdomain){

    global $Domain_DB;
    	
    	if($this->check_ownerdomain($username,$vdomain)){
			$check_result="<font face=Wingdings size=5 color=red>L</font>  <font color=red>�Բ��� $vdomain ������������!</font>";
			echo $check_result;
			return;
	}
	$SQL="INSERT INTO ownerdomain (username,virtualdomain) values('$username','$vdomain')";
	
	$Domain_DB->query($SQL);
	echo "<font face=Wingdings size=5 color=red>J</font>  <font color=red>���������ӳɹ���</font>";

}

function DeleteDomains($username,$vdomain){

    global $Domain_DB;
    	
    	if(!$this->check_ownerdomain($username,$vdomain)){
			$check_result="<font face=Wingdings size=5 color=red>L</font>  <font color=red>�Բ��� $vdomain ��û�����ӣ�Ҳ�����Ǳ�����Աɾ��!</font>";
			echo $check_result;
			return;
	}
	
	$SQL="Delete From ownerdomain Where username= '$username' and virtualdomain= '$vdomain'";
	
	$Domain_DB->query($SQL);
	echo "<font face=Wingdings size=5 color=red>J</font>  <font color=red>������ɾ���ɹ���</font>";

}

    function ShowOwnerDomain($Username){

	 global $Domain_DB,$page;
	if($Username=="sysop"){
	    $SQL="SELECT * from ownerdomain ";
	    $result=$Domain_DB->query($SQL);
	    $count=mysql_num_rows($result);

	    if($count>0){

			for ($i=0;$i<$count;$i++){
				$vd=$Domain_DB->fetch_array($result);
				$virtualdomainid[$i]=$vd[id];
				$virtualdomainlist[$i]=$vd[virtualdomain];
			}
	    }

		//��ʼѭ����ʾ������
		$i=0;
		while($i<$count){

			echo "<tr><td><b><a href=virtualdomain.php?domain=this->DomainStrReplace($virtualdomain[$i])>";
			echo $virtualdomainlist[$i];
			echo "</a></td></tr><br>";

			$i++;
		}
	}else{
	    $SQL="SELECT * from ownerdomain where username='$Username'";
	    $result=$Domain_DB->query($SQL);
	    $count=mysql_num_rows($result);
	    if($count>0){

			for ($i=0;$i<$count;$i++){
				$vd=$Domain_DB->fetch_array($result);
				$virtualdomainid[$i]=$vd[id];
				$virtualdomainlist[$i]=$vd[virtualdomain];
			}
	    }

		//��ʼѭ����ʾ������
		$i=0;
		while($i<$count){
			//$vdomain=$this->DomainStrReplace($virtualdomainlist[$i]);
			echo "<tr><td><b><a href=virtualdomain.php?VirtualDomain=$virtualdomainlist[$i] target=mainFrame>";
			echo $virtualdomainlist[$i];
			echo "</a></td></tr><br>";
			$i++;
		}
	}
    }

function HostTotals($virtualdomain,$vhost,$user,$page){

    global $Domain_DB,$page;
    
    $pagesize=30;//ÿҳ��ʾ��Ŀ
    
	$virtualdomain=$this->DomainStrReplace($virtualdomain);
	echo $host;
	    	if(!isset($vhost)){$vhost='*';}
	    	if($vhost=='*'){
			$SQL="SELECT * from $virtualdomain order by id DESC";// LIMIT $startP,$pagesize";
		}else{

			$SQL="SELECT * from $virtualdomain where host='$vhost'";
			
		}
		$result=$Domain_DB->query($SQL);
	    	$count=mysql_num_rows($result);
	    	$pagecount=ceil($count/$pagesize);
	    	
		if (!isset($page)){
			$page=1;
			$startP=0;//�趨Ĭ�ϼ�¼��ʼ��
		}elseif ($page>0 and $page<=$pagecount){
			$startP=($page-1)*$pagesize;//��Ӧҳ���һ��	
			$startP=$startP-1;//��������
			if ($startP<0){
			$startP=0;
			}
		}else{
			$startP=0;
			$page=1;
		}
		
		if($count>0){
			for ($i=0;$i<$count;$i++){
			$hosts=$Domain_DB->fetch_array($result);
			$id[$i]=$hosts[id];
			$host[$i]=$hosts[host];
			$url[$i]=$hosts[url];
			$Owner[$i]=$hosts[owner];
			}
		}

	    	$i=$startP;
		$boolean=0;
		while($i<$pagesize*$page){
		if($i>$count-1)break;
		if($boolean){
			echo "<tr bgcolor=#eeddff>";
			$boolean=0;
		}else{
			echo "<tr bgcolor=#eeeeff>";
			$boolean=1;
		}
		$serialnnumber=$i+1;
		$domainname=$host[$i].".".str_replace("_",".",$virtualdomain);
		echo "<td align=center>$serialnnumber</td>";
		echo "<td><A href=http://$domainname>$domainname</a></td>";
		echo "<td>$url[$i]</td>";
		echo "<td>$Owner[$i]</td>";
		$i++;
		}
		
		echo "����".$count."ƪ&nbsp;&nbsp;";
		echo "ҳ��:".$page."/".$pagecount."&nbsp;&nbsp;";
		echo "ÿҳ:".$pagesize."��&nbsp;&nbsp;";
		if ($pagecount==1){
			#do nothing
		}else{
			if ($page==1){
				echo "<a href=\"$php_self?page=2\">��һҳ</a>";
			}elseif ($page==$pagecount){
				echo "<a href=$php_self?page=".($page-1).">��һҳ</a>";
			}else{
				echo "<a href=$php_self?page=".($page-1).">��һҳ</a>";
				echo "&nbsp;&nbsp;";
				echo "<a href=$php_self?page=".($page+1).">��һҳ</a>";
			}
			
		}		

	}

function UserTotals(){

    global $Domain_DB,$Vdomain;
    
	$SQL="SELECT * from domainuser order by id DESC";
	$result=$Domain_DB->query($SQL);
	$usercount=mysql_num_rows($result);
	    if($usercount>0){

		for ($i=0;$i<$usercount;$i++){
			$users=$Domain_DB->fetch_array($result);
			$id[$i]=$users[id];
			$user[$i]=$users[username];

		}

	    }
	echo "<select name=\"VIPUser\" onChange=\"location.href = this.options[this.selectedIndex].value;\" style=\"font-size: 10pt; width: 130; background-color: rgb(255,255,100); color: rgb(0,0,0); font-weight: 200\" size=\"1\">";
	echo "<option value='*' selected>VIP��Ա:$usercount λ</option>\n";
	$i=0;
	while($i<$usercount){
		echo "<option value='$php_self?Vdomain=$Vdomain&Host=$user[$i]'>$user[$i]</option>\n";
	$i++;
	}
	echo "</select>";
}

function OwnerDomainTotals(){

    global $Domain_DB,$Vdomain;
    
	$SQL="SELECT * from domainuser order by id DESC";
	$result=$Domain_DB->query($SQL);
	$usercount=mysql_num_rows($result);
	    if($usercount>0){

		for ($i=0;$i<$usercount;$i++){
			$users=$Domain_DB->fetch_array($result);
			$id[$i]=$users[id];
			$user[$i]=$users[username];

		}

	    }
	echo "<select name=\"VIPUser\" onChange=\"location.href = this.options[this.selectedIndex].value;\" style=\"font-size: 10pt; width: 130; background-color: rgb(255,255,100); color: rgb(0,0,0); font-weight: 200\" size=\"1\">";
	echo "<option value='*' selected>VIP��Ա:$usercount λ</option>\n";
	$i=0;
	while($i<$usercount){
		echo "<option value='$php_self?Vdomain=$Vdomain&Host=$user[$i]'>$user[$i]</option>\n";
	$i++;
	}
	echo "</select>";
}


}

?>
