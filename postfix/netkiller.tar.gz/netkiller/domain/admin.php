<html>
<head>
<title>������������</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<frameset cols="157,*" border="1" framespacing="1" rows="*" bordercolor="#000000" frameborder="YES"> 
  <frame name="leftFrame" scrolling="NO" noresize src="domaintree.php" frameborder="NO" marginwidth="2" marginheight="5">
  <frameset rows="69,*" frameborder="NO" border="0" framespacing="0" cols="*"> 
    <frame name="topFrame" scrolling="NO" noresize src="top.php" marginwidth="1" marginheight="1" >
    <frameset rows="*,70" frameborder="NO" border="0" framespacing="0" cols="*"> 
      <frame name="mainFrame" src="virtualdomain.php" marginwidth="5" marginheight="5">
      <frame name="bottomFrame" scrolling="NO" noresize src="version.php" marginwidth="2" marginheight="2">
    </frameset>
  </frameset>
</frameset>
<noframes> 
<body bgcolor="#FFFFFF" text="#000000">
</body>
</noframes> 
</html>
