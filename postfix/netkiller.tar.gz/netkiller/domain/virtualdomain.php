<?php
include ("include/global.php");
if(!$Online){
header("location:error.php");
}
?>
<html>
<head>
<title>������������</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="domain.css" type="text/css">
<script language="JavaScript" type="text/javascript">
<!--
function DelRecord(vd,id){
	if(window.confirm("���Ҫɾ��������¼��"))
		location.href="virtualdomain.php?Operate=Delete&VirtualDomain="+vd+"&ID="+id
		
}
function EditHost(vd,id)
{
	url=prompt("�������µ�URL��","http://");
	location.href="virtualdomain.php?Operate=Edit&VirtualDomain="+vd+"&ID="+id+"&Url="+url
}
//-->
</script>
</head>

<body bgcolor="#F5F5F5" text="#000000">
<?
	if($VirtualDomain){
	$Virtualdomain=$VirtualDomain;
	}
	switch ($Operate) {
  		case "AddHost":
			if($Host && $Url!="http://"){
				$VD->AddHosts($Host,$Virtualdomain,$Url,$OnlineUser);
			}else{
				echo "<font face=Wingdings size=5 color=red>L</font>  <font color=red>�������Ӳ���ʧ�ܡ�</font>";
			}
    		break;
  		case "Edit":
    		$VD->EditHosts($ID,$Virtualdomain,$Url);
   			break;
  		case "Delete":
			$VD->DeleteHosts($ID,$Virtualdomain);
   			break;
	}
	
?>
<br>
<font color="#FF0000"><?echo $currentdomain?>��<?echo $Virtualdomain?></font>
<table border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" width="90%">
  <tr>
    <td>
      <table border="0" width="100%">
        <tr> 
          <th><?echo $number?></th>
          <th><?echo $host?></th>
          <th>
            <?echo $url?>
          </th>
          <th colspan="2"><?echo $operate?></th>
        </tr>
<?php
	$VD->ShowHosts($Virtualdomain,$OnlineUser);
?>        
      </table>
      
    </td>
  </tr>
</table>

<form name="AddHost" method="post" action="<? echo $PHP_SELF; ?>">
  <b><font size="3">http:// </font></b> 
  <input type="text" name="Host" maxlength="20" size="15">
  <font size="4"><b> . </b></font> 
  <select name="VirtualDomain">
    <?php $VD->ShowVirtualDomain();?>
  </select>
  <b>URL:</b> 
  <input type="text" name="Url" maxlength="255" size="40" value="http://">
  <input type="submit" name="Submit" value="<? echo $addhost?>">
  <input type="hidden" name="Operate" value="AddHost">
</form>
</body>
</html>
