<?
session_start(); 
session_register("URL"); 
?>
<?
header("Location: $URL");
echo "Loading...";
//<meta http-equiv='refresh' content='0;URL=$Url'>
?> 


