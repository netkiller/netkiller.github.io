<?php
//=================================================================
//
//   (C)opy right Virtual Domain System Jan 2002
//   Homepage:http://www.9812.net
//   Netkiller(�¾���) Email:netkiller@9812.net
//   Other:
//         http://www.kdeopen.com
//         http://www.xuser.com
//         http://www.aid.net
//
//=================================================================
session_start(); 
session_register("URL"); 
$mysqhost="localhost";
$dbuser = "HostSearch";
$passwd = "VHostSearch";
$dbname = "domain";

$ERROR = "http://www.gdfz.com";

$dbLink=mysql_connect($mysqhost,$dbuser,$passwd)or die("Unable to connect to database");
mysql_select_db($dbname)or die("Unable to select database");

	$headers =	getallheaders();
	
	while(list($header,$value)=each($headers)){
		if($header=="Host"){
		
			$DomainName=$value;
		}
	}
	
//echo $DomainName;
//$DomainName = 	"freebsd.9812.net";
$dnStr = 	explode(".", $DomainName);
$dnLength =	strlen($DomainName);
$i=0;

while($dnStr[$i]) { 
    $i++;
}    

$Domain = 	$dnStr[$i-2].".".$dnStr[$i-1];
$Host =		substr($DomainName, 0, $dnLength-strlen($Domain)-1);

//echo "Host:$Host<br>";
//echo "Domain:$Domain<br>";

if(SearchDomain($Domain)){
	$URL = SearchHost($Host,$Domain);
	if(!$URL){
		$URL=$ERROR;
	}
}else{
	$URL=$ERROR;
}	

mysql_close($dbLink);
//header("Location: $URL");
//=============================================================================================
HideUrlLocation("",$URL);
//==============================================================================================

	
//=============================================================================================
function SearchDomain($domain){
	$str_sql="select * from virtualdomain where virtualdomain='$domain'";
	$result = mysql_query($str_sql);
	$count=mysql_num_rows($result);
	if($count){
	//echo "Count:$count<br>";
	if($count)
		return true;
	}else{
		return false;
	}
}

function SearchHost($host,$domain){
	$domain=DomainStrReplace($domain);
	$str_sql="Select * From $domain where host='$host'";
	$result = @mysql_query($str_sql);
	$count=mysql_num_rows($result);
	if($count>=1){
	    $row = @mysql_fetch_array($result);
		if($row[url]){
		return "$row[url]";
		}else{
		return "$ERROR";
		}
	}else{
		return false;
	}
}

function DomainStrReplace($vdstr){

	$vdstr = str_replace(".","_",$vdstr);
	return $vdstr;

}

function HideUrlLocation($title,$url){
	print ("<html><title>");
	print ("$title");
	print ("</title><meta http-equiv='Content-Type' content='text/html; charset=gb2312'>");
	print ("</head>");
	print ("<frameset border=0 rows='0,*' cols='*' frameBorder=NO frameSpacing=0>");
 	print ("<frame src='netkiller.php' frameborder='NO' noResize scrolling=no>");
	print ("<frame src='redirect.php'>");
	print ("<frame name=bottomFrame scrolling=NO noresize src=toolbar.php marginwidth=0 marginheight=0 frameborder=NO>");
	print ("</frameset>");
	print ("<noframes><body>");
	print ("$url");
	print ("</body></noframes>");
	print ("</html>");
}

?>

