<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<script language="JavaScript">
                                                                                                                                                                                                                                            
	//window.open('manager/data/pop.php','new','toolbar=0,scrollbars=1,height=350,width=550');  
	//window.open('call/apple.php','applecall','toolbar=0,scrollbars=1,height=250,width=177');                                                                                                                                                                                                                                             
</script>
</body>
</html>
