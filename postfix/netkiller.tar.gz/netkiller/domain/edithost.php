<?php
include ("include/global.php");
if(!$Online){
header("location:login.php");
}
?>
<html>
<head>
<title>�༭����</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body bgcolor="#F5F5F5" text="#000000">
<form name="Modify" method="post" action="virtualdomain.php">
  <p> 
    <?echo $host?>
    :
    <input type="text" name="textfield" maxlength="20" value="<?echo $host?>">
  </p>
  <p> 
    <?echo $url?>
    :
    <input type="text" name="textfield2" maxlength="50" size="40" value="<?echo $Url?>">
  </p>
  <p> 
    <input type="submit" name="Submit" value="<?echo $modify?>">
  </p>
</form>
</body>
</html>
