<html>
<head>
<title>Error</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body bgcolor="#FFFFFF" text="#000000" background="images/netkiller.jpg">
<h1><font color="#FF0000">http://www.9812.net</font></h1>
<h1><font color="#FF0000">http://www.kdeopen.com</font></h1>
<h1><font color="#FF0000">http://www.xuser.net</font></h1>
<h1><font color="#FF0000">http://www.xaid.net</font></h1>
</body>
</html>
