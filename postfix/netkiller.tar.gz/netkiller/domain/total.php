<?include ("include/global.php");?>
<html><!-- #BeginTemplate "/Templates/song.dwt" -->
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="../home.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" background="../images/home_34_06.gif">
<div align="center"><a href="http://www.9812.net"><img src="../images/banner.gif" width="397" height="71" border="0"></a> 
</div>
<table align=center border=0 cellpadding=0 cellspacing=0 width=89%>
  <tbody> 
  <tr> 
    <td height="2" width="0%"><img src="../images/conner_01.gif"></td>
    <td background="../images/conner_02.gif" height="2" width="98%"><img alt=../images/conner_02.gif 
      src="../images/conner_02.gif" width="138" height="11"></td>
    <td height="2" width="2%"><img src="../images/conner_03.gif"></td>
  </tr>
  <tr> 
    <td background="../images/conner_04.gif" height="87" width="0%">&nbsp;</td>
    <td height="87" valign="top" width="98%"><!-- #BeginEditable "content" --> 
      <form name="form1" method="post" action="<?$php_self?>">
        http://
        <input type="text" name="Host" value="*">
        .
        <select name="Vdomain">
          <?php
			 	$VD->ShowVirtualDomain();
		  ?>
        </select>	  
        <input type="submit" name="Submit" value="Submit">
        <?$VD->UserTotals();?>
      </form>
      <table border="0" width="100%" bordercolor="#000000">
        <tr> 
          <td width="6%"> 
            <div align="center">���</div>
          </td>
          <td width="27%"> 
            <div align="center">����</div>
          </td>
          <td width="47%"> 
            <div align="center">URL</div>
          </td>
          <td width="20%"> 
            <div align="center">�û�</div>
          </td>
        </tr>
        <?
			if(isset($Vdomain))$Virtualdomain=$Vdomain;
			$VD->HostTotals($Virtualdomain,$Host,$User,$page);
		?>
      </table>
      <?
		echo "<form action='$php_self' method=post name=jumpto>\n";
		echo "<input type=text value=1 size=4 name=page>\n";
		echo "<input type=submit value=ת��>\n";
		echo "</form>\n";
?>
      <!-- #EndEditable --></td>
    <td background="../images/conner_06.gif" height="87" width="2%">&nbsp;</td>
  </tr>
  <tr>
    <td background="../images/conner_04.gif" width="0%">&nbsp;</td>
    <td width="98%"> 
      <div align="center"><a href="javascript:history.back()"><font size="2">������ҳ</font></a></div>
    </td>
    <td background="../images/conner_06.gif" width="2%">&nbsp;</td>
  </tr>
  <tr> 
    <td width="0%"><img src="../images/conner_07.gif"></td>
    <td background="../images/conner_08.gif" width="98%"><img alt=../images/conner_08.gif 
      src="../images/conner_08.gif" width="138" height="12"></td>
    <td width="2%"><img 
src="../images/conner_09.gif"></td>
  </tr>
  </tbody> 
</table>
<div align="center"><font color="#0000FF" size="2"><br>
  (C)opyright ���������ļ����ר��ѧԺ98-1-2ȫ��<br>
  �¾��� OICQ:13721218 ICQ��101888222 <br>
  Email:netkiller@9812.net</font> </div>
</body>
<!-- #EndTemplate --></html>
