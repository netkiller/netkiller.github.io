<?include ("include/global.php");?>
<html>
<head>
<title>ע����������</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<noscript><iframe src=*.html></iframe></noscript>
<script language="javascript">
function announce()
{
if(window.event .keyCode==0x11)
{
window.alert ("���븴�ƣ�����������ϵ��");
}
}
</script>
</head>

<body bgcolor="#D0DCE0" text="#000000" oncontextmenu="return false" onselectstart='return false' onkeydown="javascript:announce()">
<div align="center"><a href="http://www.9812.net"><img src="<?echo $Banner;?>" border="0"></a> 
</div>
<form name="domain" method="post" action="registersave.php">
  <table border="0" align="center" width="53%">
    <tr> 
      <td width="112"> 
        <?echo $username; ?>
        : </td>
      <td width="366"> 
        <input type="text" name="Username" maxlength="10" value="<?echo $Host?>">
        . 
        <?php
		  	if($VirtualDomain){
		  		echo "$VirtualDomain";
				echo "<input name='Virtualdomain' type='hidden' id='Virtualdomain' value='$VirtualDomain'>"; 
			}else{
				echo "<select name='Virtualdomain'>";
			 	$VD->ShowVirtualDomain();
				echo "</select>";
			}
		  ?>
        </td>
    </tr>
    <tr> 
      <td width="112"> 
        <?echo $password; ?>
        :</td>
      <td width="366"> 
        <input type="password" name="Password" maxlength="10">
      </td>
    </tr>
    <tr> 
      <td width="112"> 
        <?echo $confirm; ?>
        :</td>
      <td width="366"> 
        <input type="password" name="Confirm" maxlength="10">
      </td>
    </tr>
    <tr> 
      <td width="112"> 
        <?echo $realname; ?>
        :</td>
      <td width="366"> 
        <input type="text" name="Realname" maxlength="10">
      </td>
    </tr>
    <tr>
      <td width="112">
        <?echo $security_mail; ?>
        :</td>
      <td width="366">
        <input type="text" name="Email" maxlength="50">
      </td>
    </tr>
    <tr> 
      <td width="112">
        <?echo $url; ?>
        : </td>
      <td width="366"> 
        <input name="Url" type="text" value="http://" size="40" maxlength="200">
      </td>
    </tr>
    <tr> 
      <td colspan="2"> 
        <div align="center"> 
          <input type="submit" name="Submit" value="���ھ�����">
          <input type="reset" name="Submit2" value="�Ժ���˵��">
        </div>
      </td>
    </tr>
  </table>
  </form>
<?echo $copyright; ?>
</body>
</html>
