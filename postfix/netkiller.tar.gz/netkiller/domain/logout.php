<?
/*
session_start(); 
session_register("Online"); 
session_register("OnlineUser");
$Online=false;
$OnlineUser=null;

if(!$Online){
//	header("location:login.php?op=exit");
	header("Location: validate.php?op=reset");
}
*/	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<META HTTP-EQUIV="pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate">
<META HTTP-EQUIV="expires" CONTENT="0">

<title>�˳�ϵͳ</title>
</head>

<body>
<script>parent.close();</script>
</body>
</html>
