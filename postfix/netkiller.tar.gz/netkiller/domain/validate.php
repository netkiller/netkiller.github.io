<?php
//$MemberID = $HTTP_POST_VARS['username'];
//$MemberPasswd = $HTTP_POST_VARS['password'];
session_start(); 
session_register("Online"); 
session_register("OnlineUser");

if(PHP_OS != "WINNT"){

	if($op == "http" && $PHP_AUTH_USER == ""){
		Header("WWW-Authenticate: Basic realm=\"��Ա��¼\"");
		Header("HTTP/1.0 401 Unauthorized");
	} 

	if($op == "reset" && !$Online){ // && $OnlineUser == ""
		$Online = true;
		Header("WWW-Authenticate: Basic realm=\"��Ա��¼\"");
		Header("HTTP/1.0 401 Unauthorized");	
	}
	if ($op == "http" || $op == "reset") {
		$Username = $PHP_AUTH_USER;
		$Password = $PHP_AUTH_PW;
		//echo $Username;echo "<br>";
		//echo $Password;echo "<br>";
	}
}

/*
echo "<br>";
echo $Online;echo "<br>";
echo $OnlineUser;echo "<br>";
*/

include ("include/global.php");
	$SQL="Select username,password from domainuser where username='$Username' and password='".md5($Password)."'";
	$result=$Domain_DB->query($SQL);
	$count=mysql_num_rows($result);
//	echo $count;

	if (!$count){
		echo "�û��������벻��ȷ�����������µ�¼<a href='#' onclick='javascript:history.go(-1)'>����</a>";
		$Online = FALSE;
	}
	else
	{
		$Online = TRUE;
		$OnlineUser = $Username;
		header("Location: admin.php");
	}

?>