<?php
/*
$noheader=1;
$nocache=0;

// get rid of slashes in get / post / cookie data
if (get_magic_quotes_gpc()==1 and is_array($GLOBALS)==1) {
  while(list($key,$val)=each($GLOBALS)) {
    if (is_string($val)==1) {
      $GLOBALS[$key]=stripslashes($val);
    }
  }
}

set_magic_quotes_runtime(0);

error_reporting(7);

if (isset($noheader)==0 or $noheader==0) {
  // default headers
  header("HTTP/1.0 200 OK");
  header("HTTP/1.1 200 OK");
  header("Content-type: text/html");
}
if ($nocache==1) {
  // no caching
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT"); // always modified
  header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
  header("Pragma: no-cache");                                   // HTTP/1.0
}
*/
// ###################### ��ʼ�� #######################
require("include/config.inc.php");

// ###################### �������԰� #######################
require("include/language/$Language");

//###################### �����������ݿ��� #################
require("include/mysql.inc.php");
$MySQL=new MySQL_Class;

$MySQL->database=$dbname;
$MySQL->server=$dbserver;
$MySQL->user=$dbusername;
$MySQL->password=$dbpassword;

$MySQL->connect();

//##################### ���� DomainName �� ########################
require ("include/privileges.inc.php");
$MysqlUser=new MySQL_User;
?>