<?
require("../include/global.inc.php");
$ftpHost = null;
$ftpPort = null;
$ftpUser = null;
$ftpPass = null;
?>
<html>
<head>
<title>Web2Ftp Client</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<!-- -->
<script language="JavaScript" src="../include/ftp.js" type="text/JavaScript"></script>
<form action="mainframe.php" method=post name="ftplogin" target="_parent" id="ftplogin" onSubmit="return checkform()">
  <p><font color="#FFFFFF"></font></p>
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="2" bgcolor="#333399" height="17"><font color="#FFFFFF">Web2Ftp 
        </font><font color="#FFFFFF">Client</font><font color="#FFFFFF">: </font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td width="15%" height="2" align="center"><? echo $ftp_host ?></td>
      <td width="85%" height="2"><input name="ftphost" type="text" id="ftphost2">
        <input name="ftpport" type="text" id="ftpport" value="21" size="6"> </td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td height="2" align="center"><? echo $ftp_user ?></td>
      <td height="2"><input name="ftpuser" type="text" ></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center"><? echo $ftp_pass ?></td>
      <td height="2"><input name="ftppasswd" type="password"> </td>
    </tr>
    <tr align="center"> 
<td height="2" colspan="2" bgcolor="#333399"> 
<input type="submit" name="Submit2" value="<?echo $login_button?>">
</td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
</body>
</html>
