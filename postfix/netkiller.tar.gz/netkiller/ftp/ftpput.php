<?
require("../include/global.inc.php");
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<form name="ftpputform" method="post" action="ftptree.php" target="ftptree" enctype="multipart/form-data">
  <fieldset>
  <legend>

  <?php echo $ftp_upload." -> [".$ftppath."]"?></legend>
  <blockquote> 
    <p> 
      <label> 
      <input name="ftpmode" type="radio" value="FTP_ASCII" checked>
      ASCII 
      <input type="radio" name="ftpmode" value="FTP_BINARY">
      BINARY </label>
    </p>
    <p>
      <label>�ļ� 
      <input name="putfile0" type="file" value="">
      </label>
    </p>
<!--	
    <label><br>
    �ļ� 
    <input name="uploadfile1" type="file" value="">
    </label>
    <label><br>
    �ļ� 
    <input name="uploadfile2" type="file" value="">
    </label>
    <label><br>
    �ļ� 
    <input name="uploadfile3" type="file" value="">
    </label>
    <label><br>
    �ļ� 
    <input name="uploadfile4" type="file" value="">
    </label>
    <label><br>
    �ļ� 
    <input name="uploadfile5" type="file" value="">
    </label>
-->	
  </blockquote>
  </fieldset>
  <input name="ftpAction" type="hidden" value="ftpput">
  <input name="ftppath" type="hidden" value="<?echo $ftppath?>">  
  <input type="submit" name="Submit" value="<?php echo $upload_button?>">
</form>

</body>
</html>
