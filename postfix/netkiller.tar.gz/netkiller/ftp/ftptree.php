<?
require("../include/global.inc.php");
?>
<html>
<head>
<title>Ftp Tree</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<!--base target="remote" -->
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<?
$list 		= array();
//echo  $ftppath;
$web_ftp 		= new FTP;
$web_ftp->host	= $ftpHost;
$web_ftp->user	= $ftpUser;
$web_ftp->pass 	= $ftpPass;
$web_ftp->port 	= $ftpPort;
$web_ftp->ftpConnect();
$ftpsystype = $web_ftp->ftpSysType();
if($web_ftp->isConnect){
	$web_ftp->ftpLogin();
	if($web_ftp->isLogin){

		if($ftppath){
			switch($ftpAction){
				case "..":
					//$web_ftp->ftppwd = substr($ftppath,0,strrpos($ftppath,"/"));
					$web_ftp->ftppwd = dirname($ftppath);
					$ftppath = $web_ftp->ftppwd;
					if(!$web_ftp->ftppwd){
						$web_ftp->ftppwd = "/";
						$ftppath = $web_ftp->ftppwd;
					}
					break;
				case "makedir":
					$web_ftp->ftpMakedir($ftppath);
					break;	
				case "delete":
					if($web_ftp->ftpDelete($ftppath))
						$ftppath = substr($ftppath,0,strrpos($ftppath,"/"));
					break;
				case "ftpput":
					//$userfile_size
					//$userfile_type
					//$putfile0_name
					//$local_file =stripslashes($putfile0);
					$remote_file = $ftppath."/".$putfile0_name;
					$web_ftp->ftpChdir($ftppath);
					$web_ftp->ftpPut($remote_file,$putfile0,$ftpmode);
					break;
			}
			/*
			if($ftpActive == ".."){
				$web_ftp->ftppwd = substr($ftppath,0,strrpos($ftppath,"/"));
				$ftppath = $web_ftp->ftppwd;
				if(!$web_ftp->ftppwd){
					$web_ftp->ftppwd = "/";
					$ftppath = $web_ftp->ftppwd;
				}
			}else if($ftpActive == "makedir"){			
				$web_ftp->ftpMakedir($ftppath);
			}else if($ftpActive == "delete"){
				if($web_ftp->ftpDelete($ftppath))
					$ftppath = substr($ftppath,0,strrpos($ftppath,"/"));
			}
			*/
			$web_ftp->ftppwd = $ftppath;
		}else{
			$ftppath = $web_ftp->ftppwd;
		}
		//echo $web_ftp->ftppwd;
		$web_ftp->ftpChdir($web_ftp->ftppwd);
		$web_ftp->ftpnList($web_ftp->ftpPwd()); 
		for ($i=0,$x=0,$y=0,$x1=0,$y1=0;$i<count($web_ftp->ftplist);$i++){
			if(is_dir($web_ftp->ftplist[$i])){
				if(is_link($web_ftp->ftplist[$i])){
					$list["dir_symbolic_link"][$x1] = $web_ftp->ftplist[$i];
					$x1++;
				}else{
					$list["dir"][$x] = $web_ftp->ftplist[$i];
					$x++;					
					//echo $web_ftp->ftplist[$i]."<br>";
				}

			}else{
				if(is_link($web_ftp->ftplist[$i])){
					$list["files_ymbolic_link"][$y1] = $web_ftp->ftplist[$i];
					$y1++;
				}else{
					$list["file"][$y] = $web_ftp->ftplist[$i];
					$y++;					
				}
	
			}

		}
	}else{
		//echo $web_ftp->ftpError();
		echo $web_ftp->analyzer_error($ftpError,$web_ftp->ftpError());
		exit;
	}
}else{
	//echo $web_ftp->ftpError();
	echo $web_ftp->analyzer_error($ftpError,$web_ftp->ftpError());
	exit;
}

$web_ftp->ftpClost();

//echo $web_ftp->host;
//echo $web_ftp->isLogin;
?>
  <script language="JavaScript1.2" src="../include/ftp.js" type="text/JavaScript1.2"></script>
  <script language="JavaScript1.2" type="text/JavaScript1.2">
  		window.parent.remote.location.href = 'remote.php?ftppath=<?echo $ftppath?>';
  </script>

<table width="100%" border="3" cellspacing="0" cellpadding="5" bgcolor="E0F0FF" class="t02" align="center" bordercolor="4FA7FF">
<tr valign="top"> 
    <td height="52" colspan="2" align="center"> 
<table width="100%" border="1" cellspacing="0" cellpadding="0" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF">
        
        <tr> 
            <td align="center"> <font size="3" face="System">Web 2 Ftp</font></td>
          </tr>
          <tr> 
            
          <td align="left"> 
            <?
//echo $web_ftp->isConnect;echo "<br>";
//echo $web_ftp->isLogin;echo "<br>";
//echo $web_ftp->isSuccess; echo "<br>";
echo $ftpsystype;echo ":"; 
echo "<a href='ftp://$ftpUser:$ftpPass@$ftpHost:$ftpPort' target='ftp'>$ftpHost</a>";
echo "<br>"; 
?>
          </td>
          </tr>
          <tr>
         </table>
        
      <table width="100%" border="1" cellspacing="0" cellpadding="2" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF">
        <form action="ftptree.php" method=post name="ftp" target="_self" id="ftp">
          <tr>
            <td><input name="ftppath" type="text" id="ftppath" value="<? echo  $ftppath ?>"> 
              <input type="submit" name="Submit" value="<?echo $go_button?>" >
              <input name="ftpAction" type="hidden" id="ftpAction" value="."></td>
          </tr> 
          <tr> 
            <td><a href="javascript:ftpcdup()"><font face='Wingdings 3' size=5 > Q  </font></a></td>
          </tr>		  
<?	
echo "<tr><td>";
	for ($i=0;$i<count($list["dir"]);$i++){
		$openpath = str_replace("//","/",$list["dir"][$i]);	
		echo "<a href=javascript:OpenLink('$openpath')>";
		//echo "<a href='ftptree.php?ftppath=$openpath') target='ftptree'>";
		echo  basename($openpath);
		echo "</a>"; 
		echo "<br>";
		
	}
echo "</td></tr>";
?>
          <tr> 
            <td>
<?	
echo "<tr><td>";
	for ($i=0;$i<count($list["dir_symbolic_link"]);$i++){
		$openpath = str_replace("//","/",$list["dir_symbolic_link"][$i]);	
		$symbolic_link = @readlink($openpath);		
		echo "<a href=javascript:OpenLink('$openpath')>";
		echo  basename($openpath);
		echo "</a>->"; 
		echo "<a href=javascript:OpenLink('$symbolic_link')>";
		echo  $symbolic_link;
		echo "</a>"; 		
		echo "<br>";
		
	}
echo "</td></tr>";
?>			
			</td>
          </tr>
</form>		  
          <tr> 
            <td align="center">
	<button TYPE="BUTTON" onclick="javascript:ftpcdup()"> <font face='Wingdings 3' size=5 > Q  </font> </button>
	<button TYPE="BUTTON" onclick="javascript:ftpMkdir('<?echo $ftppath?>')"> <font face='Wingdings  ' size=4 > 0 </font> </button>	
    <button TYPE="BUTTON" onclick="javascript:ftpDelete('<?echo $ftppath?>')"><font face='Wingdings 2' size=6 > O </font></button>
    <button TYPE="BUTTON" onclick="javascript:window.parent.remote.location.href = 'ftpput.php?ftppath=<?echo $ftppath?>'"> <font face='Wingdings 3' size=5 > X </font> </button>				
            </td>
          </tr>
        </table>
 <input type="button" name="Submit2" value="<?echo $quit_button?>" onClick="ftpQuit()">
    </td>
    </tr>
  </table>
</body>
</html>