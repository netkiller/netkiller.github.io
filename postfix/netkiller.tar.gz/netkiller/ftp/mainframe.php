<?
require("../include/global.inc.php");

$web_ftp 		= new FTP;
$web_ftp->host	= $ftphost;
$web_ftp->user	= $ftpuser;
$web_ftp->pass 	= $ftppasswd;
$web_ftp->port 	= $ftpport;
$web_ftp->ftpConnect();

if($web_ftp->isConnect){
	$web_ftp->ftpLogin();
	if($web_ftp->isLogin){
		$ftpHost = $ftphost;
		$ftpUser = $ftpuser;
		$ftpPass = $ftppasswd;
		$ftpPort = $ftpport;
		
	}else{
		echo $web_ftp->analyzer_error($ftpError,$web_ftp->ftpError());
		exit;
	}
}else{
	echo $web_ftp->analyzer_error($ftpError,$web_ftp->ftpError());
	exit;
}
$web_ftp->ftpClost();

/*
echo $ftphost;
echo $ftpport;
echo $ftpuser;
echo $ftppasswd;		
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>Ftp MainFrame</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<frameset rows="*" cols="191,599" framespacing="0" frameborder="NO" border="0">
  <frame src="ftptree.php" name="ftptree" scrolling="auto">
  <frame src="remote.php" name = "remote" scrolling="no">
</frameset>
<noframes>
<body>
</body>
</noframes>
</html>
