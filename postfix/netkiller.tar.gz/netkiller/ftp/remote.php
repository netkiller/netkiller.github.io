<?
require("../include/global.inc.php");
?>
<html>
<head>
<title>Ftp Remote</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin="0" topmargin="0">
<?

?>
<table width="100%" border="3" cellspacing="0" cellpadding="5" bgcolor="E0F0FF" class="t02" align="center" bordercolor="4FA7FF" height="0%">
  <tr valign="top"> 
    <td colspan="2" height="52"> 

	<table width="100%" border="1" cellspacing="0" cellpadding="0" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF">
        <tr> 
          <td colspan="6"> <div align="center"><font size="3" face="System">Site Manager 2.1</font></div></td>
        </tr>
<?		
	$columns=0;		
	for ($i=0;$i<count($list["dir"]);$i++){
		$openpath = str_replace("//","/",$list["dir"][$i]);	
		if($columns == 6){
			echo "</tr>";
			$columns=0;
		}else if ($columns == 0){
			echo "<tr>";		
		}
		echo "<td>";
		echo "<a href='ftptree.php?ftppath=$openpath') target='ftptree'>";
		echo  basename($openpath);
		echo "</a>"; 
		echo "</td>";
		$columns++;
	}
?>

<?
	//$columns = 6;		
	for ($i=0;$i<count($list["dir_symbolic_link"]);$i++){
		$openpath = str_replace("//","/",$list["dir_symbolic_link"][$i]);	
		$symbolic_link = @readlink($openpath);		
		if($columns == 6){
			echo "</tr>";
			$columns=0;
		}else if ($columns == 0){
			echo "<tr>";		
		}
		echo "<td>";		
		echo "<a href='ftptree.php?ftppath=$openpath') target='ftptree'>";
		echo  basename($openpath);
		echo "</a>->"; 
		echo "<a href='ftptree.php?ftppath=$symbolic_link') target='ftptree'>";
		echo  $symbolic_link;
		echo "</a>"; 		
		echo "</td>";
		$columns++;
	}
?>
	</table>	
	
	<table width="100%" border="1" cellspacing="0" cellpadding="2" class="t02" bordercolorlight="4FA7FF" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" height="7%">

    <?
	$columns = 0;			
	for ($i=0;$i<count($list["file"]);$i++){
		$openpath = str_replace("//","/",$list["file"][$i]);
		if($columns == 6){
			echo "</tr>";
			$columns=0;
		}else if ($columns == 0){
			echo "<tr>";		
		}
		$columns++;
		echo "<td>";			
		echo "<a href='ftp://$ftpUser:$ftpPass@$ftpHost:$ftpPort$openpath'>";		
		echo  basename($openpath);
		echo "</a>"; 
		echo "</td>";		
	}	
	?>

<?
	//$columns = 6;		
	for ($i=0;$i<count($list["files_ymbolic_link"]);$i++){
		$openpath = str_replace("//","/",$list["files_ymbolic_link"][$i]);	
		$symbolic_link = @readlink($openpath);		
		if($columns == 6){
			echo "</tr>";
			$columns=0;
		}else if ($columns == 0){
			echo "<tr>";		
		}
		echo "<td>";		
		echo "<a href='ftp://$ftpUser:$ftpPass@$ftpHost:$ftpPort$openpath'>";
		echo  basename($openpath);
		echo "</a>->"; 
		echo "<a href='ftp://$ftpUser:$ftpPass@$ftpHost:$ftpPort$symbolic_link'>";
		echo  $symbolic_link;
		echo "</a>"; 		
		echo "</td>";
		$columns++;
	}
?>	
      </table>
	  </td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
