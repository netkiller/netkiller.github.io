<?
require("../include/global.inc.php");

$ftpHost = null;
$ftpPort = null;
$ftpUser = null;
$ftpPass = null;

Header("Location: ../");  
//exit;
?>
<html>
<head>
<title>Ftp Quit</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

<body>

</body>
</html>
