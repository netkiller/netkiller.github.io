<html>
<head>
<title>Site Manager</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="style.css" type="text/css">
<base target="main">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<?
require("./include/ldap.inc.php");
if($passwd){
	$enpw 		= crypt($passwd,$salt);
	$shadow		= crypt($passwd,"$1$".$salt);
	$BLOWFISH	= crypt($passwd,"$2$".$salt);
	$md5hash 	= md5($passwd);
	$enbase64 	= base64_encode($passwd);
	$debase64 	= base64_decode($passwd);	
	$debase64 	= base64_decode($passwd);	
	$ChineseName = $passwd;
	$EncoenStr 	= urlencode($ChineseName);
	$EncodeStr 	= urldecode($ChineseName);	
	$rawurlen 	= rawurlencode($ChineseName);
	$rawurlde 	= rawurldecode($ChineseName);
	
	$ldapcode 	= new ldap;
	$utfencode 	= $ldapcode->gb18030_utf8($ChineseName);
	$gbdecode 	= $ldapcode->utf8_gb18030($ChineseName);
	//echo $ldapcode->utf8_gb18030($utfencode);
//	$iconvs 	= iconv("gb2312","UTF-8",$ChineseName);
//ISO-8859-1

}	

?>
<form method=post action="<?echo $PHP_SELF?>">
<p>&nbsp;</p>
  <table width="95%" border="0" align="center">
    <tr> 
      <td colspan="3" bgcolor="#333399" height="17"><font color="#FFFFFF">����/���빤��: 
        <??>
        </font></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td width="15%" height="2" align="center">���룺</td>
      <td height="2" colspan="2"> <input name=passwd type=text size=50> </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">CRYPT_STD_DES</td>
      <td width="31%" height="2"> <?echo "$enpw";?></td>
      <td width="54%">&nbsp;salt 
        <input name="salt" type="text" id="salt" value="salt"></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="20" align="center">CRYPT_MD5</td>
      <td height="20"><? echo $shadow?></td>
      <td height="20">*(Unix like Shadow)</td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">CRYPT_BLOWFISH</td>
      <td height="2"><? echo $BLOWFISH?></td>
      <td height="2">&nbsp;</td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">MD5 ��ϡ</td>
      <td height="2" colspan="2"> <? echo $md5hash?> </td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">BASE64</td>
      <td height="2">���룺<?echo $enbase64?></td>
      <td height="2">���룺<?echo $debase64?></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">URL </td>
      <td height="2">���룺<?echo $EncoenStr?></td>
      <td height="2">���룺<?echo $EncodeStr ?></td>
    </tr>
    <tr bgcolor="#CCCCCC"> 
      <td height="2" align="center">UTF-8</td>
      <td height="2"> ���룺<? echo $utfencode;	?> </td>
      <td height="2">���룺<? echo $gbdecode?></td>
    </tr>
    <tr> 
      <td colspan="3" bgcolor="#333399" height="2"> <div align="center"> 
          <input type="submit" name="Submit" value="Submit">
        </div></td>
    </tr>
  </table>
  <p>&nbsp; </p>
</form>
</body>
</html>

