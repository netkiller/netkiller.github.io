<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>Role Test</title>
</head>

<body>
<?
define("IN_LOGIN", true);
define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

include("includes/role.php");

echo "ȡ���û������ڽ�ɫ";echo "<br>";
echo getRole("admin");
echo "<br>";
//=======================================================================
echo "�û���֤�������û��������롣�����֤ͨ������true,ʧ�ܷ��ؼ�<br>";
echo LoginAuth("admin","chen");
//echo LoginAuth("netkiller",md5("chen"));
echo "<br>";
//=======================================================================
echo "�����û�����<br>";
//addUser("netkiller",md5("chen"),"�¾���","Netkiller","true","netkiller@gdfz.com","name","chen","2003-9-10","2003-9-10");
echo "<br>";
//=======================================================================
echo "get �û�����<br>";echo "Array:<br>";
$userinfo = getUserInfo(3);
//getUserId($username)
$count	= count($userinfo);
for ($i=0;$i<$count;$i++){
	echo $userinfo[$i]."<br>";
}
echo "<br>";
//=======================================================================

?>

</body>
</html>
