<?php
/*
	netkiller 2003-10-21 
*/
define("IN_LOGIN", true);
//define('IN_PHPBB', true);
$phpbb_root_path = '../';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include("../includes/user.php");
if(isCheckUserExist($username)){
	echo "<script>alert('���û����Ѿ����ڣ�����ѡ���û�����'),history.back();</script>";
}
//require("../newconn.php");
/*
include ("../../inc/db_mysql.php"); 

$db = new DB_Sql;
$sql="select * from user where name='".$username."'";
$result=$db->query($sql);
$rows=$db->next_record();
if($rows>0)	echo "<script>alert('���û����Ѿ����ڣ�����ѡ���û�����'),history.back();</script>";
*/
if ($biaoji=="com")
{
	//header ("location:regist_com.php?username=$username&biaoji=$biaoji");
	$url = "regist_com.php?username=$username&biaoji=$biaoji";
}
else 
{
	//header("location:regist_per.php?username=$username&biaoji=$biaoji");
	$url = "regist_per.php?username=$username&biaoji=$biaoji";
}
echo "<meta http-equiv=\"refresh\" content=\"0;URL=$url\">";

?>