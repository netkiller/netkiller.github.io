<html>
<head>
<title>�㶫��װ��_www.gdfz.com_��Աע��</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="link.css" rel="stylesheet" type="text/css">

<SCRIPT LANGUAGE="JavaScript">
<!--
/*

��׼�û�ע���麯��
Programed By Wang Xiaofei love_xian@163.com 2003.7.23

*/
function check()
{
	//��������
	var i;
	var char;
	var badword;
	badword= '@%+.;|<>`&!*(~^)-#? :"/$=\\'+"'"

	
	//��֤
	var username=form.username.value;
	if (username=="")
	{
		alert("�û�������Ϊ�գ�");
		form.username.focus();
		return false;
	}

    
	for(i=0;i<username.length;i++){
			char=username.charAt(i);
			
		if(char == " "||char == "��"){
			alert("�û����д��ڿո񣬰���ȥ�����𣿣�");
			form.username.focus();
			return false;
		}
		
		if (badword.indexOf(char)>=0) {
			alert ("�û����д��ڲ������ַ�  "+char+"  ����ȥ�����𣿣�");
			form.username.focus();
			return false;
		}
		
	}

	if (username.length<2 || username.length>12)
	{
		alert("λ������Ŷ���û�������ӦΪ2-12���ַ��������");
		form.username.focus();
		return false;
	}
}


function back()
{
	window.location="step1.php";
}

//-->
</SCRIPT></head>

<body background="../images/bg_1.gif" leftmargin="0" topmargin="0">
<?include "../../inc/head.php"?>
<TABLE width="776" align=center cellPadding=3 cellSpacing=1 class=y1tem>
  <TBODY>
    <TR> 
      <TD width="212" height=40 vAlign=middle bgcolor="#FFFFFF"><IMG src="images/Forum_nav.gif" width="19" height="19" 
      align=absMiddle> �û�ע�� <A name=top></A></TD>
    </TR>
  </TBODY>
</TABLE>
<TABLE cellSpacing=0 cellPadding=0 width="776" align=center border=0>
  <TBODY>
    <TR> 
      <TD width="174" bgcolor="#FFFFFF"><IMG height=23 src="images/skintop1.gif" 
width=174></TD>
      <TD width="594" background=images/skintop2.gif>&nbsp;</TD>
      <TD width="175"> <div align="left"><IMG height=23 src="images/skintop3.gif" 
      width=174></div></TD>
    </TR>
  </TBODY>
</TABLE>
<?php
if($hidd<>"iagree") echo "<script>back();</script>";
?>
<TABLE width="775" align=center cellPadding=3 cellSpacing=1 bgcolor="#000000" class=tableborder1>
  <TBODY>
    <TR> 
      <TH width="984" align=middle bgcolor="#E3EDEE"> <font size="3">��ѡ���û�����</font>
    </TR>
    <TR> 
      <TD align=left bgcolor="#F9FBFB" class=y1tem><FORM action="brage.php" method=post name=form onsubmit="return check();">
          <table width="80%" border="0" cellspacing="1" cellpadding="4" align="center">
            <tr> 
              <td align="center"> <table border="0" width="500" align="center" cellpadding="3" class="font_12" cellspacing="0">
                  <tr class="y3-green"> 
                    <td width="37%" height="32" align="right" valign="bottom">�û�����</td>
                    <td width="63%" height="32"  colspan="2" valign="bottom"> 
                      <font color="#000000">
                      
                    <input name="username" type="text" size="16" style="BORDER-BOTTOM: #000000 1px solid; BORDER-LEFT: #000000 1px solid; BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid; COLOR: #4267b5">
                      </font> </td>
                  </tr>
                  <tr class="y3-green"> 
                    <td width="37%" align="right">&nbsp;</td>
                    <td width="63%"  colspan="2">&nbsp;</td>
                  </tr>
                  <tr class="y3-green"> 
                    <td width="37%" align="right" valign="bottom">�û����ʣ�</td>
                    
                  <td width="63%"  colspan="2" valign="bottom"> ��ҵ 
                    <input type="radio" name="biaoji" value="com" checked> &nbsp;&nbsp;&nbsp;&nbsp; 
                      ���� 
                      <input type="radio" name="biaoji" value="per"> </td>
                  </tr>
                  <tr class="y3-green"> 
<td height="10" colspan="3">* �Ϸ����û���Ӧ����<font color=red>���֡�a-z��Ӣ����ĸ(�����ִ�Сд)��
0-9�����ֺ��»���</font>��ɡ�<font color=red>�û�������Ϊ2-12���ַ�֮��</font>��<b>����ʹ�ÿհ׼�������ʹ��ĳЩ�����ִ���Ϊ�û�����</b></td>
                  </tr>
                  <tr align="center"> 
                    <td colspan="3"> <input type="submit" name="enter" value="ȷ��" class="button"> 
                      &nbsp;&nbsp;&nbsp;<input type="reset" name="reset" value="ȡ��" class="button"> 
                    </td>
                  </tr>
                </table></td>
            </tr>
          </table>
        </form></TD>
    </TR>
  </TBODY>
</TABLE>
<TABLE cellSpacing=0 cellPadding=0 width="776" align=center border=0>
  <TBODY>
    <TR> 
      <TD width="68"><IMG height=18 src="images/skintop4.gif" width=68></TD>
      <TD width="685" background="images/skintop5.gif">&nbsp;</TD>
      <TD width="190"> <div align="left"><IMG height=18 src="images/skintop6.gif" 
      width=189></div></TD>
    </TR>
  </TBODY>
</TABLE>
<?include "../../inc/tail.php"?>
</body>
</html>
