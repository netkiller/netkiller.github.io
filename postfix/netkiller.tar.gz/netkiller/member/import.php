
<?

function message_die($var1,$var2){
	echo "$var1,$var2";
}
//$dbms = 'postgres';

$dbhost = 'localhost';
$dbname = 'gdfz';
$dbuser = 'root';
$dbpasswd = '';
define("SQL_LAYER","mysql4");
include('db/mysql4.php');
$mydb = new sql_db($dbhost, $dbuser, $dbpasswd, $dbname, true);
if(!$mydb->db_connect_id)
{
   message_die(CRITICAL_ERROR, "Could not connect to the database");
   exit;
}


?>