<?php
/*

mysql 
mysql4 
postgres 
mssql 
oracle 
msaccess 
mssql-odbc

*/

$dbms = 'postgres';

$dbhost = 'localhost';
$dbname = 'member';
$dbuser = 'chen';
$dbpasswd = 'chen';

$table_prefix = 'public.';

define('PHPBB_INSTALLED', true);

?>