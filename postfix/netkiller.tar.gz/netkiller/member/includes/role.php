<?php
/***************************************************************************
 *                             role.php
 *                        -------------------
 *   begin                : 2003-8-27
 *   copyright            : (C) 2003 www.gdfz.com
 *   author				  : netkiller
 *   email                : netkiller@9812.net
 *   QQ			  		  : 13721218
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 * ��Ա����ϵͳ��ɫ�����ӿ�
 *
 ***************************************************************************/

function getRoleArray($uid)
{
	global $db;
	$sql = "select rolename from vrolemember where userid=$uid"; 

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	$count=$db->sql_numrows();
	
	for ($i=0;$i<$count;$i++){
		if( $row = $db->sql_fetchrow($result) ){
			$tmp[$i] = $row['rolename'];
		}
	}
	return $tmp;
}

/*
	�ж��û��Ƿ�����ĳ��ɫ
*/
function getRole($uid,$role)
{
	global $db;
	$sql = "select * from vrole where uid=$uid and rolename='$role'";

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	$count=$db->sql_numrows($result);
	if ($count>=1){
		return true;
	}else{
		return false;
	}
}

function getRoleMember($rolename){
	global $db;
	$sql = "select * from vrolemember where rolename='$rolename'";

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	$i=0;
	while( $row = $db->sql_fetchrow($result) ){
		$tmp[$i]['rid'] 	 = $row['rid'];
		$tmp[$i]['rolename'] = $row['rolename'];
		$tmp[$i]['uid'] 	 = $row['uid'];
		$tmp[$i]['userid'] 	 = $row['userid'];
		$tmp[$i]['name'] 	 = $row['name'];
	}
	return $tmp;
}
?>
