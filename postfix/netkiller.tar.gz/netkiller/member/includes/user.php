<?php
/***************************************************************************
 *     	                      user.php
 *                        -------------------
 *   begin                : 2003-8-27
 *   copyright            : (C) 2003 www.gdfz.com
 *   author				  : netkiller
 *   email                : netkiller@9812.net
 *   QQ			  		  : 13721218
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *
 *
 ***************************************************************************/

if ( !defined('IN_LOGIN') )
{
	die("Hacking attempt");
	exit;
}

function isCheckUserExist($user){
	
	global $db;
	$sql = "select * from \"user\" where userid='$user'";

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	$count=$db->sql_numrows($result);
	if ($count>=1){
		return true;
	}else{
		return false;
	}
}

function LoginAuth($user,$passwd,$type="cleartext"){
	global $db;
	switch(type){
		case "md5":
			$sql = "select * from \"user\" where userid='$user' and active='true' and passwd=md5('$passwd')";
			break;
		case "backend":
			$sql = "select * from \"user\" where userid='$user' and active='true' and passwd=password('$passwd')";
			break;
		case "crypt":
			break;
		default:
			$sql = "select * from \"user\" where userid='$user' and active='true' and passwd='$passwd'";
	}
	

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	$count=$db->sql_numrows($result);
	if ($count>=1){
		return true;
	}else{
		return false;
	}	
}
function addUser1($user,$passwd,$name,$nickname,$active="false",$email,$question,$answer,$begin_date,$end_date){
	global $db;
	$name = iconv( 'GB2312','UTF-8', $name );
	$sql = "insert into \"user\"(userid,passwd,name,nickname,active,email,question,answer,begin_date,end_date) values('$user','$passwd','$name','$nickname','$active','$email','$question','$answer','$begin_date','$end_date')";

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
}

function addUser2($user,$passwd,$name,$nickname,$active="false",$email){
	global $db;
	$name = iconv( 'GB2312','UTF-8', $name );
	$sql = "insert into \"user\"(userid,passwd,name,nickname,active,email,question,answer) values('$user','$passwd','$name','$nickname','$active','$email','question','answer')";
	//echo $sql."<br>";
	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
};

function getUserInfo($uid){
	global $db;
	$sql = "select * from \"user\" where userid='$uid'"; 
	
//	$codesql = "set CLIENT_ENCODING TO 'EUC_CN';";
//	$codesql = "set CLIENT_ENCODING TO 'BIG5';";
	$codesql = "set CLIENT_ENCODING TO 'GB18030';";
	$db->sql_query($codesql);
	
	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Could not \'select\' userdata', '', __LINE__, __FILE__, $sql);
	}
	$count=$db->sql_numrows();
	
	for ($i=0;$i<$count;$i++){
		if( $row = $db->sql_fetchrow($result) ){
			$tmp[0] = $row[0];
			$tmp[1] = $row[1];
			$tmp[2] = $row[2];
//			$tmp[3] = iconv( 'UTF-8', 'GBK', $row[3] ); 
			$tmp[3] = $row[3]; 
			$tmp[4] = $row[4];
			$tmp[5] = $row[5];
			$tmp[6] = $row[6];
			$tmp[7] = $row[7];
			$tmp[8] = $row[8];
			$tmp[9] = $row[9];
			$tmp[10] = $row[10];
		}
	}
	return $tmp;
};

function chPassword($user,$pass){
	global $db;
	$sql = "Update \"user\" set passwd = '$pass' where userid = '$user'";
	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
}

?>