<?php
/***************************************************************************
 *                           trust.php
 *                        -------------------
 *   begin                : 2003-8-27
 *   copyright            : (C) 2003 www.gdfz.com
 *   author		  : netkiller
 *   email                : netkiller@9812.net
 *   QQ			  : 13721218
 *
 *
 ***************************************************************************/

/***************************************************************************
 * ��Ա����-ģ��
 ***************************************************************************/

if ( !defined('IN_PHPBB') )
{
	die('Hacking attempt');
	exit;
}

//include("includes/db.php");

/*
    ���� �û�id
    return ���ż���
    
    ��Ա���Žӿ�,ͨ���û�ID���ó��ż���
*/
function getTrust($uid){
	global $db;
	$sql = "select rate from trust where uid=".$uid;
	$rate = 0;

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	if( $row = $db->sql_fetchrow($result) ){
		$rate = $row['rate'];
	}
	
    return $rate;
}


?>