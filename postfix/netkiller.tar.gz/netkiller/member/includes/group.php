<?php

/***************************************************************************
 *                             group.php
 *                        -------------------
 *   begin                : 2003-8-29
 *   copyright            : (C) 2003 www.gdfz.com
 *   author				  : netkiller
 *   email                : netkiller@9812.net
 *   QQ			  		  : 13721218
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 * ��Ա����ϵͳ-������ӿ�
 *
 ***************************************************************************/

if ( !defined('IN_LOGIN') )
{
	die('Hacking attempt');
	exit;
}

/*
	ͨ��$uidȡ���û�����������
	��������
*/
function getGroupArray($uid){
	global $db;
	$sql = "select groupname from vgroupmember where userid=$uid";
	
	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	
	$count=$db->sql_numrows();
	
	for ($i=0;$i<$count;$i++){
		if( $row = $db->sql_fetchrow($result) ){
			$tmp[$i] = $row['groupname'];
		}
	}
	return $tmp;	

}

/*
	�ж��û��Ƿ���������
*/
function getGroup($uid,$group){
	global $db;
	$sql = "select * from vrole where uid=$uid";
	$tmp = null;

	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
	$count=$db->sql_numrows($result);
	if ($count>=1){
		return true;
	}else{
		return false;
	}
}

function addGroupMember($user,$group){
	global $db;
	$sql = "insert into groupmember(gid,uid) values((select id from \"group\" where groupname ='$group'),(select id from vuser where userid='$user'))";
	if ( !($result = $db->sql_query($sql)) ){
		message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
	}
}

?>