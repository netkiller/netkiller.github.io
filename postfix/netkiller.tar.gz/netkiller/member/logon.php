<?php
session_start();
session_register("session_name","session_level","session_userid","session_mailnum");

define("IN_LOGIN", true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

include("includes/user.php");
//include("includes/role.php");
//include("includes/group.php");
	$isLogon = false;
	if(isCheckUserExist($name)){
		if(LoginAuth($name,$pass)){
//			$session_role	= getRoleArray($name);
//			$session_group 	= getGroupArray($name);
			$userinfo		= getUserInfo($name);
			echo $session_role."<br>";
			echo $session_group."<br>";
			//getUserId($username)
			//$count	= count($userinfo);
			/*
			for ($i=0;$i<$count;$i++){
				echo $userinfo[$i]."<br>";
			}*/
			
			$session_userid= $userinfo[0];
			$isLogon = true;
		}else{
			echo "���벻��ȷ��";
		}
	}else{
		echo "�û������ڣ�";
	}

$LOGIN_URL='<script language="javascript">self.parent.location.href="../"</script>';

function error($info)
{
	echo"<table width=378 border=0 align=center cellpadding=0 cellspacing=0>
<tr>
   <td><img name=error_r1_c1 src=../images/error_top.gif width=378 height=42 border=0></td>
</tr>
<tr>
   <td bgcolor=#4CBFFF><div align=center><font color=#FFFFFF size=5 face=����_GB2312><strong>$info</strong></font></div></td>
</tr>
<tr>
    <td><img src=../images/error_bottom.jpg width=378 height=141></td>
</tr>
</table>
	";
}
include ("../inc/db_mysql.php"); 
$db = new DB_Sql;

	$db->query("select * from user where name='$name'");
	if($db->next_record())
	{
		//if ($db->Record["password"] == $pass)
		if ($isLogon)
		{
			//$session_name = $db->Record["name"];
			$session_name = $name;
			$session_level = $db->Record["flag"];
			//$session_userid= $db->Record["id"];
			$session_mailnum=$db->Record["mailnum"];
            echo $LOGIN_URL;
		}
		else
		{
			error("���벻��Ү,����ȷ���룡<br><a href=/member/getpassword.php><font color=white>����˴��һ�����</font></a>");
			//$errpass= "<center><font color=red>&nbsp;&nbsp;���벻��Ү,����ȷ���룡</font></center>";
		    //echo $errpass;
			//$pass=1;
		}
	}
	else
	{ 
		error("�û��������ڣ�����ȷ���룡<br><a href=/><font color=white>����</font></a>");
		//$erruser="<center><font color=red>&nbsp;&nbsp;�û��������ڣ�����ȷ���룡</font></center>";
		//echo $erruser;
	}



?>
<!-- <div align="center">
<a style="cursor:hand" onClick="window.open('/member/getpassword.php','','top=100,left=100,width=400,height=200,scrollbars=1')"><b>&gt;&gt; 
                                    ����˴��һ�����</b></a> </div> -->
<!-- <a href=member/getpassword.php target=_blank>����˴��һ�����</a> -->
<?//}?>