<title>Member Test</title>
<?
define("IN_LOGIN", true);
 define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

/*
$sql = "SELECT * FROM users";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error in obtaining userdata', '', __LINE__, __FILE__, $sql);
}

if( $row = $db->sql_fetchrow($result) ){
	echo $row['userid'];
}
*/

//=======================================================================

include("includes/role.php");
/*
	�ж��û��Ƿ�����ĳ��ɫ
*/
echo "getRole(5,\"select\")��".getRole(5,"select")."<br>";

echo "Array:<br>";
$array = getRoleArray(1);
$count	= count($array);
for ($i=0;$i<$count;$i++){
	echo $array[$i]."<br>";
	//['rolename']
}

//=======================================================================
include("includes/group.php");
/*
	ͨ��$uidȡ���û�����������
	��������
*/

$array = getGroupArray(5);
$count	= count($array);
for ($i=0;$i<$count;$i++){
	echo $array[$i]."<br>";
}

echo "getGroup(5,\"Guest\")��".getGroup(5,"Guest")."<br>";

//=======================================================================

?>