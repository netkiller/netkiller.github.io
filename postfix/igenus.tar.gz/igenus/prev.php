<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: prev.php,v 1.17 2003/01/15 02:36:00 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "include/prev_inc.php";

/* ��ڲ���: 	
 *				Mailbox	����
 *				Num		�ʼ����
 *				Lang	����
 */
$get_Mailbox = trim($HTTP_GET_VARS['Mailbox']);
$get_Num     = trim($HTTP_GET_VARS['Num']);
$get_Lang    = trim($HTTP_GET_VARS['Lang']);

// ��� $get_Mailbox �����Ŀɿ��ԣ����������б��ļ���
if( !(list($listfile,$SMailbox) = GetMailboxFolder($get_Mailbox)) ) die("��Ч���������!");
$listfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$listfile";

//�� list �ļ��ж�ȡ�ʼ�������Ϣ
($FD_LIST = fopen($listfile,"r"))||die("Error open list file!");
$i=0;
while(!feof($FD_LIST)){
	$line = fgets($FD_LIST,1024);
	$i++;
	if( $i==$get_Num ) break;
}
fclose($FD_LIST);
if(empty($line)) die("Error read list file!");
if($i>$get_Num) die("����������Ч���ʼ����");

list($n,$Key,$IsNew,$File,$FromName,$From,$Subject,$Date,$Size,) = split("\t",$line,10);
list($null,$Date) = Date2Str($Date,$CFG_GMT);

$mailfile = "$G_HOME$SMailbox/$IsNew/$File";

if(!file_exists($mailfile)) $mailfile = "$G_HOME$SMailbox/cur/$File";
($FD_MAIL = fopen($mailfile,"r"))	|| die("Error open mail file $file!");

	$header = Parse_head_List($FD_MAIL);
//	print_r($FD_MAIL);
//	print_r($header);

//	$From 		= $header["fromemail"];
//	$FromName 	= $header["fromname"];
	$To 		= $header["to"];
	$Content_Type = strtolower($header["content-type"]);
	$Boundary	= $header["boundary"];
	$Content_Transfer_Encoding = strtolower($header["content-transfer-encoding"]);
	$Charset	= $header["charset"];
	$Subject	= $header["subject"];
	unset($header);		// Free memory
	
	$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";
	RemoveBody($bodylistfile); // remove body part prev or next mail

	// �� list_body �ļ�
	($FD_BODYLIST = fopen("$bodylistfile","w+")) || die("Error open body list file");
	
	$out = "$FromName\t$From\t$Subject\t$Date\t$Size\t$Content_Type\t$Content_Transfer_Encoding\n";
	fputs($FD_BODYLIST, $out);

	// decode body
	// ��ڲ�����$Content_Type, $FD_MAIL, $FD_BODYLIST
	
	if( preg_match("/^multipart/",$Content_Type) && empty($Boundary) ) $Content_Type = '';	
	
	switch($Content_Type){
		case "multipart/mixed":
		case "multipart/related":
		case "multipart/alternative":
		case "multipart/report":
			Decode_multipart($FD_MAIL,$FD_BODYLIST,$Boundary,$Content_Type);
			break;
			
		case "text/html":
			Decode_text($FD_MAIL,$FD_BODYLIST,"unknown.html",$Content_Transfer_Encoding,$Content_Type);
			break;
		
		case "text/plain":
		case "":
		default:
			Decode_text($FD_MAIL,$FD_BODYLIST,"unknown.txt",$Content_Transfer_Encoding,$Content_Type);
	}
fclose($FD_BODYLIST);
fclose($FD_MAIL);

if( $CFG_Prev_IsRead=='yes' ){
// Move mail file from new to cur
if($IsNew == "new" && file_exists("$G_HOME$SMailbox/new/$File")) {
	@link("$G_HOME$SMailbox/new/$File",
			"$G_HOME$SMailbox/cur/$File");
	@unlink("$G_HOME$SMailbox/new/$File");	
}
}
?>
<HTML>
<HEAD>
<TITLE> <?php echo $Subject;?> </TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<FRAMESET ROWS="92,*" FRAMEBORDER="NO" BORDER="0" FRAMESPACING="0"> 
  <FRAME NAME="Header" SCROLLING="NO" SRC=<?php echo "header.php?Mailbox=$get_Mailbox&Num=$get_Num&Lang=$get_Lang";?> NORESIZE>
  <FRAME NAME="Body" SRC=<?php echo "read.php?Mailbox=$get_Mailbox&Num=$get_Num&Type=$Content_Type";?>>
</FRAMESET>
<NOFRAMES>
</NOFRAMES>
</HTML>
