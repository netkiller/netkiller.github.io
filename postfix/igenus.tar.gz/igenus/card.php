<?php
 
/*Id*/

//include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";



?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>������Ƭ����</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus1.css" TYPE="TEXT/CSS">
</head>

<body bgcolor="#5A8C52" text="#000000">
<SCRIPT>
<!--
function DelAddr(id,name,email){
	if(confirm("�Ƿ�ɾ����ϵ�� " + name + 
		" �ĵ����ʼ� "+email +" ?")){
		document.List.action = "add2card.php?Cmd=Del&id="+id;
		document.List.submit();
	}
	else return false;
}

function Add(form){
	str = '';
	if(form.AddrName.value=='') str += "��ϵ��/�ǳ�\n";
	if(form.AddrEmail.value=='') str += "�����ʼ�\n";
	if(str!=''){
		str = "����д�����¸���:\n" + str;
		alert(str);
		return false;
	}
	form.action = "add2card.php?Cmd=Add";
	form.submit();
}

function Modify(form){
	str = "";
	if(form.AddrName3.value=='' || form.AddrEmail3.value==''){
		alert("��Ч���޸�!");
		return false;
	}

	if(form.AddrName2.value=='') str += "��ϵ��/�ǳ�\n";
	if(form.AddrEmail2.value=='') str += "�����ʼ�\n";
	if(str!=''){
		str = "����д�����¸���:\n" + str;
		alert(str);
		return false;
	}
	form.action = "add2card.php?Cmd=Modify";
	form.submit();
}

function Go2Modi(name,email,CardCName,CardAddr,CardJob,CardTel,CardMobile,CardBearing,CardNote){
	document.modifyForm.AddrName2.value = name;
	document.modifyForm.AddrName3.value = name;
	document.modifyForm.AddrEmail2.value = email;
	document.modifyForm.AddrEmail3.value = email;
	document.modifyForm.CardCName2.value = CardCName;
	document.modifyForm.CardCName3.value = CardCName;
	document.modifyForm.CardAddr2.value = CardAddr;
	document.modifyForm.CardAddr3.value = CardAddr;
	document.modifyForm.CardJob2.value = CardJob;
	document.modifyForm.CardJob3.value = CardJob;
	document.modifyForm.CardTel2.value = CardTel;
	document.modifyForm.CardTel3.value = CardTel;
	document.modifyForm.CardMobile2.value = CardMobile;
	document.modifyForm.CardMobile3.value = CardMobile;
	document.modifyForm.CardBearing2.value = CardBearing;
	document.modifyForm.CardBearing3.value = CardBearing;
	document.modifyForm.CardNote2.value = CardNote;
	document.modifyForm.CardNote3.value = CardNote;

	MMDIV.style.display = '';
	MMDIV2.style.display = 'none';
}

function CloseModi(){
	MMDIV2.style.display = '';
	MMDIV.style.display = 'none';
}
//-->
</SCRIPT>
<BODY BGCOLOR="#DE9C02" TEXT="#000000" LEFTMARGIN="4" TOPMARGIN="4" MARGINWIDTH="2" MARGINHEIGHT="2">
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR> 
    <TD><B><FONT COLOR="#FFFFFF">������Ƭ����</FONT></B> 
    </TD>
    <TD ALIGN="RIGHT"><B> <INPUT TYPE="BUTTON" VALUE="�ر�" CLASS="myinput2" 
      onClick="window.close()"> </TD>
  </TR>
  <TR> 
    <TD colspan="2">
	<form action="#" method="post">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><B><FONT COLOR="#FFFFFF">�ؼ���</FONT></B> <INPUT TYPE="text" CLASS="myinput2" name="key"></td>
          <td><B><FONT COLOR="#FFFFFF"> ��� </font></B></td>
          <td><select name="class" CLASS="myinput2">
        <option value="1"> ���� </option>
        <option value="2"> ��ϵ </option>
        <option value="3"> ��ַ </option>
        <option value="4"> �绰 </option>
      </select></td>
          <td width="23%"><input type="submit" value="����" CLASS="myinput2"></td>
        </tr>
      </table>
	 </form>
	   </TD>
  </TR>
</TABLE>
<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="100%" ALIGN="CENTER">
  <FORM NAME="List" METHOD="post" ACTION="">
    <TR BGCOLOR="#FFCC00" ALIGN="CENTER"> 
      <TD HEIGHT="22" bgcolor="#5A8C52"> <B><A HREF='?sortby=name&page=0&direct=up'> 
        ��&nbsp;ϵ&nbsp;��</A></B> </TD>
      <TD bgcolor="#5A8C52"><B><A HREF='?sortby=email&page=0&direct=up'> �����ʼ�</A></B> 
      </TD>
	  <TD bgcolor="#5A8C52"><B><A HREF='?sortby=bearing&page=0&direct=up'> ��ϵ</A></B> 
      </TD>
	  <TD bgcolor="#5A8C52"><B>����</B></TD>
  </TR>
    </FORM>
</TABLE>

<BR>
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR>
    <TD>&nbsp;</TD>
    <TD ALIGN="RIGHT"> 
          </TD>
  </TR>
</TABLE>
<TABLE WIDTH=100%>
  
    <TR ID="MMDIV" STYLE="DISPLAY:none"> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        <FORM NAME="modifyForm" METHOD="post" ACTION="javascript:return false;">
          <TR> 
            <TD><B><FONT COLOR="#FFFFFF">
            <A NAME="Modify"></A>�޸���ϵ��-&gt;&gt;&gt;��</FONT></B></TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;ϵ&nbsp;��:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="AddrName2" CLASS="myinput2">
			  <INPUT TYPE="hidden" NAME="AddrName3">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��˾����:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="CardCName2" CLASS="myinput2">
              <INPUT TYPE="hidden" NAME="CardCName3">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;ַ:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="CardAddr2" CLASS="myinput2">
              <INPUT TYPE="hidden" NAME="CardAddr3">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">ְ&nbsp;&nbsp;&nbsp;&nbsp;��:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="CardJob2" CLASS="myinput2">
              <INPUT TYPE="hidden" NAME="CardJob3">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;��:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="CardTel2" CLASS="myinput2">
              <INPUT TYPE="hidden" NAME="CardTel3">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;��:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="CardMobile2" CLASS="myinput2">
              <INPUT TYPE="hidden" NAME="CardMobile3">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">�����ʼ�:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="AddrEmail2" CLASS="myinput2">
              <INPUT TYPE="hidden" NAME="AddrEmail3">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;ϵ:</FONT></TD>
            <TD> 
			  <select name="CardBearing2" CLASS="myinput2" id="CardBearing">
                <option value="1" selected>����</option>
                <option value="2">����</option>
                <option value="3">ͬ��</option>
                <option value="4">�ͻ�</option>
                <option value="5">����</option>
              </select> 
              <INPUT TYPE="hidden" NAME="CardBearing3">
              <INPUT name="BUTTON" TYPE="BUTTON" CLASS="myinput" 
              onClick="CloseModi();return false" VALUE="ȡ��"> 
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;ע:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="CardNote2" CLASS="myinput2">
              <INPUT TYPE="hidden" NAME="CardNote3">
              <INPUT TYPE="button" VALUE="�޸�" 
              onClick="Modify(this.form);return false" CLASS="myinput">
            </TD>
          </TR>
        </FORM>
        </TABLE>
      </TD>
    </TR>
    <TR ID="MMDIV2" STYLE="DISPLAY:">
      <TD>
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        <FORM NAME="addForm" METHOD="post" ACTION="javascript:return false;">
          <TR> 
            <TD><B><FONT COLOR="#FFFFFF">������ϵ��-&gt;&gt;&gt;��</FONT></B></TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;ϵ&nbsp;��:</FONT></TD>
            <TD> <input type="text" name="AddrName" value='' class="myinput2"></TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��˾����:</FONT></TD>
            <TD> 
              <INPUT NAME="CardCName" TYPE="text" CLASS="myinput2" id="CardCName" VALUE=''>
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;ַ:</FONT></TD>
            <TD> 
              <INPUT NAME="CardAddr" TYPE="text" CLASS="myinput2" id="CardAddr" VALUE=''>
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">ְ&nbsp;&nbsp;&nbsp;&nbsp;��:</FONT></TD>
            <TD> 
              <INPUT NAME="CardJob" TYPE="text" CLASS="myinput2" id="CardJob" VALUE=''>
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;��:</FONT></TD>
            <TD> 
              <INPUT NAME="CardTel" TYPE="text" CLASS="myinput2" id="CardTel" VALUE=''>
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;��:</FONT></TD>
            <TD> 
              <INPUT NAME="CardMobile" TYPE="text" CLASS="myinput2" id="CardMobile" VALUE=''>
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">�����ʼ�:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="AddrEmail" VALUE='' CLASS="myinput2">
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;ϵ:</FONT></TD>
            <TD>
			  <select name="CardBearing" CLASS="myinput2" id="CardBearing">
                <option value="1" selected>����</option>
                <option value="2">����</option>
                <option value="3">ͬ��</option>
                <option value="4">�ͻ�</option>
                <option value="5">����</option>
              </select> 
            </TD>
          </TR>
		  <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF">��&nbsp;&nbsp;&nbsp;&nbsp;ע:</FONT></TD>
            <TD> 
              <INPUT NAME="CardNote" TYPE="text" CLASS="myinput2" id="CardNote" VALUE=''>
			  <INPUT TYPE="button" VALUE="����" 
              onClick="Add(this.form);return false" CLASS="myinput">
            </TD>
          </TR>
          
        </FORM>
        </TABLE>
      </TD>
    </TR>
</TABLE>
</body>
</html>
