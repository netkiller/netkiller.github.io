<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: pubaddr.php,v 1.3 2003/01/16 08:55:27 wuqiong Exp $
 */

include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

// get
$get_page = $HTTP_GET_VARS['page'];
$get_keyword = $HTTP_POST_VARS['keyword'];
$get_sortby = $HTTP_GET_VARS['sortby'];
$get_direct = $HTTP_GET_VARS['direct'];

// ���� page 
if ($get_page==0) $get_page = 1;

// ����������
$cur_direct = $get_direct;
if($cur_direct=='') $get_direct=='down';
if($get_direct=='up'){
	$sort_direct = 'ASC';
	$get_direct = 'down';
}else{
	$sort_direct = 'DESC';
	$get_direct = 'up';
}

// ��������ؼ���
switch($get_sortby){
	case 'name':
		$sortby = "ORDER BY name";
		break;
	case 'email':
		$sortby = "ORDER BY user";
		break;
	default:
		$sortby = "ORDER BY name";
}
$sortby = $sortby ." ".$sort_direct." ";

// ÿҳ��ʾ������ 10
$CFG_ADDR_NUMPERPAGE = 10;

$sql = mysql_pconnect($CFG_MYSQL_HOST, $CFG_MYSQL_USER, $CFG_MYSQL_PASS);
mysql_select_db($CFG_MYSQL_DB,$sql);

//��ʾ�б�
if ($CFG_VPOPMAIL_MYSQL_LARGE_SITE){
	$Vpopmail_Domain = ereg_replace("\.","_",$domain);
	$query = "SELECT count(*) as totalnum FROM $Vpopmail_Domain WHERE pw_name!='postmaster'";
}else {
	$query = "SELECT count(*) as totalnum FROM postfix_users WHERE domain='$G_DOMAIN'";
}

$result = @mysql_query($query,$sql);
$row = mysql_fetch_object($result);
$totalrow = $row->totalnum;
$totalpage = intval($totalrow /$CFG_ADDR_NUMPERPAGE);
if( $totalrow >$totalpage*$CFG_ADDR_NUMPERPAGE ) $totalpage++;
if ($get_page>$totalpage) $get_page = $totalpage;
$start_row = ($get_page - 1)*$CFG_ADDR_NUMPERPAGE;
$prevpage = $get_page - 1;
$nextpage = $get_page + 1;
if($get_page <=1) $prevpage = 1;
if($get_page >=$totalpage) $nextpage = $totalpage;
/*
if ($CFG_VPOPMAIL_MYSQL_LARGE_SITE){
	$Vpopmail_Domain = ereg_replace("\.","_",$domain);
	$query = "SELECT user,name FROM $Vpopmail_Domain WHERE pw_name!='postmaster' $sortby LIMIT $start_row, $CFG_ADDR_NUMPERPAGE";
}else{
*/
$query = "SELECT user,name FROM postfix_users WHERE domain='$G_DOMAIN' $sortby LIMIT $start_row, $CFG_ADDR_NUMPERPAGE";
//}

$result = mysql_query($query,$sql);
$ListOut = '';
while ($row = mysql_fetch_object($result)) {
	$email = $row->user;
	$nick  = $row->user;
	$name  = $row->name;
    $ListOut .= "<TR>\n".
    "\t<TD NOWRAP title='$email'>".
    "<A href=# onClick=\"To('$email')\">".$name."</A></TD>\n".
    "\t<TD NOWRAP title=\"$email\">".
    "<A href=#  onClick=\"To('$email')\">".$nick."</A></TD>\n".
    "\t<TD NOWRAP>&nbsp;</TD>".
    "\t<TD ALIGN='CENTER' NOWRAP>".
    "<A onClick=\"Cc('$email')\" href=#>CC</A></TD>\n".
    "\t<TD ALIGN='CENTER' NOWRAP><A onClick=\"Bcc('$email')\" href=#>BCC</A></TD>\n</TR>\n";
}

// ����page��������
function PageIndex($NumPerPage,$TotalNum,$CurPage,$URL){
	$PrevPage = $CurPage - 1;
	$NextPage = $CurPage + 1;
	$TotalPage = intval($TotalNum /$NumPerPage);
	if( $TotalNum >$TotalPage*$NumPerPage ) $TotalPage++;
	if( $PrevPage>0 ) $Out_Str .= "<A class=header href=?page=$PrevPage&$URL><<$LANG_LIST_PREV</A>";
	if( $NextPage <=$TotalPage ) $Out_Str .= " <A class=header href=?page=$NextPage&$URL>>>$LANG_LIST_NEXT</A>";
	return $Out_Str;
}
?>
<HTML>
<HEAD>
<TITLE><?php echo $LANG_ADDR_PUBLIC;?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<SCRIPT LANGUAGE="JavaScript" SRC="script/address.js">
</SCRIPT>
<BODY BGCOLOR="#5A8C52" TEXT="#000000" LEFTMARGIN="4" TOPMARGIN="4" MARGINWIDTH="2" MARGINHEIGHT="2">
 
<TABLE WIDTH="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0">
  <TR>
    <TD><B><FONT COLOR="#FFFFFF"><?php echo $LANG_ADDR_PUBLIC;?>:</FONT></B></TD>
    <TD ALIGN="RIGHT"> <B>
      <INPUT TYPE="BUTTON" VALUE="-&gt;&gt; <?php echo $LANG_ADDR_PRI;?>" CLASS="myinput2" 
      onClick="window.location='address.php'" NAME="BUTTON">
      </B> 
      <INPUT TYPE="submit" VALUE="<?php echo $LANG_DEFAULT_CLOSE;?>" CLASS="myinput2" onClick="window.close()">
    </TD>
  </TR>
</TABLE>
<BR>
<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="100%" ALIGN="CENTER">
<FORM NAME='List' METHOD='post'>
  <TR  BGCOLOR="#D0E6CE"> 
    <TD HEIGHT="22" NOWRAP>
    <A HREF='<?php echo "?sortby=name&page=$get_page&direct=$get_direct";?>'><B>
    <?php echo $LANG_ADDR_NAME;?></B></A></TD>
    <TD NOWRAP>
    <A HREF='<?php echo "?sortby=email&page=$get_page&direct=$get_direct";?>'><B>
    <?php echo $LANG_ADDR_EMAIL;?></B></A></TD>
    <TD NOWRAP><B><?php echo $LANG_ADDR_DEPARTMENT;?></B></TD>
    <TD NOWRAP><B><?php echo $LANG_ADDR_CC;?></B></TD>
    <TD NOWRAP><B><?php echo $LANG_ADDR_BCC;?></B></TD>
  </TR>
  <?php echo $ListOut;?>
</FORM>
</TABLE>
<BR>
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR>
    <TD ALIGN="RIGHT"> 
      <?php echo PageIndex($CFG_ADDR_NUMPERPAGE,$totalrow,$get_page,"sortby=$get_sortby&direct=$cur_direct#List");?>
    </TD>
  </TR>
</TABLE>
</BODY>
</HTML>
