<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: getpopmail.php,v 1.6 2003/01/16 03:23:50 wuqiong Exp $
 */
$DEBUG = 1;
if($DEBUG) $timebegin = gettimeofday();
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

//get
$get_Cmd = trim($HTTP_GET_VARS['Cmd']);

if($get_Cmd=='Get'){
	if(is_file($CFG_POP_FILE)){
		($FD_CFG = fopen($CFG_POP_FILE,"r")) || die("Error open user config file!");	
		while(!feof($FD_CFG)){	
			$line = trim(fgets($FD_CFG,512));
			if(empty($line)) continue;
			list($POP_HOST,$POP_PORT,$POP_USER,$POP_PASSWD,$POP_BACKUP,$POP_ACTIVE) = split("\t",$line,6);
			if($POP_ACTIVE) GetMail($POP_HOST,$POP_PORT,$POP_USER,$POP_PASSWD,$POP_BACKUP);
		}
		fclose($FD_CFG);
	}
	
	if ($DEBUG){
		$timeend = gettimeofday();
		$time = $timeend['sec'] - $timebegin['sec'];
		$time3 = $time + ($timeend['usec']-$timebegin['usec'])/1000000;
		echo "<CENTER><FONT color=#EEEEEE>"."Refresh Time:$time3"."</FONT></CENTER>";
	}
//exit();
	echo "
<script>
<!--
top.close();
//-->
</script>";
	exit();
}

function GetMail($POP_HOST,$POP_PORT,$POP_USER,$POP_PASSWD,$POP_BACKUP){
	global $G_HOME;
	
	$fp = fsockopen($POP_HOST, $POP_PORT,$ErrNo,$ErrStr,30);
	if(!$fp){
    	echo "$ErrStr ($ErrNo)<br>\n";
	}else {
    	fgets($fp,512);
		fputs($fp,"user $POP_USER\n");
		fgets($fp,512);
		fputs($fp,"pass $POP_PASSWD\n");
		fgets($fp,512);

		// stat
		fputs($fp,"STAT\n");
		list($Ok,$TotalMail,$TotalSize) = split(' ',fgets($fp,512),3);
		$Total = $TotalMail;
		if( $TotalMail>=50 ) $Total = 50;
		
		$UidlArray = array();
		$UidlArray2 = array();
		if($POP_BACKUP){
			if(is_file("$G_HOME/.UIDL_$POP_USER@$POP_HOST")){
				($FD_UIDL = fopen("$G_HOME/.UIDL_$POP_USER@$POP_HOST","r")) || die("Error open file");
				while(!feof($FD_UIDL)){
					$line = trim(fgets($FD_UIDL,512));
					if(!empty($line)) $UidlArray[$line] = 1;
				}
				// UIDL
				fputs($fp,"UIDL\n");
				fgets($fp,512);
				do{
					$line=rtrim(fgets($fp,512));
					if($line=='.') break;
					list(,$UIDL) = split(' ',$line,2);
					$UidlArray2[$UIDL] = 1;
				}while($line!='.');
				fclose($FD_UIDL);
			}
			($FD_UIDL = fopen("$G_HOME/.UIDL_$POP_USER@$POP_HOST","w")) || die("Error open file");	
		}
		
//		print_r($UidlArray);
		$k = 0;
		for($i=1;$i<=$Total;$i++){
			fputs($fp,"list $i\n");
			list($Ok,,$TotalSize) = split(' ',fgets($fp,512),3);

			$TotalSize = trim($TotalSize);
			if($POP_BACKUP){
				fputs($fp,"UIDL $i\n");
				list($OK,$Num,$UIDL) = split(' ',rtrim(fgets($fp,512)),3);
				if($UidlArray[$UIDL]==1){
					$Total++;
					if($Total>=$TotalMail) $Total = $TotalMail; 
					continue;	//���ʼ��Ѿ���ȡ��������һ��
				}
			}
			// ��ȡ						
			fputs($fp,"RETR $i\n");
			$CurPID = posix_getpid();
			$filename = "pop.".time().".".$i.".$POP_HOST,S=".$TotalSize;
			
			$FileArray[$k++] = $filename;
			
			$filename = "$G_HOME/tmp/".$filename;
			($FD_MAIL = fopen($filename,"w"))||die("Error open $filename");
				fputs($FD_MAIL,GetMailBody($fp));
			fclose($FD_MAIL);
			

			
			if($POP_BACKUP){
				//fputs($FD_UIDL,"$UIDL\n");
				$UidlArray[$UIDL] = 1;
				continue;
			}
			// DELE
			fputs($fp,"DELE $i\n");
			fgets($fp,512);
		}
		if($POP_BACKUP){
			foreach($UidlArray as $key => $value){
				if(empty($UidlArray2[$key])) unset($UidlArray[$key]);	
			}
			foreach($UidlArray as $key => $value){
				fputs($FD_UIDL,"$key\n");	
			}
			print_r($UidlArray);
			fclose($FD_UIDL);
			
		}
		// QUIT
		fputs($fp,"QUIT\n");
		echo "QUIT\n".fgets($fp,512);
    	fclose ($fp);
    	
    	//move mail from tmp to new

    	foreach($FileArray as $value){
			@link("$G_HOME/tmp/$value",
			"$G_HOME/new/$value");
			@unlink("$G_HOME/tmp/$value");
    	}
	}
	
}

function GetMailBody($fp){
	fgets($fp,512);
	do{
		$line=rtrim(fgets($fp,512));
		if($line=='.') break;
		$buffer .="$line\n";
	}while($line!='.');
	return $buffer;
}
?>
