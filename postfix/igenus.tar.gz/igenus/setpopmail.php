<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: setpopmail.php,v 1.5 2003/01/24 08:07:53 wuqiong Exp $
 */

include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

//post
$post_POP_HOST = trim($HTTP_POST_VARS['host']);
$post_POP_PORT = trim($HTTP_POST_VARS['port']);
$post_POP_USER = trim($HTTP_POST_VARS['user']);
$post_POP_PASSWD = trim($HTTP_POST_VARS['passwd']);
$post_POP_BACKUP = trim($HTTP_POST_VARS['backup']);
$post_POP_ACTIVE = trim($HTTP_POST_VARS['active']);

//get
$get_Cmd = trim($HTTP_GET_VARS['Cmd']);
$get_Num = trim($HTTP_GET_VARS['Num']);

if($get_Cmd=='Check'){
	$fp = fsockopen($post_POP_HOST, $post_POP_PORT,$ErrNo,$ErrStr,30);
	echo $fp;
	if(!$fp){
		echo "$ErrStr($ErrNo)<br>";
	    	echo "<?php echo $LANG_POPSET_SERVER_CONNECT_FAIL;?><br>\n";
    		exit();	// ����������ʧ��
	}else {
	// ����������ͨ��
	echo "<?php echo $LANG_POPSET_SERVER_CONNECT_OK;?><BR>";
    fgets($fp,128);
	fputs($fp,"USER $post_POP_USER\n");
	$line = trim(fgets($fp,128));
	if(substr($line,0,3)!="+OK"){
		echo "<?php echo $LANG_POPSET_CONNECT_FAIL;?><BR>";
		exit();
	}
	fputs($fp,"PASS $post_POP_PASSWD\n");
	$line = trim(fgets($fp,512));
	if(substr($line,0,3)!="+OK"){
		echo "<?php echo $LANG_POPSET_ACCOUNT_FAIL;?><BR>";
		exit();
	}
    fclose ($fp);
	}
	echo "<?php echo $LANG_POPSET_ACCOUNT_OK;?>";
	echo "
	<Script>
	if(opener.ModiPoP.style.display==''){
		opener.ModiPopMail.Check.disabled=true;
		opener.ModiPopMail.Add.disabled=false;
	}
	else{
		opener.AddPopMail.Check.disabled=true;
		opener.AddPopMail.Add.disabled=false;
	}
	window.close();
	</Script>";
	exit();
}

if($get_Cmd=='Add'){
	$fp = fsockopen($post_POP_HOST, $post_POP_PORT,$ErrNo,$ErrStr,30);
	if(!$fp){
    	echo "$ErrStr ($ErrNo)<br>\n";
    	exit();
	}else {
    fgets($fp,128);
	fputs($fp,"USER $post_POP_USER\n");
	$line = trim(fgets($fp,128));
	if(substr($line,0,3)!="+OK") exit();
	fputs($fp,"PASS $post_POP_PASSWD\n");
	$line = trim(fgets($fp,512));
	if(substr($line,0,3)!="+OK") exit();
    fclose ($fp);
	}
	($FD_CFG = fopen($CFG_POP_FILE,"a+")) || die("Error open users pop config file!");
		$line = "$post_POP_HOST\t$post_POP_PORT\t$post_POP_USER\t$post_POP_PASSWD\t$post_POP_BACKUP\t$post_POP_ACTIVE\n";
		fputs($FD_CFG,$line);
	fclose($FD_CFG);
	header("Location: setpopmail.php");
}

if($get_Cmd=='Delete'){
	$buffer = '';
	($FD_CFG = fopen($CFG_POP_FILE,"r")) || die("Error open users pop config file!");
	$i=0;
	while(!feof($FD_CFG)){
		$line = fgets($FD_CFG,512);
		if(empty($line)) continue;
		$i++;
		if($i!=$get_Num) $buffer .= $line;
	}
	fclose($FD_CFG);
	($FD_CFG = fopen($CFG_POP_FILE,"w")) || die("Error open users pop config file!");
		fputs($FD_CFG,$buffer);
	fclose($FD_CFG);
	header("Location: setpopmail.php");
}

if($get_Cmd=='Modi'){
	$buffer = '';
	($FD_CFG = fopen($CFG_POP_FILE,"r")) || die("Error open users pop config file!");
	$i=0;
	while(!feof($FD_CFG)){
		$line = fgets($FD_CFG,512);
		if(empty($line)) continue;
		$i++;
		if($i!=$get_Num) $buffer .= $line;
		else $buffer .= "$post_POP_HOST\t$post_POP_PORT\t$post_POP_USER\t$post_POP_PASSWD\t$post_POP_BACKUP\t$post_POP_ACTIVE\n";
	}
	fclose($FD_CFG);
	($FD_CFG = fopen($CFG_POP_FILE,"w")) || die("Error open users pop config file!");
		fputs($FD_CFG,$buffer);
	fclose($FD_CFG);
	header("Location: setpopmail.php");
}
//main
//list accounts
$List_Out = '';
if(is_file($CFG_POP_FILE)){
	($FD_CFG = fopen($CFG_POP_FILE,"r")) || die("Error open users pop config file!");
	$i = 1;
	while(!feof($FD_CFG)){	
		$line = trim(fgets($FD_CFG,512));
		if(empty($line)) continue;
		list($Host,$Port,$User,$Passwd,$Backup,$Active) = split("\t",$line,6);
		$List_Out .="<TR ALIGN='CENTER'>\n".
					"<TD><INPUT type='checkbox' Disabled";
		if($Active) $List_Out .=" CHECKED";
		$List_Out .=">$i</TD>\n".
					"<TD>$Host:$Port</TD>\n".
					"<TD>$User</TD>\n".					
					"<TD>";
		if($Backup) $List_Out .="Yes";
		else $List_Out .='No';	
		$List_Out .="</TD>\n".
					"<TD><A href=# onClick=\"ShowModi('$i','$Host','$Port','$User','$Backup','$Active')\">".
					"<IMG src=images/edit.gif ALT='$LANG_POPSET_EDIT' width=14 height=14 border=0></A> ".
					"<A href=# onClick=\"javascript:Delete('$i','$Host','$Port','$User');return false\">".
					"<IMG src=images/trash.gif border=0 ALT='$LANG_POPSET_DELETE' width=14 height=14></TD>\n".
					"</TR>\n";
		$i++;
	}
	$Total = $i--;
	fclose($FD_CFG);
}
?>
<SCRIPT>
<!--
function Delete(Num,Host,Port,User){
	if(confirm("<?php echo $LANG_POPSET_CONFIRM_DELETE;?> " + User+"@"+Host+":"+Port +" ?")){
		document.location = "setpopmail.php?Cmd=Delete&Num="+Num;
	}
	return false;
}

function ShowModi(Num,Host,Port,User,Backup,Active){
	AddPoP.style.display='none';
	ModiPoP.style.display='';
	document.ModiPopMail.host.value = Host;
	document.ModiPopMail.port.value = Port;
	document.ModiPopMail.user.value = User;
	if(Backup==1) document.ModiPopMail.backup.checked = true;
	else document.ModiPopMail.backup.checked = false;
	if(Active==1) document.ModiPopMail.active.checked = true;
	else document.ModiPopMail.active.checked = false;
	document.ModiPopMail.num.value = Num;
	return true;
}

function ShowAdd(input,form){
	if(form.TotalNum.value>=5){
		alert("<?php echo $LANG_POPSET_5;?>");	
		return false;
	}
	ModiPoP.style.display='none';
	if(AddPoP.style.display=='none'){
		AddPoP.style.display='';
		input.value = "<?php echo $LANG_POPSET_CANCEL;?>";
		return;
	}
	if(AddPoP.style.display==''){
		AddPoP.style.display='none';
		input.value = "<?php echo $LANG_POPSET_ADD;?>";
		return;
	}		
}

function CheckPop(form){
	Meg = '';
	if(form.host.value=='') Meg += "<?php echo $LANG_POPSET_SERVER;?>\n";
	if(form.user.value=='') Meg += "<?php echo $LANG_POPSET_ACCOUNT;?>\n";
	if(form.passwd.value=='') Meg += "<?php echo $LANG_POPSET_PASSWD;?>";
	if(Meg==''){	
		checkpop = window.open("","CheckPop","width=200,height=120");
		form.action = "setpopmail.php?Cmd=Check";
		form.target = "CheckPop";
		form.submit();
		return true;
	}
	alert("<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n\n" + Meg);
	return false;
}

function AddPop(form){
	Meg = '';
	if(form.host.value=='') Meg += "<?php echo $LANG_POPSET_SERVER;?>\n";
	if(form.user.value=='') Meg += "<?php echo $LANG_POPSET_ACCOUNT;?>\n";
	if(form.passwd.value=='') Meg += "<?php echo $LANG_POPSET_PASSWD;?>";
	if(Meg==''){	
		form.action = "setpopmail.php?Cmd=Add";
		form.target = "_self";
		form.submit();
		return true;
	}
	alert("<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n\n" + Meg);
	return false;
}

function ModiPop(form){
	Meg = '';
	if(form.host.value=='') Meg += "<?php echo $LANG_POPSET_SERVER;?>\n";
	if(form.user.value=='') Meg += "<?php echo $LANG_POPSET_ACCOUNT;?>\n";
	if(form.passwd.value=='') Meg += "<?php echo $LANG_POPSET_PASSWD;?>";
	if(Meg==''){	
		form.action = "setpopmail.php?Cmd=Modi&Num=" + form.num.value;
		form.target = "_self";
		form.submit();
		return true;
	}
	alert("<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n\n" + Meg);
	return false;
}
//-->
</SCRIPT>
<HTML>
<HEAD>
<TITLE><?php echo $LANG_DEFAULT_POP;?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#5A8C52" TEXT="#000000">
<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="100%" ALIGN="CENTER">
  <TR BGCOLOR="#D0E6CE" ALIGN="CENTER"> 
    <TD><B><?php echo $LANG_POPSET_ENABLE;?></B></TD>
    <TD><B><?php echo $LANG_POPSET_SERVER_PORT;?></B></TD>
    <TD><B><?php echo $LANG_POPSET_ACCOUNT;?></B></TD>
    <TD HEIGHT="22"><B><?php echo $LANG_POPSET_BUCKUP;?></B></TD>
    <TD HEIGHT="22"><B><?php echo $LANG_POPSET_MANAGE;?></B></TD>
  </TR>
  <?php echo $List_Out;?>
</TABLE>
      
<TABLE WIDTH="100%" BORDER="0">
  <TR>
    <TD ALIGN="RIGHT"> 
        <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_ADD;?>" CLASS="myinput2" onClick="ShowAdd(this,document.AddPopMail)">
    </TD>
  </TR>
  <TR ID="AddPoP" STYLE="DISPLAY:none">
  <FORM NAME="AddPopMail" METHOD="post" ACTION="return false;">
      <TD ALIGN="CENTER"> 
        <TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0">
          <TR> 
            <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_SERVER;?>:</FONT></B></TD>
            <TD> 
              <INPUT TYPE="text" NAME="host" CLASS="myinput2">
              <FONT COLOR="#FFFFFF"><B><?php echo $LANG_POPSET_PORT;?>:</B></FONT> 
              <INPUT TYPE="text" NAME="port" VALUE="110" SIZE="4" MAXLENGTH="4" CLASS="myinput2">
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_ACCOUNT;?>:</FONT></B></TD>
            <TD> 
              <INPUT TYPE="text" NAME="user" CLASS="myinput2" SIZE="20">
              <B></B> </TD>
          </TR>
          <TR> 
            <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_PASSWD;?>:</FONT></B></TD>
            <TD> 
              <INPUT TYPE="PASSWORD" NAME="passwd" CLASS="myinput2" SIZE="20">
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="CENTER" COLSPAN="2"><B> 
              <INPUT TYPE="HIDDEN" NAME="TotalNum" VALUE="<?php echo $Total;?>">
              <INPUT TYPE="checkbox" NAME="backup" VALUE="1" CHECKED>
              <FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_BUCKUP_2;?></FONT></B>
              <INPUT TYPE="checkbox" VALUE="1" CHECKED NAME="active">
              <FONT COLOR="#FFFFFF"><B><?php echo $LANG_POPSET_BE_ENABLE;?></B></FONT></TD>
          </TR>
          <TR> 
            <TD ALIGN="CENTER">&nbsp; </TD>
            <TD> 
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_CHECK_ACCOUNT;?>" NAME="Check" CLASS="myinput" onClick="CheckPop(this.form)">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_NEXT_ADD;?>" NAME="Add" CLASS="myinput" Disabled onClick="AddPop(this.form)">
            </TD>
          </TR>
        </TABLE>
      </TD> 
    </FORM>
  </TR>
  <TR ID="ModiPoP" STYLE="DISPLAY:none">
  <FORM NAME="ModiPopMail" METHOD="post" ACTION="return false;">
    <TD ALIGN="CENTER">
      <TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0">
        <TR> 
          <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_SERVER;?>:</FONT></B></TD>
          <TD> 
            <INPUT TYPE="text" NAME="host" CLASS="myinput2">
            <FONT COLOR="#FFFFFF"><B><?php echo $LANG_POPSET_PORT;?>:</B></FONT> 
            <INPUT TYPE="text" NAME="port" VALUE="110" SIZE="4" MAXLENGTH="4" CLASS="myinput2">
          </TD>
        </TR>
        <TR> 
          <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_ACCOUNT;?>:</FONT></B></TD>
          <TD> 
              <INPUT TYPE="text" NAME="user" CLASS="myinput2" SIZE="20">
            <B></B> </TD>
        </TR>
        <TR> 
          <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_PASSWD;?>:</FONT></B></TD>
          <TD> 
            <INPUT TYPE="PASSWORD" NAME="passwd" CLASS="myinput2" SIZE="20">
            </TD>
        </TR>
        <TR> 
            <TD ALIGN="CENTER" COLSPAN="2"><B> 
              <INPUT TYPE="HIDDEN" NAME=num>
              <INPUT TYPE="checkbox" NAME="backup" VALUE="1">
              <FONT COLOR="#FFFFFF"><?php echo $LANG_POPSET_BUCKUP_2;?></FONT></B> 
              <INPUT TYPE="checkbox" VALUE="1" NAME="active">
            <FONT COLOR="#FFFFFF"><B><?php echo $LANG_POPSET_BE_ENABLE;?></B></FONT></TD>
        </TR>
        <TR>
          <TD ALIGN="CENTER">&nbsp; </TD>
          <TD> 
            <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_CHECK_ACCOUNT;?>" NAME="Check" CLASS="myinput" onClick="CheckPop(this.form)">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_CANCEL;?>" CLASS="myinput2" onClick="ModiPoP.style.display='none'">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_NEXT_MODI;?>" NAME="Add" CLASS="myinput" Disabled onClick="ModiPop(this.form)">
          </TD>
        </TR>
      </TABLE>
    </TD>
     </FORM>
  </TR>
</TABLE>
</BODY>
<script>
self.focus();
</script>
</HTML>
