<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: read.php,v 1.13 2003/01/14 00:57:38 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

/* ��ڲ���: 	
 *				$get_Mailbox	����
 *				$get_Num		�ʼ����
 *				$get_Type
 */
$get_Mailbox = trim($HTTP_GET_VARS['Mailbox']);
$get_Num = trim($HTTP_GET_VARS['Num']);
$get_Type = trim($HTTP_GET_VARS['Type']);


$CFG_HOSTNAME = "http://".$HTTP_SERVER_VARS["HTTP_HOST"]; 
$CFG_HOSTNAME = $CFG_HOSTNAME . str_replace("read.php","",$HTTP_SERVER_VARS["SCRIPT_NAME"]);

switch ($get_Type){

case "Header":
	ShowHeader();
	break;
	
case "Source":	// ��ʾ�ʼ�Դ����
	ShowSource();
	break;

case "text/html":
	$MimeType = "text/html";
	$filename = "unknown.html";
	ShowBody();
	break;

case "multipart/mixed":
case "multipart/related":
case "multipart/alternative":
	$MimeType = "text/html";
	if($CFG_Prev_Alternative=='Html'){
		if (file_exists("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/unknown.html")) $filename = "unknown.html";
		else if (file_exists("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/unknown.txt")){
			$filename = "unknown.txt";
			$MimeType = "text/plain";
		}
	}else{
		if (file_exists("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/unknown.txt")){
			$filename = "unknown.txt";
			$MimeType = "text/plain";
		}
	}
	ShowBody();
	break;

case "text/plain":
case "":
default:
	$filename = "unknown.txt";
	$MimeType = "text/plain";
	ShowBody();
	break;
}
exit();

function ShowBody(){
	global $CFG_TEMP,$G_DOMAIN,$G_USERNAME;
	global $MimeType,$filename;
	global $CFG_HOSTNAME,$CFG_CHARSET,$CFG_LANGUAGE;
	
	if ($filename == "unknown.html"){
		// get the body list
		$body_list = array();
		$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";
		($FD_BODYLIST = fopen("$bodylistfile","r"))	|| die("Error open body list file");
		$line = fgets($FD_BODYLIST,1024);
		while( ($line = fgets($FD_BODYLIST,1024)) && !feof($FD_BODYLIST)){
			$line = chop($line);
			list($file,$get_Type,$size,$disposition,$id,$location) = split("\t",$line,6);
			if ($id !="") $body_list["cid:".$id] = $file;
			if ($location !="") $body_list[$location] = $file;
		}
		fclose($FD_BODYLIST);
//		print_r ($body_list);
	}

	$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$filename";
	($FD_MAIL = fopen("$bodylistfile","r"))	|| die("Error open body list file");
	$buff = "";
	$i = 0;
	while($line = fread($FD_MAIL,4096)){
		$buff .= $line;
	}
	if ($filename == "unknown.html"){
			while(list($key,$value)= each ($body_list)){
				
				$value = "mime.php?Cmd=Show&File=$value&MimeType=$get_Type";
				$value = rawurldecode($value);
				$value = $CFG_HOSTNAME.$value;
				$buff = str_replace($key,$value,$buff);
			}
	}
	
	fclose($FD_MAIL);
	
	header("Content-type: $MimeType\n");
	header("Content-Disposition: filename=\"$filename\"\n\n");
	if( $filename=="unknown.txt" ){	//
		$buff = preg_replace("/(ftp:\/\/[\w|\.|\/|\?|\%|\&|\=|\-|\;|\,|\+|\~]+)/i","<A href=$1 target=_blank>$1</A>",$buff);
		$buff = preg_replace("/(http:\/\/[\w|\.|\/|\?|\%|\&|\=|\-|\;|\,|\+|\~]+)/i","<A href=$1 target=_blank>$1</A>",$buff);
		$buff = preg_replace("/([\w|\.|\-]+@[\w|\-|\.]+\.[a-z]+)/i","<A href=mailto:$1>$1</A>",$buff);
		
		$buff = eregi_replace("\n"," <BR>\n",$buff);
		$buff = "<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=$CFG_CHARSET[$CFG_LANGUAGE]'>
<STYLE TYPE='TEXT/CSS'>
<!--
body { color:#5A8C52; font-size: 12px; line-height: 120%}
.mybody { color:#000000; font-size: 14px; line-height: 150%}
.sign { color:#cccccc; font-size: 12px; line-height: 120%}
-->
</STYLE>
</HEAD>
<BODY BGCOLOR='#FFFFFF' TEXT='#000000'>
<TABLE WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
	<TR>
	<TD class='mybody'>$buff</TD>
	</TR>
</TABLE>
</BODY>
</HTML>";	
	}
	echo $buff;
}

function ShowSource(){
	global $CFG_TEMP,$G_HOME,$G_DOMAIN,$G_USERNAME,$get_Mailbox;
	global $CFG_GMT,$get_Num,$CFG_MAILBOX;
	
	$listfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_$get_Mailbox";

	($FD_LIST = fopen($listfile,"r"))||die("Error open $get_Mailbox list file!");
	for($i=0;$i<$get_Num;$i++){
		$line = fgets($FD_LIST,1024);
	}
	fclose($FD_LIST);
	chop($line);
	list($n,$key,$isnew,$file,$fromname,$from,$subject,$date,$size) = split("\t",$line,9);
	list($null,$date) = Date2Str($date,$CFG_GMT);
	
	if($CFG_MAILBOX[$get_Mailbox]!='') $SMailbox = $CFG_MAILBOX[$get_Mailbox];
	else $SMailbox = ".$get_Mailbox";
	
	$mailfile = "$G_HOME$SMailbox/$isnew/$file";
	if(!file_exists($mailfile)) $mailfile = "$G_HOME$SMailbox/cur/$file";
	($FD_MAIL = fopen($mailfile,"r"))	|| die("Error open mail file $file!");

	
	header("Content-type: text/plain\n");
	header("Content-Disposition: filename=\"unknown.txt\"\n\n");
	$buff = "";
	while($line = fread($FD_MAIL,4096)){
		$buff .= $line;
	}
	echo $buff;
	fclose($FD_MAIL);
}

function ShowHeader(){
	global $CFG_TEMP,$G_HOME,$G_DOMAIN,$G_USERNAME,$get_Mailbox;
	global $CFG_GMT,$get_Num,$CFG_MAILBOX;
	
	$listfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_$get_Mailbox";

	($FD_LIST = fopen($listfile,"r"))||die("Error open $get_Mailbox list file!");
	for($i=0;$i<$get_Num;$i++){
		$line = fgets($FD_LIST,1024);
	}
	fclose($FD_LIST);
	chop($line);
	list($n,$key,$isnew,$file,$fromname,$from,$subject,$date,$size) = split("\t",$line,9);
	list($null,$date) = Date2Str($date,$CFG_GMT);
	
	if($CFG_MAILBOX[$get_Mailbox]!='') $SMailbox = $CFG_MAILBOX[$get_Mailbox];
	else $SMailbox = ".$get_Mailbox";

	$mailfile = "$G_HOME$SMailbox/$isnew/$file";
	if(!file_exists($mailfile)) $mailfile = "$G_HOME$SMailbox/cur/$file";
	($FD_MAIL = fopen($mailfile,"r"))	|| die("Error open mail file $file!");

	
	header("Content-type: text/plain\n");
	header("Content-Disposition: filename=\"unknown.txt\"\n\n");
	$buff = "";
	while($line = fgets($FD_MAIL,4096)){
		if(chop($line)=="") break;
		$buff .= $line;
	}
	echo $buff;
	fclose($FD_MAIL);
}
?>
