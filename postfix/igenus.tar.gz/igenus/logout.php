<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: logout.php,v 1.5 2003/01/28 01:32:58 wuqiong Exp $
 */

include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

//echo $G_USERNAME;
//echo $G_HOME;
//echo $G_DOMAIN;
//echo $G_TIME;

// decode body
// remove body part prev mail
$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";
if (file_exists($bodylistfile)){
	($FD_BODYLIST = fopen("$bodylistfile","r"))	|| die("Error open body list file");
	$line = fgets($FD_BODYLIST,1024);
	while( ($line = fgets($FD_BODYLIST,1024)) && !feof($FD_BODYLIST)){
		list($filename,$type,$size,$disposition,$id,$location) = split("\t",$line,6);
		$filename = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$filename";
		if (file_exists($filename)) unlink($filename);
	}
	fclose($FD_BODYLIST);
	unlink($bodylistfile);
}

// remove the attachment list file
$listattachfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_attach";
if (file_exists($listattachfile)){
	($FD_LIST_ATTACH = fopen($listattachfile,"r")) || die("Error open $listattachfile!");
	while( $buff = chop(fgets($FD_LIST_ATTACH,1024)) ){
		list($name,$size,$type) = split("\t",$buff,3);
		$name = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach/$name";
		if (file_exists($name)) @unlink($name);
	}
	fclose($FD_LIST_ATTACH);
	unlink($listattachfile);
}

// remove attach dir
if(is_dir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach"))
		rmdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach");

// remove list files

$home = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME";
$handle=opendir($home);
while (($file = readdir($handle))!==false) {
   	if ($file !='.' && $file !='..' && is_file("$home/$file"))
   		unlink("$home/$file");
}
closedir($handle); 

session_destroy();
header("Location: login.php");
exit();
?>
<HTML>
<HEAD>
<TITLE>iGENUS webmail Logout</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=gb2312">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000">
<A HREF="login.php"><?php echo $LANG_LOGOUT_LOGIN_AGAIN;?></A>
</BODY>
</HTML>

