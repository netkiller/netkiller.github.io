<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: add2addr.php,v 1.9 2003/01/24 08:07:53 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

// get
$get_page = $HTTP_GET_VARS['page'];
$get_keyword = $HTTP_POST_VARS['keyword'];
$get_sortby = $HTTP_GET_VARS['sortby'];
$get_direct = $HTTP_GET_VARS['direct'];
$get_Cmd = $HTTP_GET_VARS['Cmd'];
$get_id = $HTTP_GET_VARS['id'];

//post
$post_AddrName = $HTTP_POST_VARS['AddrName'];
$post_AddrEmail = $HTTP_POST_VARS['AddrEmail'];
$post_AddrName2 = $HTTP_POST_VARS['AddrName2'];
$post_AddrEmail2 = $HTTP_POST_VARS['AddrEmail2'];
$post_AddrName3 = $HTTP_POST_VARS['AddrName3'];
$post_AddrEmail3 = $HTTP_POST_VARS['AddrEmail3'];

// ���� page 
if ($get_page==0) $get_page = 1;

// ����������
$cur_direct = $get_direct;
if($cur_direct=='') $get_direct=='down';
if($get_direct=='up'){
	$sort_direct = 'ASC';
	$get_direct = 'down';
}else{
	$sort_direct = 'DESC';
	$get_direct = 'up';
}

// ��������ؼ���
switch($get_sortby){
	case 'name':
		$sortby = "ORDER BY name";
		break;
	case 'email':
		$sortby = "ORDER BY email";
		break;
	default:
		$sortby = "ORDER BY id";
}
$sortby = $sortby ." ".$sort_direct." ";

// ÿҳ��ʾ������ 10
$CFG_ADDR_NUMPERPAGE = 7;

$sql = mysql_connect($CFG_MYSQL_HOST, $CFG_MYSQL_USER, $CFG_MYSQL_PASS);
mysql_select_db($CFG_MYSQL_DB,$sql);

if($get_Cmd=='Add' && $post_AddrName!='' && $post_AddrEmail!=''){
	$query = "SELECT * FROM address WHERE pw_id='$G_ID' and name='$post_AddrName' and email='$post_AddrEmail'";
	$result = @mysql_query($query,$sql);
	$rows = @mysql_num_rows($result);
	
	if ($rows !=1 && $row <=100){
		$query = "INSERT INTO address SET pw_id='$G_ID',name='$post_AddrName',email='$post_AddrEmail'";
		$result = @mysql_query($query,$sql);
	}
	header("Location: add2addr.php");
}

if($get_Cmd=='Modify' && $post_AddrName2!='' && $post_AddrEmail2!='' && $post_AddrName3!='' && $post_AddrEmail3!=''){
	$query = "UPDATE address SET name='$post_AddrName2' ,email='$post_AddrEmail2'".
		" WHERE pw_id='$G_ID' and name='$post_AddrName3' and email='$post_AddrEmail3'";
	$result = @mysql_query($query,$sql);
	$rows = @mysql_num_rows($result);
}

if($get_Cmd=='Del' && $get_id!=''){
	$query = "DELETE FROM address WHERE id=$get_id and pw_id='$G_ID'";
	$result = @mysql_query($query,$sql);
	header("Location: add2addr.php");
}

//��ʾ�б�
$query = "SELECT count(*) as totalnum FROM address WHERE pw_id='$G_ID'";
$result = @mysql_query($query,$sql);
$row = mysql_fetch_object($result);
$totalrow = $row->totalnum;
$totalpage = intval($totalrow /$CFG_ADDR_NUMPERPAGE);
if( $totalrow >$totalpage*$CFG_ADDR_NUMPERPAGE ) $totalpage++;
if ($get_page>$totalpage) $get_page = $totalpage;
$start_row = ($get_page - 1)*$CFG_ADDR_NUMPERPAGE;
$prevpage = $get_page - 1;
$nextpage = $get_page + 1;
if($get_page <=1) $prevpage = 1;
if($get_page >=$totalpage) $nextpage = $totalpage;

$query = "SELECT id,name,email FROM address WHERE pw_id='$G_ID' $sortby LIMIT $start_row, $CFG_ADDR_NUMPERPAGE";

$result = @mysql_query($query,$sql);
$ListOut = '';
while ($row = mysql_fetch_object($result)) {
    $ListOut .= "<TR height=20>\n\t".
    "<TD title=\"$row->name\" NOWRAP><A href=# onClick=\"To('$row->email');return false\">".
    TrimStr($row->name,14)."</A></TD>\n".
	"\t<TD title=\"$row->email\" NOWRAP><A href=# onClick=\"To('$row->email');return false\">".
	TrimStr($row->email,36)."</A></TD>\n".
	"\t<TD width=34 NOWRAP><A onClick=\"Go2Modi('$row->name','$row->email')\" href=#Modify>".
	"<IMG src=images/edit.gif ALT='$LANG_POPSET_EDIT' width=14 height=14 border=0></A> ".
	"<A onClick=\"DelAddr('$row->id','$row->name','$row->email');return false;\" href=#>".
	"<IMG src=images/trash.gif border=0 ALT='$LANG_POPSET_DELETE' width=14 height=14></A></TD>\n</TR>\n";
}

// ����page��������
function PageIndex($NumPerPage,$TotalNum,$CurPage,$URL){
	$PrevPage = $CurPage - 1;
	$NextPage = $CurPage + 1;

	$TotalPage = intval($TotalNum /$NumPerPage);
	if( $TotalNum >$TotalPage*$NumPerPage ) $TotalPage++;

	if( $PrevPage>0 ) $Out_Str .= "<A class=header href=?page=$PrevPage&$URL><<$LANG_LIST_PREV</A>";

	if( $NextPage <=$TotalPage ) $Out_Str .= " <A class=header href=?page=$NextPage&$URL>>>$LANG_LIST_NEXT</A>";
	return $Out_Str;
}
?>
<HTML>
<HEAD>
<TITLE><?php echo $LANG_ADDR_PRI_MANAGE;?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=gb2312">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="text/css">
</HEAD>
<SCRIPT LANGUAGE="JavaScript" SRC="script/address.js">
</SCRIPT>
<SCRIPT>
<!--
function DelAddr(id,name,email){
	if(confirm("<?php echo $LANG_ADDR_CONFIRM_DELETE;?> " + name + 
		" <?php echo $LANG_ADDR_CONFIRM_DELETE_EMAIL;?> "+email +" ?")){
		document.List.action = "add2addr.php?Cmd=Del&id="+id;
		document.List.submit();
	}
	else return false;
}

function Add(form){
	str = '';
	if(form.AddrName.value=='') str += "<?php echo $LANG_ADDR_NAME;?>\n";
	if(form.AddrEmail.value=='') str += "<?php echo $LANG_ADDR_EMAIL;?>\n";
	if(str!=''){
		str = "<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n" + str;
		alert(str);
		return false;
	}
	form.action = "add2addr.php?Cmd=Add";
	form.submit();
}

function Modify(form){
	str = "";
	if(form.AddrName3.value=='' || form.AddrEmail3.value==''){
		alert("<?php echo $LANG_ADDR_MODIFY_FAIL;?>");
		return false;
	}

	if(form.AddrName2.value=='') str += "<?php echo $LANG_ADDR_NAME;?>\n";
	if(form.AddrEmail2.value=='') str += "<?php echo $LANG_ADDR_EMAIL;?>\n";
	if(str!=''){
		str = "<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n" + str;
		alert(str);
		return false;
	}
	
	if(form.AddrName2.value==form.AddrName3.value && form.AddrEmail2.value==form.AddrEmail3.value){
		alert("<?php echo $LANG_ADDR_MODIFY_FAIL;?>");
		return false;
	}
	form.action = "add2addr.php?Cmd=Modify";
	form.submit();
}

function Go2Modi(name,email){
	document.modifyForm.AddrName2.value = name;
	document.modifyForm.AddrEmail2.value = email;
	document.modifyForm.AddrName3.value = name;
	document.modifyForm.AddrEmail3.value = email;
	MMDIV.style.display = '';
	MMDIV2.style.display = 'none';
}

function CloseModi(){
	MMDIV2.style.display = '';
	MMDIV.style.display = 'none';
}
//-->
</SCRIPT>
<BODY BGCOLOR="#5A8C52" TEXT="#000000" LEFTMARGIN="4" TOPMARGIN="4" MARGINWIDTH="2" MARGINHEIGHT="2">
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR> 
    <TD><B><FONT COLOR="#FFFFFF"><?php echo $LANG_ADDR_PRI_MANAGE;?></FONT></B> </TD>
    <TD ALIGN="RIGHT"><B> 
      <INPUT TYPE="BUTTON" VALUE="-&gt;&gt; <?php echo $LANG_ADDR_PRI;?>" CLASS="myinput2" 
      onClick="window.location='address.php'">
      </B> 
      <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_DEFAULT_CLOSE;?>" CLASS="myinput2" 
      onClick="window.close()">
    </TD>
  </TR>
  <TR> 
    <TD COLSPAN="2">&nbsp; </TD>
  </TR>
</TABLE>
<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="100%" ALIGN="CENTER">
  <FORM NAME="List" METHOD="post" ACTION="">
    <TR BGCOLOR="#D0E6CE" ALIGN="CENTER"> 
      <TD HEIGHT="22">
      <B><A HREF='<?php echo "?sortby=name&page=$get_page&direct=$get_direct";?>'>
      <?php echo $LANG_ADDR_NAME;?></A></B>
      </TD>
      <TD><B><A HREF='<?php echo "?sortby=email&page=$get_page&direct=$get_direct";?>'>
      <?php echo $LANG_ADDR_EMAIL;?></A></B>
      </TD>
	  <TD><B><?php echo $LANG_POPSET_MANAGE;?></B></TD>
  </TR>
  <?php echo $ListOut;?>
  </FORM>
</TABLE>

<BR>
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR>
    <TD>&nbsp;</TD>
    <TD ALIGN="RIGHT"> 
      <?php echo PageIndex($CFG_ADDR_NUMPERPAGE,$totalrow,$get_page,"sortby=$get_sortby&direct=$cur_direct#List");?>
    </TD>
  </TR>
</TABLE>
<TABLE WIDTH=100%>
  
    <TR ID="MMDIV" STYLE="DISPLAY:none"> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        <FORM NAME="modifyForm" METHOD="post" ACTION="javascript:return false;">
          <TR> 
            <TD><B><FONT COLOR="#FFFFFF">
            <A NAME="Modify"></A><?php echo $LANG_ADDR_MODIFY_LINK;?>-&gt;&gt;&gt;��</FONT></B></TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF"><?php echo $LANG_ADDR_NAME;?>:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="AddrName2" CLASS="myinput2">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_CANCEL;?>" 
              onClick="CloseModi();return false" CLASS="myinput">
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF"><?php echo $LANG_ADDR_EMAIL;?>:</FONT></TD>
            <TD> 
              <INPUT TYPE="hidden" NAME="AddrName3">
              <INPUT TYPE="hidden" NAME="AddrEmail3">
              <INPUT TYPE="text" NAME="AddrEmail2" CLASS="myinput2">
              <INPUT TYPE="button" VALUE="<?php echo $LANG_ADDR_MODIFY;?>" 
              onClick="Modify(this.form);return false" CLASS="myinput">
            </TD>
          </TR>
        </FORM>
        </TABLE>
      </TD>
    </TR>
    <TR ID="MMDIV2" STYLE="DISPLAY:">
      <TD>
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        <FORM NAME="addForm" METHOD="post" ACTION="javascript:return false;">
          <TR> 
            <TD><B><FONT COLOR="#FFFFFF"><?php echo $LANG_ADDR_ADD_LINK;?>-&gt;&gt;&gt;��</FONT></B></TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF"><?php echo $LANG_ADDR_NAME;?>:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="AddrName" VALUE='<?php echo $name;?>' CLASS="myinput2">
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#FFFFFF"><?php echo $LANG_ADDR_EMAIL;?>:</FONT></TD>
            <TD> 
              <INPUT TYPE="text" NAME="AddrEmail" VALUE='<?php echo $email;?>' CLASS="myinput2">
              <INPUT TYPE="button" VALUE="<?php echo $LANG_POPSET_ADD;?>" 
              onClick="Add(this.form);return false" CLASS="myinput">
            </TD>
          </TR>
        </FORM>
        </TABLE>
      </TD>
    </TR>
</TABLE>
</BODY>
</HTML>