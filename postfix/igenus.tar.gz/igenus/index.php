<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: index.php,v 1.6 2002/11/22 01:39:38 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";

?>
<HTML>
<HEAD>
<TITLE>iGENUS webmail</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=gb2312">
</HEAD>

<FRAMESET ROWS="*" COLS="150,*" FRAMEBORDER="NO" BORDER="0" FRAMESPACING="0"> 
  <FRAME NAME="menu" SRC="menu.php?Lang=<?php echo $Lang;?>" NORESIZE>
  <FRAME NAME="main" SRC="mailbox.php?Lang=<?php echo $Lang;?>" scrolling="yes">
</FRAMESET>
<NOFRAMES>
</NOFRAMES>
</HTML>
