self.focus();


function To(email){
	main_open = opener.top.frames[1].SendFlag.flag.value;
	if(opener.name!='main' && main_open==1){
		document.List.action = "send.php?to=" + email;
		document.List.target = 'main';
		document.List.submit();
		main_open = 0;
	}
	opener.top.frames[1].send.To.value =email;
}

function Cc(email){
	main_open = opener.top.frames[1].SendFlag.flag.value;
	if(opener.name!='main' && main_open==1){
		document.List.action = "send.php?cc=" + email;
		document.List.target = 'main';
		document.List.submit();
		main_open = 0;
	}
	opener.top.frames[1].send.Cc.value =email;
}

function Bcc(email){
	main_open = opener.top.frames[1].SendFlag.flag.value;
	if(opener.name!='main' && main_open==1){
		document.List.action = "send.php?bcc=" + email;
		document.List.target = 'main';
		document.List.submit();
		main_open = 0;
	}
	opener.top.frames[1].send.Bcc.value =email;
}