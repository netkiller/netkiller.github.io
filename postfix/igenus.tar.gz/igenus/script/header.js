/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: header.js,v 1.7 2002/11/14 08:28:04 wuqiong Exp $
 */

function AddToAddr(name,from){
	URL = "add2addr.php?name="+name+"&email="+from;
	addrwin = window.open (URL,"addrwin","width=400,height=300,scrollbars=yes");
	addrwin.focus();
}

function ReadSource(form,url,str){
	if(confirm(str)) url = "read.php?Type=Header&" + url ;
	else url = "read.php?Type=Source&" + url;
	form.action = url;
	form.target = "Body";
	form.submit();
	return true;
} 

function Read(form,url){
	url = "read.php?" + url;
	form.action = url;
	form.target = "Body";
	form.submit();
	return true;
} 

function SendAgain(url){
	url = "sendagain.php?" + url;
	(parent.opener).location = url;
	parent.close();
	return true;	
}

function WriteAgain(url){
	url = "writeagain.php?" + url;
	(parent.opener).location = url;
	parent.close();	
	return true;	
}

function Reply(url){
	url = "reply.php?" + url;
	(parent.opener).location = url;
	parent.close();	
	return true;
} 

function Forward(url,str1){
	Attach = 0;
	if(confirm(str1)) Attach = 1;	//"��ԭ�ʼ���Ϊ����ת����"
	url = "forward.php?" + url + "&Attach="+ Attach;
	(parent.opener).location = url;
	parent.close();	
	return true;
}

function Prev(url,Num,str1,str2){
	begin = (parent.opener).bottom.begin.value;
	if(Num == 0){
		alert(str1);					//"�Ѿ��ǵ�һ���ʼ���"
		return false;
	}
	if(Num <= begin){
		if(confirm(str2)){					//"��һҳ��������?"
			page = (parent.opener).bottom.page.value -1;
			loca = (parent.opener).bottom.loca.value;
			(parent.opener).location = loca + "&Page=" + page ;
		} else return false;
	}
	url = "prev.php?" + url + "&Num="+ Num;
	document.header.action = url;
	document.header.target = "mail";
	document.header.submit();
	return true;
} 

function Next(url,Num,str1,str2){
	end = (parent.opener).bottom.end.value;
	totalmail = (parent.opener).bottom.totalmail.value;
	if(Num > totalmail){
		alert(str1);					//"�Ѿ������һ���ʼ���"
		return false;
	}
	if(Num> end){
		if(confirm(str2)){				//"��һҳ��������?"
			page = (parent.opener).bottom.page.value * 1 + 1;
			loca = (parent.opener).bottom.loca.value;
			(parent.opener).location = loca + "&Page=" + page ;
		}else return false;
	}
	url = "prev.php?" + url + "&Num="+ Num;
	document.header.action = url;
	document.header.target = "mail";
	document.header.submit();
	return true;
} 

function ShowAttach(form){
	if(form.Attach.value=="-"){
		return false;
	}
	url = "mime.php?Cmd=Show&" + form.Attach.value;
//	alert(url);
	form.action = url;
	form.target = "Body";
	form.submit();
	return true;
}

function DownloadAttach(form){
	if(form.Attach.value=="-"){
		form.Attach.selectedIndex = 0;
		return false;
	}
	url = "mime.php?Cmd=Download&" + form.Attach.value;
	form.Attach.selectedIndex = 0;
	form.action = url;
	form.target = "Body";
	form.submit();
	return true;
}

function Flag(Num){
	(parent.opener).list.elements[Num-1].checked = !(parent.opener).list.elements[Num-1].checked;
}

