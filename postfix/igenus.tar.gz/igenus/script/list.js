/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: list.js,v 1.8 2003/01/15 07:10:55 wuqiong Exp $
 */
function GetPopMail(){
	getpop = window.open("popmail.php","PopMail","width=200,height=120");//
	getpop.blur();
}
 
function Read(Box,Num){
	begin = document.bottom.begin.value;
	end = document.bottom.end.value;
	URL = "Mailbox="+ Box + "&Num=" + Num;// +"&begin=" + begin +"&end=" + end;
	read = window.open ("prev.php?"+URL,"mail","width=600,height=550,resizable=yes");
	read.window.focus();
	read.window.moveTo(100,100);
}

function GotoPage(form){
	if(form.page.value=="-"){
		return false;
	}
//	alert(form.page.value);
	window.location = form.page.value;
}

function DelMail(force,str1,str2,str3){
	begin = document.bottom.begin.value;
	var string = "";
	id = 1 * begin + 1;
	for (var i=id;i<document.list.elements.length+id;i++){
    	var e=document.list.elements[i-id];
    	if (e.checked == true){
    		string += "&ID" + i + "=" + i;
    	}
    }
    if (string == ""){
    	alert(str1);
    	return false;
    }
    if (force!="force"){
    	if (confirm(str2)){
			url = document.list.action + string +"&MoveTo=trash";
			document.list.action = url;
			document.list.submit();
		} else return false;
	}else {
		if (confirm(str3)){
			url = document.list.action + string + "&MoveTo=force";
			document.list.action = url;
			document.list.submit();
		} else return false;
	}
}

function MoveTo(CurFolder){
	folder = document.bottom.TargetFolder.value;
	FolderName = document.bottom.TargetFolder.options[document.bottom.TargetFolder.selectedIndex].text;
	begin = document.bottom.begin.value;
	if(CurFolder == folder){
		alert(Alert_Invalid_Select);
		return false;	
	}
	var string = "";
	id = 1 * begin + 1;
	for (var i=id;i<document.list.elements.length+id;i++){
    	var e=document.list.elements[i-id];
    	if (e.checked == true){
    		string += "&ID" + i + "=" + i;
    	}
    }
    if (string == ""){
    	alert(Alert_Invalid_Select);
    	return false;
    }
	if(folder == "-"){
		alert(Alert_Invalid_Target);
		return false;
	}
	if (confirm(Confirm_Move + FolderName + " ?")){
		url = document.list.action + string + "&MoveTo=" + folder;
		document.list.action = url;
		document.list.submit();
	} else return false;
}

function SelectAll(){
	if (document.bottom.all.value =="0"){
		all = 1;
		document.bottom.all.value = "1";
	}else {
		all = 0;
		document.bottom.all.value = "0";	
	}
	for (i=0;i<document.list.elements.length;i++){
    	var e = document.list.elements[i];
    	if (all==0) e.checked = true;
    	else e.checked = false;
    }
}

function SelectLang(url){
	lang = document.bottom.language.value;
	if(lang =="-") return false;
	document.location = "list.php?" + url + "&Lang=" + lang;
}

function Flag(Num){
	document.list.elements[Num-1].checked = !document.list.elements[Num-1].checked;
}