/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: send.js,v 1.8 2003/01/15 08:16:00 wuqiong Exp $
 */
var addrwin;
function Addr(form){
	addrwin = window.open("address.php","addrwin","width=400,height=300,scrollbars=yes");	
	addrwin.focus();
	return;
}

function Send(form,str1,str2,str3,str4){
	mesg = "";
	if(form.To.value == "") mesg = mesg + str1+ "\n";	//�����˵�ַ
	if(form.Subject.value == "") mesg = mesg + str2+ "\n";	//����
	if(form.Body.value == "") mesg = mesg + str3+ "\n";		//����
	if (mesg != ""){
		mesg = str4+ ":\n" + mesg ;//����д�����¸���
		alert(mesg);
		return false;
	}
	if(form.Backup.checked) form.action = "sendmail.php?Cmd=Backup";
	else form.action = "sendmail.php";
	form.submit();
}

function AddAttach(form,str1,str2){
	if(form.attachfile.value==""){
		alert(str1);		//"��ѡ���ļ���"
		return false;
	}
	alert(str2);
	form.submit();
	form.attachfile.value = "";
}

function SaveToDraft(form){
	if(!confirm( Confirm_Save_Continue )) return false;
	mesg = "";
	if(form.To.value == "") mesg += Mesg_To + "\n";	//�����˵�ַ
	if(form.Subject.value == "") mesg += Mesg_Subject + "\n";	//����
	if(form.Body.value == "") mesg += Mesg_Body + "\n";		//����
	if (mesg != ""){
		mesg = Mesg_Input + ":\n" + mesg ;//����д�����¸���
		alert(mesg);
		return false;
	}
	form.action = "sendmail.php?Cmd=Draft";
	form.submit();
}