<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: popmail.php,v 1.3 2003/01/21 02:59:31 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
?>
<HTML>
<HEAD>
<TITLE><?php echo $LANG_LIST_CHECKPOP;?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">

<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#5A8C52" TEXT="#000000" OnLoad="setTimeout('window.close()',<?php echo $CFG_POP_Timeout;?>)">
<P>&nbsp;</P>
<P>&nbsp;</P>
<P ALIGN="CENTER"><FONT COLOR="#FFFFFF"><B><?php echo $LANG_POP_CHECKING;?></B></FONT></P>
<P>&nbsp;</P>
<P>&nbsp;</P>
<IFRAME SRC='getpopmail.php?Cmd=Get' width=100%>
</IFRAME>
</BODY>
</HTML>
