CREATE TABLE address (
  id int(11) unsigned NOT NULL auto_increment,
  pw_id int(5) NOT NULL default '0',
  domain varchar(20) NOT NULL default '',
  name varchar(64) NOT NULL default '',
  email varchar(128) NOT NULL default '',
  UNIQUE KEY id (id),
  KEY pw_id (pw_id)
) TYPE=MyISAM PACK_KEYS=1;