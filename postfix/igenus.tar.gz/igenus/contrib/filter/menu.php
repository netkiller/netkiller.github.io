$useremail1="$G_USERNAME"."$G_DOMAIN";
list($useremail,$com) =split("\.",$useremail1);
$content="|/usr/local/bin/maildrop $G_HOME/Maildir/refuse\n|/usr/local/bin/maildrop $G_HOME/Maildir/filter\n";
writeqmail($G_HOME,$content);
$content="�����ʼ����Է�����\nYou Email was refused\n";
if(!file_exists("$G_HOME/Maildir/filter")){
	   $filterrule="to \"$G_HOME/Maildir/.\"";
	   write($G_HOME,$filterrule,filter);}
writerefuse($G_HOME,$content);
$mail="$G_USERNAME"."@"."$G_DOMAIN";