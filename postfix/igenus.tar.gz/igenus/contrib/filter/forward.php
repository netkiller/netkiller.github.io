<?
/*-
 * Qwebmail3.0
 * 
 * Copyright (c) 1999-2002 by lnxsoft Inc.
 * All rights reserved.
 * Author: hufanjie <hfj@lnxsoft.com>
 *
 */

include "../include/login_inc.php";
include "../config/config_inc.php";
include "../include/fun_inc.php";

if($forwarddes!=''){
	if($forwardactive=='1'){$active=1;}
	else{$active=0;}
		if($keeplocal=='1')
		{
		  $content="$active,$forwarddes,1";
		  $content1 = "&$forwarddes\n$G_HOME/Maildir/\n";
		  }
		else{
		  $content="$active,$forwarddes,0";
		  $content1 = "&$forwarddes\n";
		}
	   writeforward($G_HOME,$content,forward); 
	   	 if($active=='0')
	          {
	       	   $content1='';
	       	  }
	   	forward($G_HOME,$content1);

	  }
$show=readforward($G_HOME,forward);
$forward=split(",",$show);
?>

<HTML>
<HEAD>
<TITLE>�ʼ�ת��</TITLE>
   <META HTTP-EQUIV='Content-Type' CONTENT='text/html;CHARSET=gb2312'>
<LINK REL='stylesheet' HREF='../css/igenus.css' TYPE='TEXT/CSS'>
<STYLE TYPE='TEXT/CSS'>
<!--
body { font-family: Tahoma}
-->
</STYLE>
</HEAD>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH=100% HEIGHT=48 BACKGROUND='../images/bg-table1.gif'>
<TR>
   <TD ALIGN='left'><DIV CLASS='title'><FONT COLOR='black' SIZE=3>�ʼ�ת��</FONT></DIV></TD>
      <TD ALIGN='right'><font face='Verdana, Arial, Helvetica' color='black' size='2'>Qwebmail</font><font face='Verdana, Arial, Helvetica' color='black' size='2'>&nbsp;&nbsp;</font></TD>
</TR>
</TABLE>
      <hr size="1">
      <form method="post" action="forward.php" name="">
        <p><br>
        </p>
        <table width="60%" border="0" cellspacing="2" cellpadding="2">
          <tr> 
            <td align="right" class="tab01">ת����Ч: </td>
            <td class="tab02" bgcolor="#FFFFFF"> 
              <input type="checkbox" name="forwardactive" value="1" <?if($forward[0]=='1'){echo checked;}?> >
            </td>
          </tr>
          <tr> 
            <td align="right" class="tab01">ת����ָ���û�:</td>
            <td class="tab02" bgcolor="#FFFFFF"> 
              <input type="text" name="forwarddes"  CLASS="myinput2" maxlength="30" value="<?echo $forward[1];?>" >
            </td>
          </tr>
          <tr> 
            <td align="right" class="tab01">�ڱ�վ����:</td>
            <td class="tab02" bgcolor="#FFFFFF"> 
              <input type="checkbox" name="keeplocal"  value="1"  <?if($forward[2]=='1'){echo checked;}?>>
            </td>
          </tr>
        </table>
        <table width="60%" border="0" cellspacing="2" cellpadding="2">
        <tr><td align="center"><p align=center>
          <input type=submit name=update value=" ȷ �� " CLASS=myinput style='font-family:Tahoma'>
          </p>
          <hr size="1">
        <td></tr>
      </form>
      <p>&nbsp;</p>
    </td>
  </tr>

  </tr>
</table>
</body>
</html>