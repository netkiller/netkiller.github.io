<?php
/*-
 * Qwebmail3.0
 * 
 * Copyright (c) 1999-2002 by lnxsoft Inc.
 * All rights reserved.
 * Author: hufanjie <hfj@lnxsoft.com>
 *
 */

function Parse_head($FD_MAIL){
	$header = array();
	$linepre = "";
	while(($line = chop(fgets($FD_MAIL,1024))) && $line !=""){
		if(preg_match("/^\s+/",$line)){
			$line = preg_replace("/^\s+/"," ",$line);
			$line = $linepre.$line;
		} else {
			$linepre = "";
		}
		list($name,$value) = split(":",$line,2);
		$linepre = $line;
		$name = strtolower($name);
		$header["$name"] = Chop1st($value);
		
		$header = SplitSubType($header,$name);
/*		list($header["$name"],$str) = split(";",$header["$name"],2);
		$str = Chop1st($str);
		if (!empty($str)){
			list($name,$value) = split("=",$str,2);
			$name = strtolower($name);
			$header["$name"] = ChopQuota(Chop1st($value));
		}
*/
		
	}
	
//	if (empty($header["content-transfer-encoding"])) $header["content-transfer-encoding"] = "8bit";

	return $header;
}

function Parse_head2($FD_MAIL){
	$header = array();
	$linepre = "";
	while(($line = chop(fgets($FD_MAIL,1024)))){
		if(preg_match("/^\s+/",$line)){
			$line = preg_replace("/^\s+/"," ",$line);
			$line = $linepre.$line;
		} else {
			$linepre = "";
		}
		list($name,$value) = split(":",$line,2);
		$linepre = $line;
		$name = strtolower($name);
		$header["$name"] = Chop1st($value);
		
		$header = SplitSubType($header,$name);
	}
	
	$header['subject'] = Decode_mime($header['subject']);
	$header['date'] = Date2stamp($header['date']);
	// Get mail file size
	fseek($FD_MAIL,0,SEEK_END);
	$header['size'] = ftell($FD_MAIL);
	

	// split from address 
	list($name,$from) = split(" <",$header['from'],2);
	if ($from =="") {$from = $name;$name ="";}
	if (substr($from,strlen($from)-1,1)==">") $from = substr($from,0,strlen($from)-1);
	if ($name != "") {
	} else {
		list($name,$null) = split('@',$from);
	}
	$name = Decode_mime($name);
	$header['fromname'] = ChopQuota($name);
	$header['from'] = Decode_mime($from);
	
	
	if($header['content-type'] == "multipart/mixed"){
	$header['Content-Disposition'] = 1;
	} else{
	 $header['Content-Disposition'] = 0;
	}
	return $header;
}


function SplitSubType($header,$name){
	list($header["$name"],$value) = split(";",$header["$name"],2);
	$value = Chop1st($value);
	if (!empty($value)){
		list($name,$value) = split("=",$value,2);
		$name = Chop1st(strtolower($name));
		$value = Chop1st($value);
	}
	if (!empty($value)){
		list($prevalue,$value) = split(";",$value,2);
		$header["$name"] = ChopQuota(Chop1st($prevalue));
		list($name,$value) = split("=",$value,2);
		$name = Chop1st(strtolower($name));
		$header["$name"] = ChopQuota(Chop1st($value));
	}
	return $header;
}
// End of Parse header

function Decode_FromAddr($from){
	list($name,$from) = split(" <",$from,2);
	if ($from =="") {$from = $name;$name ="";}
	if (substr($from,strlen($from)-1,1)==">") $from = substr($from,0,strlen($from)-1);
	if ($name != "") {
	} else {
		list($name,$null) = split('@',$from);
		
	}
	$name = Decode_mime($name);
	print $name."|".$from;
	$header['fromname'] = ChopQuota($name);
	$header['from'] = Decode_mime($from);
	return $header;
}


// ���������ַ���
function Num2Str($num,$bitlen){
	$mylen = strlen($num);
	$mylen = $bitlen - $mylen; 
	if ( $mylen > 0 ) $num = str_repeat("0",$mylen) .$num;
	return $num;
}


// 
function Decode_mime($str){
	$result = imap_mime_header_decode($str);
	for($i=0;$i<count($result);$i++) {
		if (chop($result[$i]->text)!=""){
			$out .= $result[$i]->text;
		}
	}
	return $out;
}

/*
function Decode_mime($str){
	if ( substr($str,0,2)=='=?' && substr($str,strlen($str)-2,2)=='?='){
		$str = substr($str,2,strlen($str)-4);
		list($charset,$type,$str) = split("\?",$str,3);
		switch($type){
			case "Q":
				$str = quoted_printable_decode($str);
				break;
			case "B":
				$str = base64_decode($str);
				break;
		}
	}
//	echo $str;
	return $str;
}
*/

// 
function Date2stamp($dateStr){
	list($dateStr,$null) = split(',',$dateStr);
	if ($null !="" ) $dateStr = $null;
	$dateStr = Chop1st($dateStr);
	list($day,$month,$year,$time,$gmt ) = split(' ',$dateStr,5);
//	print $day."|".$month."|".$year."|".$time."|".$gmt;
	$month = strtolower($month);
	$monthof = array(	'jan'=>1,
					'feb'=>2,
					'mar'=>3,
					'apr'=>4,
					'may'=>5,
					'jun'=>6,
					'jul'=>7,
					'aug'=>8,
					'sep'=>9,
					'oct'=>10,
					'nov'=>11,
					'dec'=>12);
	$month = $monthof[$month];
	list($hour,$minute,$second) = split(':',$time);
	if ($gmt =="GMT") $gmt = 0;
	$gmt = $gmt /100;
	$hour = $hour - $gmt;
//	print $hour."|".$minute."|".$second;
	return mktime($hour,$minute,$second,$month,$day,$year);
	
}

// �޳��ַ����׵Ŀո�
function Chop1st($str){
//	if (substr($str,0,1)==" ") {
//		$str = substr($str,1);
		$str = preg_replace("/^\s+/","",$str);
//	}
	
	return $str;
}

// �޳��ַ�����β������
function ChopQuota($str){
	if(substr($str,0,1)=="\"" && substr($str,strlen($str)-1,1)=="\""){
		$str = substr($str,1,strlen($str)-2);
	}
	return $str;
}

function ChopQuota2($str){
	if(substr($str,0,1)=='<' && substr($str,strlen($str)-1,1)=='>'){
		$str = substr($str,1,strlen($str)-2);
	}
	return $str;
}


// �����ַ���Ϊָ�����ȣ������޳��������
function TrimStr($string,$length){
	$tmp = $string;
	$len = strlen($string);
	$checkchar = "";
	for($i=0;$i<$len+2;$i++)
		$checkchar = $checkchar." ";
	if($len <= $length)
		return $string;
	for($i=0;$i<$length;$i++)
	{
		$ac = ord($tmp[$i]);
		if($ac >= 161)
		{
			$checkchar [$i] = chr($ac);
			$checkchar [$i+1] = chr(ord($tmp[$i+1]));
			$i++;
			countinue;
		}
		else
		{
			$checkchar [$i] = chr($ac);
		}
	}
	return trim($checkchar)."��";
} 

function Date2Str($TimeStamp,$gmt){
	$TimeStamp = $TimeStamp + 60 * 60  * $gmt;
	$date = getdate($TimeStamp);
	$ret[0] = $date['mon']."/".$date['mday']." ".
			$date['hours'].":".$date['minutes'];
	$ret[1] = $date['year']."/".$date['mon']."/".$date['mday']." ".
			$date['hours'].":".$date['minutes'].":".$date['seconds'];
	return $ret;
}

function FormatSize($size){
	if ($size <1024) return $size."B";
	$size = intval($size / 1024)+ 1;
	return $size."KB";
}

// remove the attachment list file
function DelAttach(){
	global $CFG_TEMP,$G_DOMAIN,$G_USERNAME;
	
	$listattachfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_attach";
	if (file_exists($listattachfile)){
/*
		($FD_LIST_ATTACH = fopen($listattachfile,"r")) || die("Error open $listattachfile!");
		while( $buff = chop(fgets($FD_LIST_ATTACH,1024)) ){
			list($name,$size,$type) = split("\t",$buff,3);
			$name = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach/$name";
			if (file_exists($name)) unlink($name);
		}
		fclose($FD_LIST_ATTACH);
*/
		unlink($listattachfile);
	}
	if(!is_dir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach")) return;
	$dir = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach";
	$DIR_HANDLE = opendir($dir);
	if($DIR_HANDLE){
		while (($file = readdir($DIR_HANDLE))!==false) {
    	if($file !="." && $file !="..")
    		unlink("$dir/$file");
		}
		closedir($DIR_HANDLE);
	}
}

function DelAttachdomain(){
	global $CFG_TEMP,$G_DOMAIN,$G_USERNAME;
	
	$listattachfile = "$CFG_TEMP/$G_DOMAIN/list_attach";
	if (file_exists($listattachfile)){
		unlink($listattachfile);
	}
	if(!is_dir("$CFG_TEMP/$G_DOMAIN/attach")) return;
	$dir = "$CFG_TEMP/attach";
	$DIR_HANDLE = opendir($dir);
	if($DIR_HANDLE){
		while (($file = readdir($DIR_HANDLE))!==false) {
    	if($file !="." && $file !="..")
    		unlink("$dir/$file");
		}
		closedir($DIR_HANDLE);
	}
}

function DelAttachadmin(){
	global $CFG_TEMP,$G_DOMAIN,$G_USERNAME;
	
	$listattachfile = "$CFG_TEMP/list_attach";
	if (file_exists($listattachfile)){
		unlink($listattachfile);
	}
	if(!is_dir("$CFG_TEMP/attach")) return;
	$dir = "$CFG_TEMP/attach";
	$DIR_HANDLE = opendir($dir);
	if($DIR_HANDLE){
		while (($file = readdir($DIR_HANDLE))!==false) {
    	if($file !="." && $file !="..")
    		unlink("$dir/$file");
		}
		closedir($DIR_HANDLE);
	}
}

function write($G_HOME,$content,$name){
	 	       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file=$name;
                       $fp = fopen($tempdir.$file, "w");
                       fwrite($fp, "$content");
                       fclose($fp);
                       chmod($tempdir.$file,0600);
         }

function writeadmin($G_HOME,$content,$name){
	 	       $tempdir = ("$G_HOME/");
                       chdir($tempdir);
                       $file=$name;
                       $fp = fopen($tempdir.$file, "w");
                       fwrite($fp, "$content");
                       fclose($fp);
                       chmod($tempdir.$file,0600);
         }

function read($G_HOME,$name){
	 	       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file=$name;
                       if (file_exists($tempdir.$file)){
                       $fp = fopen($tempdir.$file, "r" );
                       while ($buffer = fgets($fp, 4096)) {
                       $content.= $buffer;
                         }
                      fclose($fp);
                }
                
                return $content;
         }


function readadmin($G_HOME,$name){
	 	       $tempdir = ("$G_HOME/");
                       chdir($tempdir);
                       $file=$name;
                       if (file_exists($tempdir.$file)){
                       $fp = fopen($tempdir.$file, "r" );
                       while ($buffer = fgets($fp, 4096)) {
                       $content.= $buffer;
                         }
                      fclose($fp);
                }
                
                return $content;
         }

function pop($G_HOME,$popmail){
	            $tempdir = ("$G_HOME/Maildir/new/");
                    chdir($tempdir);
                    mt_srand((double)microtime()*1000000);
                    $randval = mt_rand();
                    $a=(date("Y")-1970)*365*12*30*12*60*60+(date("n")-1)*30*12*60*60+(date("j")-1)*12*60*60+date("G")*60*60+date("i")*60+$randval;
                    $b=getmypid(void);
                    $file="file";
                    $fp = fopen($tempdir.$file, "w");
                    fwrite($fp, "$popmail\n");
                    fclose($fp);
                    $c=filesize($tempdir.$file);
                    $oldname="$tempdir$file";
                    $newname="$a.$b.$G_DOMAIN,s=$c";
                    rename($oldname,$newname);
          }    

function popset($G_HOME,$content){
	 	       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file="pop";
                       $fp = fopen($tempdir.$file, "a+");
                       fwrite($fp, "$content\n");
                       fclose($fp);
         }


function popmodify($G_HOME,$content1,$id){
	               $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file="pop";
                       $filebak="popbak";
                       rename($file,$filebak);
                       ($FD_LIST = fopen("popbak","r+"))||die("Error open file!");
	                $i = 0;
	                while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                {
	                   if ($id==$i)
	                      {
                               $fp = fopen($tempdir.$file, "a+");
                               fwrite($fp, "$content1\n");
                               fclose($fp);
                              }
                            else{
                                $fp = fopen($tempdir.$file, "a+");
                                fwrite($fp, "$line");
                                 fclose($fp);
                                }
                           $i++;
                          }
                         fclose($FD_LIST);
         }


function popdel($G_HOME,$content1,$id){
	               $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file="pop";
                       $filebak="popbak";
                       rename($file,$filebak);
                       ($FD_LIST = fopen("popbak","r+"))||die("Error open file!");
	                $i = 0;
	                while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) ){
	               if ($id==$i){
                       }
                       else{
                       $fp = fopen($tempdir.$file, "a+");
                       fwrite($fp, "$line");
                       fclose($fp);
                }
                      $i++;
                }
                       fclose($FD_LIST);
         }

function autoresponseset($G_HOME,$content,$rulename){
	 	       $tempdir = ("$G_HOME/Maildir/autoresponses/");
                       chdir($tempdir);
                       $file=$rulename;
                       $fp = fopen($tempdir.$file, "w");
                       fwrite($fp, "$content\n");
                       fclose($fp);
         }
         
function readreply($G_HOME,$name){
	 	       $tempdir = ("$G_HOME/Maildir/autoresponses/");
                       chdir($tempdir);
                       $file=$name;
                       if (file_exists($tempdir.$file)){
                       $fp = fopen($tempdir.$file, "r" );
                       while ($buffer = fgets($fp, 4096)) {
                       $content.= $buffer;
                         }
                      fclose($fp);
                }
                
                return $content;
         }        

function filtermodify($G_HOME,$filtername,$rule){
	              $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file="filter";
                       $filebak="filterbak";
                       rename($file,$filebak);
                       
                       ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                  while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                  {
	                    $filtername=trim($filtername);
	                     $filterrule=split(":",$line);
	                    $filter=trim($filterrule[1]);
	                   
		        
		            if(($filter==$filtername)&&($filterrule[0]=='##name'))
	                   {
	                   	while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	               	     {
			     $filterrule1=split(":",$line);
		             if($filterrule1[0]=='##name')
		               {
	                         $FD=1;
                               }
                             }
                             }
                          } 
                         fclose($FD_LIST);
                       
                       ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                $i = 0;
	                while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) ){
	               $filterrule=split(":",$line);
	               
	              $filtername=trim($filtername);
	               $filter=trim($filterrule[1]);
	              
		       if(($filter==$filtername)&&($filterrule[0]=='##name'))
	               {
	               	   while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	               	   {
			     $filterrule=split(":",$line);
		             if($filterrule[0]=='##name')
		               {
		                $fp = fopen($tempdir.$file, "a+");
		                fwrite($fp, "$rule\n");
                                fwrite($fp, "$line");
                                fclose($fp);
                                while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	               	         {
	               	         $fp = fopen($tempdir.$file, "a+");
                                 fwrite($fp, "$line");
                                 fclose($fp);
                                 }
                               }
                           }
                        }
                       else{
                       $fp = fopen($tempdir.$file, "a+");
                       fwrite($fp, "$line");
                       fclose($fp);
                       }
                      $i++;
                }
                       fclose($FD_LIST);
                       if ($FD!='1'){
                         	$fp = fopen($tempdir.$file, "a+");
                                 fwrite($fp, "$rule\n");
                                 fclose($fp);
                                }
                       chmod($tempdir.$file, 0600 );       
         }


function filterdel($G_HOME,$filtername){
	               $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file="filter";
                       $filebak="filterbak";
                       rename($file,$filebak);
                       ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                $i = 0;
	                while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) ){
	               $filterrule=split(":",$line);
	               
	              $filtername=trim($filtername);
	               $filter=trim($filterrule[1]);
	              
		       if(($filter==$filtername)&&($filterrule[0]=='##name'))
	               {
	               	   while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	               	   {
			     $filterrule=split(":",$line);
		             if($filterrule[0]=='##name')
		               {
		                $fp = fopen($tempdir.$file, "a+");
                                fwrite($fp, "$line");
                                fclose($fp);
                                while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	               	         {
	               	         $fp = fopen($tempdir.$file, "a+");
                                 fwrite($fp, "$line");
                                 fclose($fp);
                                 }
                               }
                           }
                        }
                       else{
                       $fp = fopen($tempdir.$file, "a+");
                       fwrite($fp, "$line");
                       fclose($fp);
                       }
                      $i++;
                }
                       fclose($FD_LIST);
                       
         }

function writeforward($G_HOME,$content,$name){
	 	       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file=$name;
                       $fp = fopen($tempdir.$file, "w");
                       fwrite($fp, "$content");
                       fclose($fp);
         }

function forward($G_HOME,$content){
	               $tempdir = ("$G_HOME/");
                       chdir($tempdir);
                       $file=".qmail";
                       if (file_exists($tempdir.$file))
                       {
                          $filebak="qmailbak";
                          rename($file,$filebak);
                          ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                  while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                  {
	                    $forward=split("@",$line);
		            if($forward[1]!='')
	                    { 
	                   	$FD=1;
                            }
                         }
                         fclose($FD_LIST);
                          ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                  $i = 0;
	                  while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                  {
	                    $forward=split("@",$line);
		            if($forward[1]!='')
	                    {
		                 $fp = fopen($tempdir.$file, "a+");
                                 fwrite($fp, "$content");
                                 fclose($fp);
                               while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) ){
	                       }
                            }
                           else{
                                $fp = fopen($tempdir.$file, "a+");
                                fwrite($fp, "$line");
                                fclose($fp);
                               }
                            $i++;
                      }
                         fclose($FD_LIST);
                         if ($FD!='1'){
                         	$fp = fopen($tempdir.$file, "a+");
                                 fwrite($fp, "$content");
                                 fclose($fp);
                                 }
                    }
                   else{
	               	         $fp = fopen($tempdir.$file, "a+");
                                 fwrite($fp, "$content");
                                 fclose($fp);
                        }
         }

function readforward($G_HOME,$name){
	 	       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file=$name;
                       if (file_exists($tempdir.$file)){
                       $fp = fopen($tempdir.$file, "r" );
                       while ($buffer = fgets($fp, 4096)) {
                       $content.= $buffer;
                         }
                      fclose($fp);
                }
                return $content;
         }
         
function writeqmail($G_HOME,$content){
	 	       $tempdir = ("$G_HOME/");
                       chdir($tempdir);
                       $file=".qmail";
                       if (!file_exists($tempdir.$file))
                       {
                       $fp = fopen($tempdir.$file, "w");
                       fwrite($fp, "$content");
                       fclose($fp);
                       chmod($tempdir.$file,0600);
                       }
                  
                }
                
function writerefuse($G_HOME,$content){
	               if(!is_dir("$G_HOME/Maildir/autoresponses")){
	               mkdir("$G_HOME/Maildir/autoresponses",0750);}
	 	       $tempdir = ("$G_HOME/Maildir/autoresponses/");
                       chdir($tempdir);
                       $file="refuse";
                       if (!file_exists($tempdir.$file))
                       {
                       $fp = fopen($tempdir.$file, "w");
                       fwrite($fp, "$content");
                       fclose($fp);
                       chmod($tempdir.$file,0600);
                        }
                }

 function modifyrefuse($G_HOME,$rule){
	              $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file="filter";
                       $filebak="filterbak";
                       rename($file,$filebak);
                       $fp = fopen($tempdir.refuse, "w");
                       fwrite($fp, "$rule");
                       ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                  while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                  {
                                fwrite($fp, "$line");
                           }
                        fclose($FD_LIST);
                        fclose($fp);                                
                       chmod($tempdir.$file, 0600 );       
         }  
         
         
 function ruletolocal($G_HOME,$filter8){
                       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file=filter;
                       $filebak="filterbak";
                       if(file_exists("$G_HOME/Maildir/filter"))
                       {
                           rename($file,$filebak);
                           ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                     $i = 0;
	                          while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                        {
                                   $i++;
                                }
                            fclose($FD_LIST);
                          
                          ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
                            $j = 0;
                                while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                      {
	                           if ($j==($i-1)){
	                	       if($line==$filter8){}
	                	       else{
	                	            $fp = fopen($tempdir.$file, "a+");
                                            fwrite($fp, "$filter8\n");
                                             fclose($fp);
	                	       }
	                           }
                                   else{
                                      $fp = fopen($tempdir.$file, "a+");
                                      fwrite($fp, "$line");
                                      fclose($fp);
                                   } 
                                 $j++;
                               }
                           fclose($FD_LIST);
                         }
                        else{
                         $fp = fopen($tempdir.$file, "a+");
                             fwrite($fp, "$filter8\n");
                             fclose($fp);
                            }  
} 


function sendlocal($G_HOME,$name){
	 	       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file=$name;
                       if (file_exists($tempdir.$file)){
                       ($FD_LIST = fopen($tempdir.$file,"r+"))||die("Error open file!");
                                $i = 0;
	                          while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                        {
                                   $i++;
                                }
                                fclose($FD_LIST);
                       
                       $fp = fopen($tempdir.$file, "r" );
                          $j = 0;
                             while ($line = fgets($fp, 1024)) {
                               if($j==($i-1)){
                                return $line;
                                }
                                $j++;
                             }
                             fclose($fp);
                     }
                   
         }                  
?>