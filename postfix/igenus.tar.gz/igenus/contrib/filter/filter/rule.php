<?
/*-
 * Qwebmail3.0
 * 
 * Copyright (c) 1999-2002 by lnxsoft Inc.
 * All rights reserved.
 * Author: hufanjie <hfj@lnxsoft.com>
 *
 */

include "../include/login_inc.php";
include "../config/config_inc.php";
include "../include/fun_inc.php";
if($add!=''){
if($from_active!=''&&$from_text!=''){
if($from_active == "1") {
                 if($from_case != '1'){
                      $from_text1 = strtolower($from_text);
                      $from_text2 = strtoupper($from_text);
                      }
		if ($from_cond == "12"){
			 if($from_case != '1'){
			 $filter1="/^From:.*$from_text*/ || /^From:.*$from_text1*/ || /^From:.*$from_text2*/";}
			    else{
			     $filter1="/^From:.*$from_text*/";}
                             }
	        elseif($from_cond == "13"){
	        	if($from_case != '1'){
	        	$filter1="/^From:!.*$from_text*/ || /^From:!.*$from_text1*/ || /^From:!.*$from_text2*/";}
	        	    else{
	        	    $filter1="/^From:!.*$from_text*/";}
			     }
                elseif($from_cond == "14"){
                	if($from_case != '1'){
	        	$filter1="/^From:.*$from_text>/ || /^From:.*$from_text1>/ || /^From:.*$from_text2>/)";}
	        	     else{
	        	     $filter1="/^From:.*$from_text>/";}
			     }
		elseif($from_cond == "15"){
			if($from_case != '1'){
	        	$filter1="/^From:!.*$from_text>/ || /^From:!.*$from_text1>/ || /^From:!.*$from_text2>/";}
	        	     else{
	        	     $filter1="/^From:!.*$from_text>/";}
			     }
		elseif($from_cond == "16"){
			if($from_case != '1'){
	        	$filter1="/^From:*$from_text*.>/ || /^From:*$from_text1*.>/ || /^From:*$from_text2*.>/";}
	        	     else{
	        	     $filter1="/^From:!.*$from_text*.>/";}
			     }
                elseif($from_cond == "17"){
                	if($from_case != '1'){
	        	$filter1="/^From:.*$from_text>/ || /^From:.*$from_text1>/ || /^From:.*$from_text2>/";}
	        	     else{
	        	     $filter1="/^From:.*$from_text>/";}
			     }
	        else{
                  $from_cond = '';
                  $from_case = '';
                  $from_text = '';
                      }
	       }
else{
$from_cond = '';
$from_case = '';
$from_text = '';
$filter1=0;
}
}
else{
$from_cond = '';
$from_case = '';
$from_text = '';
$filter1=0;
}

if($rcpt_active != ''&& $rcpt_text!=''){
if($rcpt_active == "1") {
                  if($rcpt_case != '1'){
                      $rcpt_text1 = strtolower($rcpt_text);
                      $rcpt_text2 = strtoupper($rcpt_text);
                      }
		if ($rcpt_cond == "12"){
			if($rcpt_case != '1'){
			 $filter2="/^To:.*$rcpt_text*/ || /^To:.*$rcpt_text1*/ || /^To:.*$rcpt_text2*/";}
			   else{
			   $filter2="/^To:.*$rcpt_text*/";}
                             }
	        elseif($rcpt_cond == "13"){
	        	if($rcpt_case != '1'){
	        	$filter2="/^To:!.*$rcpt_text*/ || /^To:!.*$rcpt_text1*/ || /^To:!.*$rcpt_text2*/";}
	        	   else{
	        	   $filter2="/^To:!.*$rcpt_text*/";}
			     }
                elseif($rcpt_cond == "14"){
                	if($rcpt_case != '1'){
	        	$filter2="/^To:.*$rcpt_text>/ || /^To:.*$rcpt_text1>/ || /^To:.*$rcpt_text2>/";}
	        	   else{
	        	   $filter2="/^To:.*$rcpt_text>/";}
			     }
		elseif($rcpt_cond == "15"){
			if($rcpt_case != '1'){
	        	$filter2="/^To:!.*$rcpt_text>/ || /^To:!.*$rcpt_text1>/ || /^To:!.*$rcpt_text2>/";}
	        	   else{
	        	   $filter2="/^To:!.*$rcpt_text>/";}
			     }
		elseif($rcpt_cond == "16"){
			if($rcpt_case != '1'){
	        	$filter2="/^To:.*$rcpt_text*.>/ || /^To:.*$rcpt_text1*.>/ || /^To:.*$rcpt_text2*.>/";}
	        	    else{
	        	    $filter2="/^To:.*$rcpt_text*.>/";}
			     }
                elseif($rcpt_cond == "17"){
                	if($rcpt_case != '1'){
	        	$filter2="/^To:.*$rcpt_text>/ || /^To:.*$rcpt_text1>/ || /^To:.*$rcpt_text2>/";}
	        	    else{
	        	    $filter2="/^To:.*$rcpt_text>/";}
			     }
                 else{
                  $rcpt_cond = '';
                  $rcpt_case = '';
                  $rcpt_text = '';
                      }
	       }
else {
$rcpt_cond = '';
$rcpt_case = '';
$rcpt_text = '';
$filter2=0;
}	       
}
else{
$rcpt_cond = '';
$rcpt_case = '';
$rcpt_text = '';
$filter2=0;
}

if($subj_active !=''&& $subj_text!=''){
if($subj_active == "1") {
                  if($subj_case != '1'){
                      $subj_text1 = strtolower($subj_text);
                      $subj_text2 = strtoupper($subj_text);
                      }
		if ($subj_cond == "12"){
			if($subj_case != '1'){
			 $filter3="/^Subject:.*$subj_text*/ || /^Subject:.*$subj_text1*/ || /^Subject:.*$subj_text2*/";}
			   else{
			    $filter3="/^Subject:.*$subj_text*/";}
                             }
	        elseif($subj_cond == "13"){
	        	if($subj_case != '1'){
	        	$filter3="/^Subject:!.*$subj_text*/ || /^Subject:!.*$subj_text1*/ || /^Subject:!.*$subj_text2*/";}
	        	else{
	        	$filter3="/^Subject:!.*$subj_text*/";}
			     }
                elseif($subj_cond == "14"){
                	if($subj_case != '1'){
	        	$filter3="/^Subject: $subj_text/ || /^Subject: $subj_text1/ || /^Subject: $subj_text2/";}
	        	else{
	        	$filter3="/^Subject: $subj_text/";}
			     }
		elseif($subj_cond == "15"){
			if($subj_case != '1'){
	        	$filter3="/^Subject:!.*$subj_text/ || /^Subject:!.*$subj_text1/ || /^Subject:!.*$subj_text2/";}
	        	else{
	        	$filter3="/^Subject:!.*$subj_text/";}
	        	
			     }
		elseif($subj_cond == "16"){
			if($subj_case != '1'){
	        	$filter3="/^Subject: $subj_text*/ || /^Subject: $subj_text1*/ || /^Subject: $subj_text2*/";}
	        	else{
	        	$filter3="/^Subject: $subj_text*/";}
			     }
                elseif($subj_cond == "17"){
                	if($subj_case != '1'){
	        	$filter3="/^Subject:.*$subj_text/ || /^Subject:.*$subj_text1/ || /^Subject:.*$subj_text2/";}
	        	else{
	        	 $filter3="/^Subject:.*$subj_text/";}
			     }
	        else{
                  $subj_cond = '';
                  $subj_case = '';
                  $subj_text = '';
                      }
	       }
else{
$subj_cond = '';
$subj_case = '';
$subj_text = '';
$filter3=0;
}
}
else{
$subj_cond = '';
$subj_case = '';
$subj_text = '';
$filter3=0;
}

if($size_active!=''&& $size_text!=''){
if($size_active == "1") {
		if ($size_cond == "18"){
			 $filter4="\$SIZE >= $size_text";
                             }
	        elseif($size_cond == "19"){
	        	$filter4="\$SIZE < $size_text";
			     }	 
	        else{
                       $size_cond = ''; 
                       $size_text = '';
                             }
	       }
else{
$size_cond = '';
$size_text = '';
$filter4=0;
}
}
else{
$size_cond = '';
$size_text = '';
$filter4=0;
}


if($move_active  == "1"){
	if($move_text == "1"){
		$dir=".";
		$move=
		$do.="ת�Ƶ��ռ���,";
	}
	  elseif($move_text == "4"){
	  	$dir=".Trash";
	  	$do.="ת�Ƶ�������,";
	   }
$filter6="to \"$G_HOME/Maildir/$dir\"";
}
else{
 $move_text = '';
 }


if($reply_active  == "1"&&$reply_text!=''){
	autoresponseset($G_HOME,$reply_text,$rulename);
	$filter7="`/usr/local/bin/mailbot -A \"X-Sender:$G_USERNAME@$G_DOMAIN\" -A \"From:$G_USERNAME@$G_DOMAIN\" -m \"$G_HOME/Maildir/autoresponses/$rulename\" \$SENDMAIL -f \"\"`";
$do.="�Զ��ظ�";
}
if($reject_active  == "1"){
$filter5="`/usr/local/bin/mailbot -A \"X-Sender: $G_USERNAME@$G_DOMAIN\" -A \"From: $G_USERNAME@$G_DOMAIN\" -s \"Undelivered Mail Returned ���޷�Ͷ�ݵ����ţ�\" -m \"$G_HOME/Maildir/autoresponses/refuse\" \$SENDMAIL -f \"\"`\nto \"/dev/null\"";
   $do.="�����ʼ�";
    }
$filter8="to \"$G_HOME/Maildir/.\"";
if (($filter1!=''||$filter2!=''||$filter3!=''||$filter4!='')&&($filter5!=''||$filter6!=''||$filter7!='')){
$rule="##name:$rulename\n##from:$from_cond,$from_text,$from_case\n##rcpt:$rcpt_cond,$rcpt_text,$rcpt_case\n##subj:$subj_cond,$subj_text,$subj_case\n##size:$size_cond,$size_text\n##do:$do\n##move:$move_text\n##reply:$reply_active\n##reject:$reject_active\nif($filter1 || $filter2 || $filter3 ||$filter4)\n{\n$filter5\n$filter7\n$filter6\n}\n$filter8";
	 	       $tempdir = ("$G_HOME/Maildir/");
                       chdir($tempdir);
                       $file=filter;
                       $filebak="filterbak";
                       if(file_exists("$G_HOME/Maildir/filter"))
                       {
                          rename($file,$filebak);
                          ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
	                  $i = 0;
	                  while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                  {
                           $i++;
                          }
                          fclose($FD_LIST);
                          ($FD_LIST = fopen("$filebak","r+"))||die("Error open file!");
                           $j = 0;
                          while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) )
	                   {
	                	if ($j==($i-1)){}
                            else{
                                $fp = fopen($tempdir.$file, "a+");
                                fwrite($fp, "$line");
                                 fclose($fp);
                                } 
                            $j++;
                           }
                             fclose($FD_LIST);
                             $fp = fopen($tempdir.$file, "a+");
                             fwrite($fp, "$rule\n");
                             fclose($fp);
                         }
                        else{
                         $fp = fopen($tempdir.$file, "a+");
                             fwrite($fp, "$rule\n");
                             fclose($fp);
                            }
         if(file_exists("$G_HOME/Maildir/filter")){chmod("$G_HOME/Maildir/filter",0600);}
                            header("Location: filter1.php");
                           
         exit;  
  }
  else{
  echo "��������д��Ϣ";
  }      

}

?>


<HTML>
<HEAD>
<TITLE>�ʼ�����</TITLE>
   <META HTTP-EQUIV='Content-Type' CONTENT='text/html;CHARSET=gb2312'>
<LINK REL='stylesheet' HREF='../css/igenus.css' TYPE='TEXT/CSS'>
<STYLE TYPE='TEXT/CSS'>
<!--
body { font-family: Tahoma }
-->
</STYLE>


<script language=javascript>
function check()
{
    if ( document.form.rulename.value == "" )
    {
        alert( "�ʼ����˹������Ʋ���Ϊ�գ�\r\r��������д" );
        return false;
    }
    if ( document.form.from_active.checked != true && document.form.rcpt_active.checked != true && document.form.subj_active.checked != true && document.form.size_active.checked != true )
    {
        alert( "��ѡ��һ���������˹���\r\r��������д" );
        return false;
    }
    if ( document.form.reject_active.checked != true && document.form.move_active.checked != true &&  document.form.reply_active.checked != true )
    {
        alert( "��ѡ��һ���������˹���ִ��ѡ�\r\r��������д" );
        return false;
    }
    if ( document.form.from_active.checked == true && document.form.from_text.value == "" )
    {
        alert( "����ʼ���Դ����Ϊ�գ�\r\r��������д" );
        return false;
    }
    if ( document.form.rcpt_active.checked == true && document.form.rcpt_text.value == "" )
    {
        alert( "����ʼ������߲���Ϊ�գ�\r\r��������д" );
        return false;
    }
    if ( document.form.subj_active.checked == true && document.form.subj_text.value == "" )
    {
        alert( "����ʼ����ⲻ��Ϊ�գ�\r\r��������д" );
        return false;
    }
    if ( document.form.size_active.checked == true && document.form.size_text.value == "" )
    {
        alert( "����ʼ���С����Ϊ�գ�\r\r��������д" );
        return false;
    }
    if ( document.form.reply_active.checked == true && document.form.reply_text.value == "" )
    {
        alert( "����ʼ��Զ��ظ�����Ϊ�գ�\r\r��������д" );
        return false;
    }
    return true;
}
</SCRIPT>
</HEAD>
<body bgcolor="#FFFFFF" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr valign="top"> 
    <td class="tab03" align="center"> 
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH=100% HEIGHT=48 BACKGROUND='../images/bg-table1.gif'>
<TR>
   <TD ALIGN='left'><DIV CLASS='title'><FONT COLOR='black' SIZE=3>�ʼ�����</FONT></DIV></TD>
      <TD ALIGN='right'><font face='Verdana, Arial, Helvetica' color='black' size='2'>Qwebmail</font><font face='Verdana, Arial, Helvetica' color='black' size='2'>&nbsp;&nbsp;</font></TD>
</TR>
</TABLE>
      <hr size="1">
      <form method="post" onsubmit="return check();" action="rule.php" name="form">
        <p class="tab03">�ʼ����˹�������: 
          <input type="text" name="rulename" CLASS="myinput2" value="" >
        </p>
        <table class="content" width="70%">
          
        </table>
        <hr size="1">
        <p class="tab03">ѡ�񱾹�������: [��ѡ�����������е�һ������] </p>
        <table class="content" width="80%">
          <tr> 
            <td class="tab03"> 
              <input type="checkbox" name="from_active" value="1"  >
              ����ʼ���Դ</td>
            <td class="tab03"> 
              <select name="from_cond" CLASS="myselect">
                <option value="12"  >����</option>
                <option value="13"  >������</option>
                <option value="14"  >��</option>
                <option value="15"  >����</option>
                <option value="16"  >��...��ʼ</option>
                <option value="17"  >��...����</option>
              </select>
            </td>
            <td class="tab03"> 
              <input type="text" name="from_text" CLASS="myinput2" value="" >
            </td>
            <td class="tab03"> ���ִ�Сд 
              <input type="checkbox" name="from_case" value="1"  >
            </td>
          </tr>
          <tr> 
            <td class="tab03"> 
              <input type="checkbox" name="rcpt_active" value="1"  >
              ����ʼ�������</td>
            <td class="tab03"> 
              <select name="rcpt_cond" CLASS="myselect">
                <option value="12"  >����</option>
                <option value="13"  >������</option>
                <option value="14"  >��</option>
                <option value="15"  >����</option>
                <option value="16"  >��...��ʼ</option>
                <option value="17"  >��...����</option>
              </select>
            </td>
            <td class="tab03"> 
              <input type="text" name="rcpt_text" CLASS="myinput2" value="" >
            </td>
            <td class="tab03"> ���ִ�Сд 
              <input type="checkbox" name="rcpt_case" value="1"  >
            </td>
          </tr>
          <tr> 
            <td class="tab03"> 
              <input type="checkbox" name="subj_active" value="1"  >
              ����ʼ�����</td>
            <td class="tab03"> 
              <select name="subj_cond" CLASS="myselect">
                <option value="12"  >����</option>
                <option value="13"  >������</option>
                <option value="14"  >��</option>
                <option value="15"  >����</option>
                <option value="16"  >��...��ʼ</option>
                <option value="17"  >��...����</option>
              </select>
            </td>
            <td> 
              <input type="text" name="subj_text" CLASS="myinput2" value="" >
            </td>
            <td > ���ִ�Сд 
              <input type="checkbox" name="subj_case" value="1"  >
            </td>
          </tr>
          <tr> 
            <td> 
              <input type="checkbox" name="size_active" value="1"  >
              ����ʼ�����</td>
            <td> 
              <select name="size_cond" CLASS="myselect">
                <option value="18"  >&gt;=</option>
                <option value="19"  >&lt;</option>
              </select>
            </td>
            <td> 
              <input type="text" name="size_text" size="10" CLASS="myinput2" value="" >
              K </td>
            <td>&nbsp; </td>
          </tr>
        </table>
        <hr size="1">
        <p class="tab03">ѡ�񱾹������: [��ѡ�����в����е�һ������] </p>
        <table width="100%" class="content">
          <tr> 
            <td class="tab03"> 
              <input type="checkbox" name="reject_active" value="1"  >
              ���շ����������ʼ�</td>
            <td colspan="2"> 
              <input type="hidden" name="fwd_active" value="1">
              <input type="hidden" name="fwd_text" size="35" class="tab03" value="" >
              <input type="hidden" name="fwd_keep" value="1">
            </td>
          </tr>
          <tr> 
            <td class="tab03"> 
              <input type="checkbox" name="move_active" value="1"  >
              ת�Ƶ�ָ���ļ���:</td>
            <td colspan="2" > 
              <select name="move_text" CLASS="myselect"><option value="1" >�ռ���</option><option value="4" >������</option>
             </select>
            </td>
          </tr>
          <tr> 
            <td class="tab03"> 
              <input type="checkbox" name="reply_active" value="1"  >
              ʹ���ʼ��Զ��ظ�:</td>
            <td colspan="2" > 
              <textarea name="reply_text" rows="8" cols="60" CLASS=mytextarea></textarea>
            </td>
          </tr>
         
        </table>
        <table width="100%">
          <tr> 
            <td colspan="2"> 
              <hr size="1">
            </td>
          </tr>
          <tr align="center"> 
            <td colspan="2"> 
              <input type=submit name=add value=" �� �� " CLASS=myinput style='font-family:Tahoma'>
              <input type=submit name=cancel value=" ȡ �� " CLASS=myinput style='font-family:Tahoma'>
            
          </tr>
        </table>
        <p>
          <input type="hidden" name="filid" value="0">
        </p>
      </form>
      <p>&nbsp;</p>
    </td>
  </tr>
  <tr valign="bottom"> 
    <td align="center" class="copyright"> 
      <hr size="1">
      <script language="JavaScript" src="/copyright.js">
</script>
    </td>
  </tr>
</table>
</body>
</html>
