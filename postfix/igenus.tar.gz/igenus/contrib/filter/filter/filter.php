<?
/*-
 * Qwebmail3.0
 * 
 * Copyright (c) 1999-2002 by lnxsoft Inc.
 * All rights reserved.
 * Author: hufanjie <hfj@lnxsoft.com>
 *
 */

include "../include/login_inc.php";
include "../config/config_inc.php";
include "../include/fun_inc.php";


$name="refuselist";
if($update!=''){
if($refuselist!=''){
	write($G_HOME,$refuselist,$name);
	$show=read($G_HOME,$name);
	$list = split(',',$show);
	$num=count($list);
	for($i=0;$i<$num;$i++){
        $filter1="/^From:.*$list[$i]>/";
        $filter2="`/usr/local/bin/mailbot -A \"X-Sender: $G_USERNAME@$G_DOMAIN\" -A \"From: $G_USERNAME@$G_DOMAIN\" -s \"Undelivered Mail Returned ���޷�Ͷ�ݵ����ţ�\" -m \"$G_HOME/Maildir/autoresponses/refuse\" \$SENDMAIL -f \"\"`\nto \"/dev/null\"";
        $rule.="if($filter1)\n{\n$filter2\n}\n";
        }
        write($G_HOME,$rule,refuse);
      }
     else{
        write($G_HOME,$refuselist,$name);
	$show=read($G_HOME,$name);
	$rule.="";
        write($G_HOME,$rule,refuse);
          }
      }
$show=read($G_HOME,$name);
	
		
	if($delete!=''){
	   filterdel($G_HOME,$filtername);
	   if(!file_exists("$G_HOME/Maildir/filter")||(strlen(sendlocal($G_HOME,filter))==2)){
	   $filterrule="to \"$G_HOME/Maildir/.\"";
	   write($G_HOME,$filterrule,filter);}
	   }
	    elseif($modify!=''){
	    	header("Location: modifyrule.php");
	    	 require("modifyrule.php");
	    	 exit;
	    	 }   	
?>
<HTML>
<HEAD>
<TITLE>�ʼ�����</TITLE>
   <META HTTP-EQUIV='Content-Type' CONTENT='text/html;CHARSET=gb2312'>
<LINK REL='stylesheet' HREF='../css/igenus.css' TYPE='TEXT/CSS'>
<STYLE TYPE='TEXT/CSS'>
<!--
body { font-family: Tahoma}
-->
</STYLE>
<SCRIPT language=JavaScript src='../script/js_lng_conl.js'></SCRIPT>
</HEAD>
<body bgcolor="#FFFFFF" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr valign="top"> 
    <td class="tab03" align="center"> 
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH=100% HEIGHT=48 BACKGROUND='../images/bg-table1.gif'>
<TR>
   <TD ALIGN='left'><DIV CLASS='title'><FONT COLOR='black' SIZE=3>�ʼ�����</FONT></DIV></TD>
      <TD ALIGN='right'><font face='Verdana, Arial, Helvetica' color='black' size='2'>Qwebmail</font><font face='Verdana, Arial, Helvetica' color='black' size='2'>&nbsp;&nbsp;</font></TD>
</TR>
</TABLE>
      <hr size="1">
      <p><span class="normal-font">�ռ�������:</span></p>
      <p><span class="normal-font">�����������趨���������, �����ʼ�ʱ���ʼ�����ŵ���ͬ�ļ�����: </span></p>
      
        <p> <span class="normal-font">
        <input type="button" value=" �� �� " language="JavaScript" onClick="window.navigate('rule.php')" CLASS=myinput style='font-family:Tahoma'>
        </span> </p>
    
      <hr size="1">
        <?
        if(file_exists("$G_HOME/Maildir/filter")){
      ($FD_LIST = fopen("$G_HOME/Maildir/filter","r"))||die("Error open file error!");
	$i = 0;
	while(($line = fgets($FD_LIST,1024)) && !feof($FD_LIST) ){
		$filterrule=split(":",$line);
		if($filterrule[0]=='##name')
		{
			$rulename=$filterrule[1];
			for($i=0;$i<8;$i++)
			{
			   $linerule = fgets($FD_LIST,1024);
			   $filterrule=split(":",$linerule);
			   if($filterrule[0]=='##from')
			   {
			     $from=split(",",$filterrule[1]);
			     
                              if($from[0]=='12'){$from1="����";}
			      elseif($from[0]=='13'){$from1="������";}
			      elseif($from[0]=='14'){$from1="��";}
			      elseif($from[0]=='15'){$from1="����";}
			      elseif($from[0]=='16'){$from1="��ʼΪ";}
			      elseif($from[0]=='17'){$from1="����Ϊ";}
			     if($from[1]!='')
			       {
			        $from2=$from[1];
			       }
			     else
			        {
			         $from2='';
			        }
			    }
		           elseif($filterrule[0]=='##rcpt')
		           {
			     $rcpt=split(",",$filterrule[1]);
                             if($rcpt[0]=='12'){$rcpt1="����";}
			     elseif($rcpt[0]=='13'){$rcpt1="������";}
			     elseif($rcpt[0]=='14'){$rcpt1="��";}
			     elseif($rcpt[0]=='15'){$rcpt1="����";}
			     elseif($rcpt[0]=='16'){$rcpt1="��ʼΪ";}
			     elseif($rcpt[0]=='17'){$rcpt1="����Ϊ";}
			     if($rcpt[1]!='')
			       {
			        $rcpt2=$rcpt[1];
			       }
			      else
			        {
			         $rcpt2='';
			        }
			   }
			   elseif($filterrule[0]=='##subj')
			   {
			     $subj=split(",",$filterrule[1]);
                             if($subj[0]=='12'){$subj1="����";}
			     elseif($subj[0]=='13'){$subj1="������";}
			     elseif($subj[0]=='14'){$subj1="��";}
			     elseif($subj[0]=='15'){$subj1="����";}
			     elseif($subj[0]=='16'){$subj1="��ʼΪ";}
			     elseif($subj[0]=='17'){$subj1="����Ϊ";}
			     if($subj[1]!='')
			       {
			        $subj2=$subj[1];
			       }
			       else
			        {
			         $subj2='';
			        }
			   }
			   elseif($filterrule[0]=='##size')
			   {
			     $size=split(",",$filterrule[1]);
                             if($size[0]=='18'){$size1="���ڵ���";}
			     elseif($size[0]=='19'){$size1="С��";}
			     if($size[1]!='')
			       {
			        $size2=$size[1];
			       }
			     else
			        {
			         $size2='';
			        }
			   }
			   elseif($filterrule[0]=='##do')
			   {
			     $do=$filterrule[1];
		           }
		           elseif($filterrule[0]=='##move')
			   {
			     $move=$filterrule[1];
			    
		           }
		           elseif($filterrule[0]=='##reply')
			   {
			     $reply=$filterrule[1];
		           }
		           elseif($filterrule[0]=='##reject')
			   {
			     $reject=$filterrule[1];
		           }
		        }

		   $rulename=trim($rulename);
                   $from1=trim($from1);
                   $from2=trim($from2);
                   $from3=trim($from[0]);
                   $rcpt1=trim($rcpt1);
                   $rcpt2=trim($rcpt2);
                   $rcpt3=trim($rcpt[0]);
                   $subj1=trim($subj1);
                   $subj2=trim($subj2);
                   $subj3=trim($subj[0]);
                   $size1=trim($size1);
                   $size2=trim($size2);
                   $size3=trim($size[0]);
                   $move=trim($move);
                   $reject=trim($reject);
                   $reply=trim($reply);
		   if ($from2!=''){$rule1="�����ߣ�$from1 $from2\n";}
		   else{$rule1='';}
		   if($rcpt2!=''){$rule2="�����ߣ�$rcpt1 $rcpt2\n";}
		   else{$rule2='';}
		   if($subj2!=''){$rule3="���⣺$subj1 $subj2\n";}
		   else{$rule3='';}
		   if($size2!=''){$rule4="�ż� $size1 $size2";}
		   else{$rule4='';}
		   $rule="$rule1\n $rule2\n $rule3\n $rule4";
		
		?>
      <form method="post" action="filter.php" name="">
        <p> <span class="normal-font">���˹�����:<?echo "$rulename";?> <BR>�����<BR>&nbsp;&nbsp;&nbsp;&nbsp;<?echo "$rule";?>  <BR>ִ�У�<BR>&nbsp;&nbsp;<?echo "$do";?><BR></span></p>
        <p> <span class="normal-font"> 
          <input type="hidden" name="filid" value="0">
         
          </span> </p>
        <p>
          <input type="hidden" name="filtername" value="<? echo $rulename;?>">
          <input type="hidden" name="from1" value="<? echo $from1;?>">
          <input type="hidden" name="from2" value="<? echo $from2;?>">
          <input type="hidden" name="from3" value="<? echo $from[0];?>">
          <input type="hidden" name="rcpt1" value="<? echo $rcpt1;?>">
          <input type="hidden" name="rcpt2" value="<? echo $rcpt2;?>">
          <input type="hidden" name="rcpt3" value="<? echo $rcpt[0];?>">
          <input type="hidden" name="subj1" value="<? echo $subj1;?>">
          <input type="hidden" name="subj2" value="<? echo $subj2;?>">
          <input type="hidden" name="subj3" value="<? echo $subj[0];?>">
          <input type="hidden" name="size1" value="<? echo $size1;?>">
          <input type="hidden" name="size2" value="<? echo $size2;?>">
          <input type="hidden" name="size3" value="<? echo $size[0];?>">
          <input type="hidden" name="move" value="<? echo $move;?>">
          <input type="hidden" name="reject" value="<? echo $reject;?>">
          <input type="hidden" name="reply" value="<? echo $reply;?>">
          
          
          <input type="button" value=" �� �� " language="JavaScript" onClick="window.navigate('modifyrule.php?filtername=<?echo "$rulename";?>&from1=<?echo "$from1";?>&from2=<? echo $from2;?>&from3=<? echo $from3;?>&from4=<? echo $from4;?>&rcpt1=<? echo $rcpt1;?>&rcpt2=<? echo $rcpt2;?>&rcpt3=<? echo $rcpt3;?>&rcpt4=<? echo $rcpt4;?>&subj1=<? echo $subj1;?>&subj2=<? echo $subj2;?>&subj3=<? echo $subj3;?>&subj4=<? echo $subj4;?>&size1=<? echo $size1;?>&size2=<? echo $size2;?>&size3=<? echo $size3;?>&move=<? echo $move;?>&reject=<? echo $reject;?>&reply=<? echo $reply;?>')" CLASS=myinput style='font-family:Tahoma'>
          <input type=submit name=delete value=" ɾ �� " CLASS=myinput style='font-family:Tahoma' onclick="if(checkform(del_prompt)) {document.form1.cmd.value='del';return true;} else return false;">
          
          
        </p>
      </form>
      <p>
      <?
 echo" <hr size='1'>";    
}

       }
	fclose($FD_LIST);
}
else{}
	?>
        
        
      </p>
      <form method="post" action="filter.php" name="">
        <table border="0" class="content">
          <tr> 
            <td class="tab03"> 
              <p><span class="normal-font">���շ������б�:</span></p>
              <p>����ĳЩ�����������ʼ��ķ���: ��ֻ�����¿�����������д��Щ�����˵�email��ַ ( ���� 
                someone@nomeans.com ), ע������ַ֮���ö��ŷָ�, Ȼ��㡰���ġ���ȷ�����ɡ��Ժ���Щ�������������ʼ��Ͳ��ٽ����ռ���, 
                ����ֱ���˻ط����˵����䡣</p>
            </td>
          </tr>
        </table>
        <p> 
          <textarea name="refuselist" cols="60" rows="5" CLASS=mytextarea><?echo"$show";?></textarea>
        </p>
        <p> 
          <input type=submit name=update value=" ȷ �� " CLASS=myinput style='font-family:Tahoma'>
         
         
        </p>
      </form>
    </td>
  </tr>
  <tr valign="bottom"> 
    <td align="center" class="copyright"> 
      <hr size="1">
      <script language="JavaScript" src="/copyright.js">
</script>
    </td>
  </tr>
</table>

</body>

</html>

