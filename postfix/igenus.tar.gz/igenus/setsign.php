<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: setsign.php,v 1.4 2003/01/16 08:55:27 wuqiong Exp $
 */

include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

//post
$post_Sign = preg_replace("/\r\n/","\n",trim($HTTP_POST_VARS['Sign']));

//get
$get_Cmd = trim($HTTP_GET_VARS['Cmd']);
$get_Num = trim($HTTP_GET_VARS['Num']);

if($get_Cmd=='Add'){
	($FD_CFG = fopen($CFG_USERSIGN,"a+")) || die("Error open user config file!");
		$line = $post_Sign . "\n# -end- \n";
		fputs($FD_CFG,$line);
	fclose($FD_CFG);
	header("Location: setsign.php");
}

if($get_Cmd=='Delete'){
	$buffer = '';
	($FD_CFG = fopen($CFG_USERSIGN,"r")) || die("Error open user config file!");
	$i=0;
	while(!feof($FD_CFG)){
		$line = trim(fgets($FD_CFG,512));
		if( $line!='# -end-' ){
			$Sign .= $line."\n";
			continue;
		}
		$i++;
		if($i!=$get_Num) $buffer .= $Sign ."\n# -end-\n";
		$Sign = '';
	}
	fclose($FD_CFG);
	($FD_CFG = fopen($CFG_USERSIGN,"w")) || die("Error open user config file!");
		fputs($FD_CFG,$buffer);
	fclose($FD_CFG);
	header("Location: setsign.php");
}

if($get_Cmd=='Modi'){
	$buffer = '';
	$Sign = '';
	($FD_CFG = fopen($CFG_USERSIGN,"r")) || die("Error open user config file!");
	$i=0;
	while(!feof($FD_CFG)){
		$line = trim(fgets($FD_CFG,512));
		if( $line!='# -end-' ){
			$Sign .= $line ."\n";
			continue;
		}

		$i++;
		if($i==$get_Num) $buffer .= $post_Sign ."\n# -end-\n";
		else $buffer .= $Sign ."# -end-\n";
		$Sign = '';
		
	}
	fclose($FD_CFG);
	($FD_CFG = fopen($CFG_USERSIGN,"w+")) || die("Error open user config file!");
		fputs($FD_CFG,$buffer);
	fclose($FD_CFG);
	header("Location: setsign.php");
}

//main
//list accounts
$Sign = '';
$List_Out = '';
if(is_file($CFG_USERSIGN)){
	($FD_CFG = fopen($CFG_USERSIGN,"r")) || die("Error open user config file!");
	$i = 0;
	while(!feof($FD_CFG)){
		$line = trim(fgets($FD_CFG,512));
		if( $line!='# -end-' ){
			$Sign .= $line."\n";
			continue;
		}
		$i++;
		// ȡ��ǰ����
		if($get_Cmd=='ShowModi' && $get_Num==$i){
			$CurSign = $Sign;
		}
		$Sign = preg_replace("/\n/","<BR>\n",$Sign);
		$List_Out .="<TR>\n".
					"<TD ALIGN='CENTER'>$i</TD>\n".
					"<TD>$Sign</TD>\n".
					"<TD ALIGN='CENTER'><A href=# onClick=\"ShowModi('$i');return false\">".
					"<IMG src=images/edit.gif ALT='$LANG_POPSET_EDIT' width=14 height=14 border=0></A></TD>".
					"<TD><A href=# onClick=\"javascript:Delete('$i');return false\">".
					"<IMG src=images/trash.gif border=0 ALT='$LANG_POPSET_DELETE' width=14 height=14></TD>\n".
					"</TR>\n";
		$Sign = '';
	}
	$Total = $i--;
	fclose($FD_CFG);
}
?>
<SCRIPT>
<!--
function Delete(Num){
	if(confirm("<?php echo $LANG_POPSET_CONFIRM_DELETE.$LANG_SIGN;?>" + Num +" ?")){
		document.location = "setsign.php?Cmd=Delete&Num=" + Num;
	}
	return false;
}

function ShowModi(Num){
	document.location = "setsign.php?Cmd=ShowModi&Num=" + Num;
}

function ShowAdd(input,form){
	if(form.TotalNum.value>=5){
		alert("<?php echo $LANG_SIGN_ALERT_5;?>");	
		return false;
	}
	ModiPoP.style.display='none';
	if(AddPoP.style.display=='none') {
		AddPoP.style.display='';
		input.value = "<?php echo $LANG_POPSET_CANCEL;?>";
		return;
	}
	if(AddPoP.style.display==''){
		AddPoP.style.display='none';
		input.value = "<?php echo $LANG_POPSET_ADD;?>";
		return;
	}		
}

function AddSign(form){
	Meg = '';
	if(form.Sign.value=='') Meg += "<?php echo $LANG_SIGN_BODY;?>\n";
	if(Meg==''){
		form.action = "setsign.php?Cmd=Add";
		form.target = "_self";
		form.submit();
		return true;
	}
	alert("<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n\n" + Meg);
	return false;
}

function ModiSign(form){
	Meg = '';
	if(form.Sign.value=='') Meg += "<?php echo $LANG_SIGN_BODY;?>\n";
	if(Meg==''){	
		form.action = "setsign.php?Cmd=Modi&Num=" + form.num.value;
		form.target = "_self";
		form.submit();
		return true;
	}
	alert("<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n\n" + Meg);
	return false;
}
//-->
</SCRIPT>
<HTML>
<HEAD>
<TITLE><?php echo $LANG_SIGN_MANAGE;?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#5A8C52" TEXT="#000000">
<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="100%" ALIGN="CENTER">
  <TR BGCOLOR="#D0E6CE" ALIGN="CENTER"> 
    <TD><B><?php echo $LNAG_LIST_NUM;?></B></TD>
    <TD><B><?php echo $LANG_SIGN_BODY;?></B></TD>
    <TD HEIGHT="22" COLSPAN="2"><B><?php echo $LANG_POPSET_MANAGE;?></B></TD>
  </TR>
  <?php echo $List_Out;?>
</TABLE>
      
<TABLE WIDTH="100%" BORDER="0">
  <TR>
    <TD ALIGN="RIGHT"> 
        <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_ADD;?>" CLASS="myinput2" onClick="ShowAdd(this,document.AddPopMail)">
    </TD>
  </TR>
  <TR ID="AddPoP" STYLE="DISPLAY:none">
  <FORM NAME="AddPopMail" METHOD="post" ACTION="return false;">
      <TD ALIGN="CENTER">
        <TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0">
          <TR> 
            <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_SIGN_BODY;?>:</FONT></B></TD>
            <TD> 
              <TEXTAREA NAME="Sign" CLASS="mytextarea" COLS="45" ROWS="5"></TEXTAREA>
              <B> 
              <INPUT TYPE="HIDDEN" NAME="TotalNum" VALUE="<?php echo $Total;?>">
              </B> </TD>
          </TR>
          <TR> 
            <TD ALIGN="CENTER" HEIGHT="37">&nbsp; </TD>
            <TD HEIGHT="37"> 
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_ADD;?>" CLASS="myinput" onClick="AddSign(this.form)">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_CANCEL;?>" CLASS="myinput">
            </TD>
          </TR>
        </TABLE>
      </TD> 
    </FORM>
  </TR>
  <TR ID="ModiPoP" STYLE="DISPLAY:none">
  <FORM NAME="ModiPopMail" METHOD="post" ACTION="return false;">
      <TD ALIGN="CENTER">
        <TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0">
          <TR ALIGN="CENTER"> 
            <TD COLSPAN="2"><FONT COLOR="#FFFFFF"><B><?php echo $LANG_ADDR_MODIFY.$LANG_SIGN;?></B> <U> 
              <?php echo $get_Num;?>
              </U></FONT></TD>
          </TR>
          <TR> 
            <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_SIGN_BODY;?>:</FONT></B></TD>
            <TD> 
              <TEXTAREA NAME="Sign" CLASS="mytextarea" COLS="45" ROWS="5"><?php echo $CurSign;?></TEXTAREA>
              <B> 
              <INPUT TYPE="HIDDEN" NAME="num" VALUE='<?php echo $get_Num;?>'>
              </B> </TD>
          </TR>
          <TR> 
            <TD ALIGN="CENTER">&nbsp; </TD>
            <TD> 
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_ADDR_MODIFY;?>" CLASS="myinput" onClick="ModiSign(this.form)">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_CANCEL;?>" CLASS="myinput" onClick="ModiPoP.style.display = 'none'">
            </TD>
          </TR>
        </TABLE>
      </TD>
     </FORM>
  </TR>
</TABLE>
</BODY>
<SCRIPT>
self.focus();
</SCRIPT>
<?php
if($get_Cmd=='ShowModi'){
	echo "<script>
ModiPoP.style.display = '';
</script>";
}
?>
</HTML>