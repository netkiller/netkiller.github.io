<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: en_inc.php,v 1.6 2003/01/22 01:26:43 wuqiong Exp $
 */

// in login.php
$LANG_LOGIN_WELCOME = "Welcome to iGENUS webmail";
$LANG_LOGIN_ERROR_USER_NOT_EXIST = "User not exist!";
$LANG_LOGIN_ERROR_PASSWD = "Error password!";

// in menu.php
$LANG_MENU_CHECKIN 	="CheckIn";
$LANG_MENU_SEND		="Send";
$LANG_MENU_MAILBOX	="Mailbox";
$LANG_MENU_ADDBOOK	="Address";
$LANG_MENU_SETUP	="Setup";
$LANG_MENU_HELP		="Help";
$LANG_MENU_LOGOUT	="Logout";

$LANG_MAILBOX_NAME['inbox'] = "Inbox";
$LANG_MAILBOX_NAME['outbox'] = "Sent";
$LANG_MAILBOX_NAME['draft'] = "Draft";
$LANG_MAILBOX_NAME['trash'] = "Trash";

$LANG_ADDBOOK_PUB = "Public";
$LANG_ADDBOOK_PRI = "Private";

$LANG_MENU_SETUP_DEFAULT = "Default";
$LANG_MENU_SETUP_POP	= "POP config";
$LANG_MENU_SETUP_INFO	= "Infomation";
$LANG_MENU_SETUP_PASSWD	= "Password";
$LANG_MENU_SETUP_SIGN	= "Signature";

// in adv.php
$LANG_USERNAME = "UserName";
$LANG_USER_EMAIL = "Address";

// in mailbox.php
$LANG_MAILBOX_QUOTA = "MAILBOX QUOTA";
$LANG_MAILBOX_USED = "USED";
$LANG_MAILBOX_REMAIN = "REMAIN";
$LANG_MAILBOX_SYSTEM = "SYSTEM";
$LANG_MAILBOX_SIZE = "SIZE";
$LANG_MAILBOX_DELETE = "DELETE";
$LANG_MAILBOX_PRIVATE = "PRIVATE";
$LANG_MAILBOX_TOTAL_ALL = "ALL TOTAL";
$LANG_MAILBOX_SELECT = "Select Mailbox";
$LANG_MAILBOX_RENAME = "RenameTo";
$LANG_MAILBOX_CREATE = "New Mailbox";

$LANG_MAILBOX_INVALID_BOXNAME = "Invalid mailbox name !";
$LANG_MAILBOX_CONFIRM_CREATE = "Create mailbox";
$LANG_MAILBOX_CONFIRM_CONTINUE = ",Continue ?";
$LANG_MAILBOX_ALERT_SELECT = "Please select private mailbox !";
$LANG_MAILBOX_ALERT_NEWNAME = "Please input mailbox name !";
$LANG_MAILBOX_CONFIRM_RENAME = "Rename";
$LANG_MAILBOX_CONFIRM_TO = "to";
$LANG_MAILBOX_CONFIRM_CLEAR = "Clear trash, Continue ?";

// in list.php
$LANG_LIST_NEWMAIL	="NEW";
$LANG_LIST_CURRENT_MAILBOX ="MAILBOX";
$LANG_LIST_TOTAL	="TOTAL";
$LANG_LIST_REFRESH	="REFRESH";
$LANG_LIST_PAGE_TOTAL ="TOTAL";
$LANG_LIST_CURRENT_PAGE = "CURRENT";
$LANG_LIST_PAGE		="Page";
$LANG_LIST_PREV		="PREV";
$LANG_LIST_NEXT		="NEXT";
$LNAG_LIST_NUM		="NO.";

$LANG_LIST_SORTBY_FROM	="Sort by from";
$LANG_LIST_SORTBY_SUBJECT	="Sort by subject";
$LANG_LIST_SORTBY_DATE	="Sort by date";
$LANG_LIST_SORTBY_SIZE	="Sort by size";
$LANG_LIST_SORTBY_TO	="Sort by to";

$LANG_LIST_FROM_PREVIEW	="FROM/PREVIEW";
$LANG_LIST_SUBJECT_READ	="SUBJECT/READ";
$LANG_LIST_DATE	="DATE";
$LANG_LIST_SIZE	="SIZE";
$LANG_LIST_TO_CONTINUE	="TO/WRITEAGAIN";
$LANG_LIST_TO_AGAIN	="TO/SENDAGAIN";

$LANG_LIST_CHECKPOP = "CheckIn POP";

$LANG_LIST_SELECTALL ="All/Clear";
$LANG_LIST_SELECT	="Select";
$LANG_LIST_MOVE		="Move";
$LANG_LIST_DELETE	="Delete";
$LANG_LIST_DELETE_FORCE ="Force Delete";

$LANG_LIST_DELETE_ALERT_MSG1 = "Please select mail!";
$LANG_LIST_DELETE_ALERT_MSG2 = "The mail you selected will be send into trash box, continue?";
$LANG_LIST_DELETE_ALERT_MSG3 = "The mail you selected will be deleted, continue?";
$LANG_LIST_MOVE_ALERT_MSG1	= "Please select mail!";
$LANG_LIST_MOVE_ALERT_MSG2	= "Move the mail you selected into ";
$LANG_LIST_MOVE_ALERT_MSG3	= "Please select target!";
$LANG_LIST_SELECT_LANG		= "Langauge";
$LANG_LIST_CHINESE_GB		= "Chinese GB";
$LANG_LIST_CHINESE_BIG		= "Chinese Big";
$LANG_LIST_ENGLISH			= "English";

// in header.php
$LANG_HEADER_FROM = "From:";
$LANG_HEADER_DATE = "Date:";
$LANG_HEADER_SUBJECT = "Subject:";
$LANG_HEADER_REPLY	= " Reply ";
$LANG_HEADER_FORWARD = " Forward ";
$LANG_HEADER_FLAG	= " Flag ";
$LANG_HEADER_SOURCE = "Source";
$LANG_HEADER_BODY	= "Body";
$LANG_HEADER_BODY_LIST	= "List of body";
$LANG_HEADER_ATTACH	= "Attachment";
$LANG_HEADER_PREV	= "Prev";
$LANG_HEADER_NEXT	= "Next";
$LANG_HEADER_ADD_TO_ADDRESS = "Add to Address";

$LANG_HEADER_ALERT_FORWARD_STR1 = "Attachment ?";
$LANG_HEADER_ALERT_PREV_STR1 = "Is first!";
$LANG_HEADER_ALERT_PREV_STR2 = "Previous page,continue ?";
$LANG_HEADER_ALERT_NEXT_STR1 = "Is lasted!";
$LANG_HEADER_ALERT_NEXT_STR2 = "Next page,continue ?";
$LANG_HEADER_ALERT_SOURCEHEADONLY = "Just mail header ?";

$LANG_HEADER_WRITEAGAIN = "WriteAgain";
$LANG_HEADER_SENDAGAIN = "SendAgain";
$LANG_HEADER_NOATTACH = "No Attachment";

// in send_form_inc.php
$LANG_SENDFORM_TO = "SendTo ";
$LANG_SENDFORM_CC = "Cc     ";
$LANG_SENDFORM_BCC = "Bcc    ";
$LANG_SENDFORM_REPLYTO = "ReplyTo";
$LANG_SENDFORM_SUBJECT = "Subject";
$LANG_SENDFORM_PRIORITY = "Priority";
$LANG_SENDFORM_PRIORITY_VALUE[1] = "1";
$LANG_SENDFORM_PRIORITY_VALUE[3] = "3";
$LANG_SENDFORM_PRIORITY_VALUE[5] = "5";
$LANG_SENDFORM_BODY = "Message Body";
$LANG_SENDFORM_BACKUP = "Backup to outbox after send";
$LANG_SENDFORM_USE_SIGN = "Use sign";
$LANG_SENDFORM_SEND = "Send";
$LANG_SENDFORM_SAVE = "Save as draft";
$LANG_SENDFORM_RESET = "Reset";
$LANG_SENDFORM_ATTACH = "Attachment";
$LANG_SENDFORM_ATTACH_MESG = "file must < 1MB";
$LANG_SENDFORM_ADD = "Upload";

$LANG_SENDFORM_SEND_ALERT_STR1 = $LANG_SENDFORM_TO;
$LANG_SENDFORM_SEND_ALERT_STR2 = $LANG_SENDFORM_SUBJECT;
$LANG_SENDFORM_SEND_ALERT_STR3 = $LANG_SENDFORM_BODY;
$LANG_SENDFORM_SEND_ALERT_STR4 = "Please fill below:";

$LANG_SENDFORM_ADD_ALERT_STR1 = "Please select file !";
$LANG_SENDFORM_FILE_EXIST = "already existed!";
$LANG_SENDFORM_FILE_DEL_CONFIRM = "Delete attachment file ";

$LANG_SENDFORM_SIGN = "Sign";
$LANG_SENDFORM_SAVETODRAFT = "Save as draft,Continue ?";

// sendok.php
$LANG_SENDOK_OK = "Mail send ok!";
$LANG_DRAFTOK_OK = "Mail had save into draft!";
$LANG_SENDOK_BACK = "Back to Mailbox list.";

$LANG_ATTACH_DELETE = "Delete";
$LANG_ATTACH_LIST = "Attachment list:";

$LANG_REPLY_HELLO1 = "Hi! ";
$LANG_REPLY_HELLO2 = ",";
$LANG_REPLY_AT		= "In ";
$LANG_REPLY_YOUSAID = "you said:";

// in default.php
$LANG_DEFAULT = "Configuration";
$LANG_DEFAULT_LANGUAGE = "Language";
$LANG_DEFAULT_GMT = "GMT zone";
$LANG_DEFAULT_LIST = "Mailbox listing";
$LANG_DEFAULT_LIST_NUM = "Num./Page";
$LANG_DEFAULT_LIST_AUTOREFRESH = "Auto refresh";
$LANG_DEFAULT_LIST_AUTOPOP = "Auto checkin POP mail when refresh";
$LANG_DEFAULT_LIST_DATE = "Mail date";
$LANG_DEFAULT_LIST_ARRIVED_DATE = "Arrived Time";
$LANG_DEFAULT_LIST_WRITE_DATE = "Writed Time";
$LANG_DEFAULT_LIST_SORT = "Sort by";
$LANG_DEFAULT_LIST_FROMTO = "FROM/TO";
$LANG_DEFAULT_CLOSE = "Close";
$LANG_DEFAULT_ALL = "All";
$LANG_DEFAULT_MINUTE = "Minute";
$LANG_DEFAULT_SEC = "Sec.";
$LANG_DEFAULT_NOREFRESH = "No Refresh";

$LANG_DEFAULT_READ_PREV = "Read & Preview";
$LANG_DEFAULT_READ = "Alternative";
$LANG_DEFAULT_HTML = "HTML";
$LANG_DEFAULT_TEXT = "Plain text";
$LANG_DEFAULT_AUTO_READED = "taged by isread after read";

$LANG_DEFAULT_SEND = "Sendmail/Reply/Forward";
$LANG_DEFAULT_SEND_TYPE = "Format";
$LANG_DEFAULT_SEND_CODE = "Coding by";
$LANG_DEFAULT_SEND_LANG = "Charset";
$LANG_DEFAULT_SEND_NOCODE = "None";

$LANG_DEFAULT_POP = "Remote POP3 mailbox manager";
$LANG_DEFAULT_POP_NUM = "Maximum per. POP account";
$LANG_DEFAULT_POP_TIMEOUT = "Timeout";
$LANG_DEFAULT_DEFAULT = "Reset To Default";
$LANG_DEFAULT_OK = "OK";
$LANG_DEFAULT_MESG_OK = "Modify ?";
$LANG_DEFAULT_MESG_DEFAULT = "All configuration reset to default,continue ?";

// in popmail.php
$LANG_POP_CHECKING = "Checking...";

// in setpopmail.php
$LANG_POPSET_ENABLE = "Enable";
$LANG_POPSET_SERVER_PORT = "POP3 Server/Port";
$LANG_POPSET_ACCOUNT = "Account";
$LANG_POPSET_BUCKUP = "Backup";
$LANG_POPSET_MANAGE = "Manager";
$LANG_POPSET_ADD = "Add";
$LANG_POPSET_SERVER = "Server";
$LANG_POPSET_PORT = "Port";
$LANG_POPSET_ACCOUNT = "Account";
$LANG_POPSET_PASSWD = "Password";
$LANG_POPSET_BUCKUP_2 = "Backup in server";
$LANG_POPSET_BE_ENABLE = "Enable";
$LANG_POPSET_CHECK_ACCOUNT = "Checking Account";
$LANG_POPSET_NEXT_ADD = "Next,add...";
$LANG_POPSET_NEXT_MODI = "Next,modify...";
$LANG_POPSET_CANCEL = "Cancel";
$LANG_POPSET_5 = "Only 5 account of POP server at most!";
$LANG_POPSET_EDIT = "Edit";
$LANG_POPSET_DELETE = "Delete";
$LANG_POPSET_CONFIRM_DELETE = "Is delete ";
$LANG_POPSET_SERVER_CONNECT_FAIL = "Fail of connect to server!";
$LANG_POPSET_SERVER_CONNECT_OK = "Connect to server ok!";
$LANG_POPSET_ACCOUNT_FAIL = "Error of account or password";
$LANG_POPSET_ACCOUNT_OK = "Account is pass!";

// in passwd.php
$LANG_PASSWD = "Change password";
$LANG_PASSWD_OLD = "Old password";
$LANG_PASSWD_NEW = "New password";
$LANG_PASSWD_NEW_CONFIRM = "Confirm new password";
$LANG_PASSWD_SIZE = "length of password must >= 6";
$LANG_PASSWD_OK = "Change passwd ok";
$LANG_PASSWD_ERROR_PARAMETER = "Error parameter!";
$LANG_PASSWD_ERROR_BAD_OLD = "Bad old password!";
$LANG_PASSWD_ERROR_SYSTEM_FAIL = "Fail of change password!";

// in add2addr.php
$LANG_ADDR_PRI_MANAGE = "Personal Address Book manager";
$LANG_ADDR_CONFIRM_DELETE = "Are you confirm delete ";
$LANG_ADDR_CONFIRM_DELETE_EMAIL = "Email";
$LANG_ADDR_NAME = "Nickname";
$LANG_ADDR_EMAIL = "Email";
$LANG_ADDR_MODIFY_FAIL = "Invalid modify";
$LANG_ADDR_PRI = "Personal Address Book";
$LANG_ADDR_MODIFY_LINK = "Modify person";
$LANG_ADDR_MODIFY = "Modify";
$LANG_ADDR_ADD_LINK = "New";

// in address.php
$LANG_ADDR_PUBLIC = "Public Address book";
$LANG_ADDR_CC = "CC";
$LANG_ADDR_BCC = "BCC";
$LANG_ADDR_DEPARTMENT = "Department/UNIT";

// in setsign.php
$LANG_SIGN_ALERT_5 = "Only 5 account of signature at most!";
$LANG_SIGN_BODY = "Signature";
$LANG_SIGN_MANAGE = "Sign manager";
$LANG_SIGN = "Sign";

// in logout.php
$LANG_LOGOUT_LOGIN_AGAIN = "Login again";
?>