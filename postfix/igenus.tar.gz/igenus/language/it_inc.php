<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author for this page: Herakletos <herakletos@hotmail.com>
 *
 * $Id: it_inc.php,v 1.1 2002/11/20 08:06:49 wuqiong Exp $
 */

// in login.php
$LANG_LOGIN_WELCOME = "Benvenuto su iGENUS webmail";
$LANG_LOGIN_ERROR_USER_NOT_EXIST = "L'utente non esiste";
$LANG_LOGIN_ERROR_PASSWD = "Password Errata";

// in menu.php
$LANG_MENU_CHECKIN 	="Controllo";
$LANG_MENU_SEND		="Scrivi";
$LANG_MENU_MAILBOX	="Cartelle";
$LANG_MENU_ADDBOOK	="Rubrica";
$LANG_MENU_SETUP	="Setup";
$LANG_MENU_HELP		="Help";
$LANG_MENU_LOGOUT	="Logout";

$LANG_MAILBOX_NAME['inbox'] = "In Arrivo";
$LANG_MAILBOX_NAME['outbox'] = "In Uscita";
$LANG_MAILBOX_NAME['draft'] = "Bozze";
$LANG_MAILBOX_NAME['trash'] = "Cestino";

// in list.php
$LANG_LIST_NEWMAIL	="nuovi:";
$LANG_LIST_CURRENT_MAILBOX ="Cartelle:";
$LANG_LIST_TOTAL	="Totale:";
$LANG_LIST_REFRESH	="Aggiorna";
$LANG_LIST_PAGE_TOTAL   ="Totale:";
$LANG_LIST_PAGE		="Pagine";
$LANG_LIST_CURRENT_PAGE ="Pagina Corrente:";
$LANG_LIST_PREV		="Prec.";
$LANG_LIST_NEXT		="Succ.";
$LNAG_LIST_NUM		="No.";

$LANG_LIST_SORTBY_FROM	="Ordina per Da:";
$LANG_LIST_SORTBY_SUBJECT	="Ordina per Oggetto";
$LANG_LIST_SORTBY_DATE	="Ordina per Data";
$LANG_LIST_SORTBY_SIZE	="Ordina per Dim.";

$LANG_LIST_FROM_PREVIEW	="Da/A";
$LANG_LIST_SUBJECT_READ	="Oggetto";
$LANG_LIST_DATE	="Data";
$LANG_LIST_SIZE	="Dim.";

$LANG_LIST_SELECTALL ="Selez. Tutto/Deselez.";
$LANG_LIST_SELECT	="Seleziona";
$LANG_LIST_MOVE		="Sposta";
$LANG_LIST_DELETE	="Cancella";
$LANG_LIST_DELETE_FORCE ="Cancella Tutto";

$LANG_LIST_DELETE_ALERT_MSG1 = "Scegli la Mail!";
$LANG_LIST_DELETE_ALERT_MSG2 = "La mail che hai selezionato verr� spostata nel cestino, Continuo?";
$LANG_LIST_DELETE_ALERT_MSG3 = "La mail che hai selezionato verra cancellata, Continuo?";
$LANG_LIST_MOVE_ALERT_MSG1	= "Seleziona la mail!";
$LANG_LIST_MOVE_ALERT_MSG2	= "Sposta la mail in ";
$LANG_LIST_MOVE_ALERT_MSG3	= "Seleziona";
$LANG_LIST_SELECT_LANG		= "Linguaggio";
// in header.php
$LANG_HEADER_FROM = "Da:";
$LANG_HEADER_DATE = "Data:";
$LANG_HEADER_SUBJECT = "Oggetto:";
$LANG_HEADER_REPLY	= " Rispondi ";
$LANG_HEADER_FORWARD = " Inoltra ";
$LANG_HEADER_FLAG	= " Flag ";
$LANG_HEADER_SOURCE = "Source";
$LANG_HEADER_BODY	= "Messaggio";
$LANG_HEADER_ATTACH	= "Allegato";
$LANG_HEADER_PREV	= "Prec.";
$LANG_HEADER_NEXT	= "Succ.";
$LANG_HEADER_ADD_TO_ADDRESS = "Aggiungi a Rubrica";

$LANG_HEADER_ALERT_FORWARD_STR1 = "Allego il file?";
$LANG_HEADER_ALERT_PREV_STR1 = "� la prima!";
$LANG_HEADER_ALERT_PREV_STR2 = "Pagina precedente, Continuo?";
$LANG_HEADER_ALERT_NEXT_STR1 = "� l'ultima!";
$LANG_HEADER_ALERT_NEXT_STR2 = "Pagina successiva, Continuo?";

// in send_form_inc.php
$LANG_SENDFORM_TO = "A: ";
$LANG_SENDFORM_CC = "Cc:     ";
$LANG_SENDFORM_BCC = "Bcc:    ";
$LANG_SENDFORM_REPLYTO = "Rispondi A:";
$LANG_SENDFORM_SUBJECT = "Oggetto:";
$LANG_SENDFORM_PRIORITY = "Priorit�";
$LANG_SENDFORM_PRIORITY_VALUE[1] = "Alta";
$LANG_SENDFORM_PRIORITY_VALUE[3] = "Normale";
$LANG_SENDFORM_PRIORITY_VALUE[5] = "Bassa";
$LANG_SENDFORM_BODY = "Messaggio:";
$LANG_SENDFORM_BACKUP = "Salva in uscita";
$LANG_SENDFORM_USE_SIGN = "Usa La Firma";
$LANG_SENDFORM_SEND = "Invia";
$LANG_SENDFORM_SAVE = "Salva Bozza";
$LANG_SENDFORM_RESET = "Cancella";
$LANG_SENDFORM_ATTACH = "Allega File";
$LANG_SENDFORM_ATTACH_MESG = "Il File deve essere < 1MB";
$LANG_SENDFORM_ADD = "Aggiungi";

$LANG_SENDFORM_SEND_ALERT_STR1 = $LANG_SENDFORM_TO;
$LANG_SENDFORM_SEND_ALERT_STR2 = $LANG_SENDFORM_SUBJECT;
$LANG_SENDFORM_SEND_ALERT_STR3 = $LANG_SENDFORM_BODY;
$LANG_SENDFORM_SEND_ALERT_STR4 = "Controlla i campi:";

$LANG_SENDFORM_ADD_ALERT_STR1 = "Selezione un file!";
$LANG_SENDFORM_FILE_EXIST = "Esiste gi�!";
$LANG_SENDFORM_FILE_DEL_CONFIRM = "File allegato cancellato ";

// sendok.php
$LANG_SENDOK_OK = "Mail inviata corretamente";

$LANG_ATTACH_DELETE = "Cancella";
$LANG_ATTACH_LIST = "Lista Allegati:";

$LANG_REPLY_HELLO1 = "Ciao! ";
$LANG_REPLY_HELLO2 = ",";
$LANG_REPLY_AT		= "In ";
$LANG_REPLY_YOUSAID = "Hai spedito:";

// in logout.php
$LANG_LOGOUT_LOGIN_AGAIN = "Ripeti il login";
?>
