<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2002 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 * Tranlator: janio Cheung <janio_cheung@uol.com.br>
 *
 * $Id: br_inc.php,v 1.2 2002/09/05 08:11:08 wuqiong Exp $
 */

// in login.php
$LANG_LOGIN_WELCOME = "Bem vindo ao iGENUS webmail";
$LANG_LOGIN_ERROR_USER_NOT_EXIST = "Usu�rio inexistente!";
$LANG_LOGIN_ERROR_PASSWD = "Senha incorreta!";

// in menu.php
$LANG_MENU_CHECKIN 	="Chegou e-mail?";
$LANG_MENU_SEND		="Escrever";
$LANG_MENU_MAILBOX	="Pastas";
$LANG_MENU_ADDBOOK	="Address";
$LANG_MENU_SETUP	="Configurar";
$LANG_MENU_HELP		="Ajuda";
$LANG_MENU_LOGOUT	="Sair";

$LANG_MAILBOX_NAME['inbox'] = "Entrada";
$LANG_MAILBOX_NAME['outbox'] = "Enviadas";
$LANG_MAILBOX_NAME['draft'] = "Rascunhos";
$LANG_MAILBOX_NAME['trash'] = "Lixeira";

// in list.php
$LANG_LIST_NEWMAIL	="Novo:";
$LANG_LIST_CURRENT_MAILBOX ="Pasta:";
$LANG_LIST_TOTAL	="Total:";
$LANG_LIST_REFRESH	="Atualizar";
$LANG_LIST_PAGE_TOTAL ="Total:";
$LANG_LIST_PAGE		="p�gina";
$LANG_LIST_CURRENT_PAGE = "Atual:";
$LANG_LIST_PREV		="Anterior";
$LANG_LIST_NEXT		="Pr�ximo";
$LNAG_LIST_NUM		="NO.";

$LANG_LIST_SORTBY_FROM	="Clasificar por autor";
$LANG_LIST_SORTBY_SUBJECT	="Clasificar por assunto";
$LANG_LIST_SORTBY_DATE	="Clasificar por data";
$LANG_LIST_SORTBY_SIZE	="Clasificar por Tamanho";

$LANG_LIST_FROM_PREVIEW	="De";
$LANG_LIST_SUBJECT_READ	="Assunto";
$LANG_LIST_DATE	="Data";
$LANG_LIST_SIZE	="Tam";

$LANG_LIST_SELECTALL ="Selecionar todas";
$LANG_LIST_SELECT	="Selecione";
$LANG_LIST_MOVE		="Mover";
$LANG_LIST_DELETE	="Apagar";
$LANG_LIST_DELETE_FORCE ="For�ar remo��o";

$LANG_LIST_DELETE_ALERT_MSG1 = "Por favor selecione um Email!";
$LANG_LIST_DELETE_ALERT_MSG2 = "O Email selecionado sera enviado para lixeira, deseja continuar?";
$LANG_LIST_DELETE_ALERT_MSG3 = "O Email selecionado sera apagado, deseja continuar?";
$LANG_LIST_MOVE_ALERT_MSG1	= "Por favor selecione um Email!";
$LANG_LIST_MOVE_ALERT_MSG2	= "Mover o email selecionado para ";
$LANG_LIST_MOVE_ALERT_MSG3	= "Por favor selecione o destino!";
$LANG_LIST_SELECT_LANG		= "Idioma";
// in header.php
$LANG_HEADER_FROM = "De:";
$LANG_HEADER_DATE = "Data:";
$LANG_HEADER_SUBJECT = "Assunto:";
$LANG_HEADER_REPLY	= " Responder ";
$LANG_HEADER_FORWARD = " Encaminhar ";
$LANG_HEADER_FLAG	= " Flag ";
$LANG_HEADER_SOURCE = "Fonte";
$LANG_HEADER_BODY	= "Normal";
$LANG_HEADER_ATTACH	= "Arquivo anexo";
$LANG_HEADER_PREV	= "Anterior";
$LANG_HEADER_NEXT	= "Pr�ximo";
$LANG_HEADER_ADD_TO_ADDRESS = "Add endere�o";

$LANG_HEADER_ALERT_FORWARD_STR1 = "Como anexo?";
$LANG_HEADER_ALERT_PREV_STR1 = "� o primeiro!";
$LANG_HEADER_ALERT_PREV_STR2 = "P�gina anterior, continua?";
$LANG_HEADER_ALERT_NEXT_STR1 = "� o �ltimo!";
$LANG_HEADER_ALERT_NEXT_STR2 = "Pr�xima p�gina, continua?";

// in send_form_inc.php
$LANG_SENDFORM_TO = "Para: ";
$LANG_SENDFORM_CC = "Cc:     ";
$LANG_SENDFORM_BCC = "Bcc:    ";
$LANG_SENDFORM_REPLYTO = "Responder para:";
$LANG_SENDFORM_SUBJECT = "Assunto:";
$LANG_SENDFORM_PRIORITY = "Prioridade";
$LANG_SENDFORM_PRIORITY_VALUE[1] = "1";
$LANG_SENDFORM_PRIORITY_VALUE[3] = "3";
$LANG_SENDFORM_PRIORITY_VALUE[5] = "5";
$LANG_SENDFORM_BODY = "Mensagem:";
$LANG_SENDFORM_BACKUP = "Salvar c�pia da mensagem na pasta Enviadas";
$LANG_SENDFORM_USE_SIGN = "Use sign";
$LANG_SENDFORM_SEND = "Enviar";
$LANG_SENDFORM_SAVE = "Salvar na pasta Rascunhos";
$LANG_SENDFORM_RESET = " Limpar ";
$LANG_SENDFORM_ATTACH = " Anexar ";
$LANG_SENDFORM_ATTACH_MESG = "Tamanho m�ximo < 1MB";
$LANG_SENDFORM_ADD = " Incluir ";

$LANG_SENDFORM_SEND_ALERT_STR1 = $LANG_SENDFORM_TO;
$LANG_SENDFORM_SEND_ALERT_STR2 = $LANG_SENDFORM_SUBJECT;
$LANG_SENDFORM_SEND_ALERT_STR3 = $LANG_SENDFORM_BODY;
$LANG_SENDFORM_SEND_ALERT_STR4 = "Aten��o: campo vazio";

$LANG_SENDFORM_ADD_ALERT_STR1 = "Por favor selecione um arquivo!";
$LANG_SENDFORM_FILE_EXIST = "j� existe!";
$LANG_SENDFORM_FILE_DEL_CONFIRM = "Apagar arquivo anexado ";

// sendok.php
$LANG_SENDOK_OK = "Email Enviado!";

$LANG_ATTACH_DELETE = "Apagar";
$LANG_ATTACH_LIST = "Arquivos anexos:";

$LANG_REPLY_HELLO1 = "Ol�! ";
$LANG_REPLY_HELLO2 = ",";
$LANG_REPLY_AT		= "Em ";
$LANG_REPLY_YOUSAID = "voc� escreveu:";

// in logout.php
$LANG_LOGOUT_LOGIN_AGAIN = "Entrar novamente";
?>
