<?php

/*Id*/

include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";


// get
$get_page = $HTTP_GET_VARS['page'];
$get_keyword = $HTTP_POST_VARS['keyword'];
$get_sortby = $HTTP_GET_VARS['sortby'];
$get_direct = $HTTP_GET_VARS['direct'];
$get_Cmd = $HTTP_GET_VARS['Cmd'];
$get_id = $HTTP_GET_VARS['id'];

//post
$post_Name = $HTTP_POST_VARS['Name'];
$post_http = $HTTP_POST_VARS['http'];
$post_memo = $HTTP_POST_VARS['memo'];
$post_Name2 = $HTTP_POST_VARS['Name2'];
$post_http2 = $HTTP_POST_VARS['http2'];
$post_memo2 = $HTTP_POST_VARS['memo2'];
$post_Name3 = $HTTP_POST_VARS['Name3'];
$post_http3 = $HTTP_POST_VARS['http3'];
$post_memo3 = $HTTP_POST_VARS['memo3'];
$post_sr = $HTTP_POST_VARS['sr'];
$post_sl = $HTTP_POST_VARS['sl'];

SWITCH($sr){
	case "1":
		$cha='Name';
		break;
	default:
		$cha='http';
	break;
}

// ���� page 
if ($get_page==0) $get_page = 1;

// ����������
$cur_direct = $get_direct;
if($cur_direct=='') $get_direct=='down';
if($get_direct=='up'){
	$sort_direct = 'ASC';
	$get_direct = 'down';
}else{
	$sort_direct = 'DESC';
	$get_direct = 'up';
}

// ��������ؼ���
switch($get_sortby){
	case 'Name':
		$sortby = "ORDER BY name";
		break;
	case 'http':
		$sortby = "ORDER BY url";
		break;
	default:
		$sortby = "ORDER BY id";
}
$sortby = $sortby ." ".$sort_direct." ";

// ÿҳ��ʾ������ 10
$CFG_ADDR_NUMPERPAGE = 7;

$sql = mysql_pconnect($CFG_MYSQL_HOST, $CFG_MYSQL_USER, $CFG_MYSQL_PASS);
mysql_select_db($CFG_MYSQL_DB,$sql);

if($get_Cmd=='Add' && $post_Name!='' && $post_http!=''){
	$query = "SELECT * FROM favorites WHERE email='$G_ID' and name='$post_Name' and url='$post_http'";
	$result = @mysql_query($query,$sql);
	$rows = @mysql_num_rows($result);
	
	if ($rows !=1 && $row <=100){
		$query = "INSERT INTO favorites SET email='$G_ID',name='$post_Name',url='$post_http',memo='$post_memo'";
		$result = @mysql_query($query,$sql);
	}
	header("Location: favorites.php");
}

if($get_Cmd=='Modify' && $post_Name2!='' && $post_http2!='' && $post_Name3!='' && $post_http3!=''){
	$query = "UPDATE favorites SET name='$post_Name2' ,url'$post_http2',memo='$post_memo2'".
		" WHERE email='$G_ID' and name='$post_Name3' and url='$post_http3' and memo='$post_memo3'";
	$result = @mysql_query($query,$sql);
	$rows = @mysql_num_rows($result);
}

if($get_Cmd=='Del' && $get_id!=''){
	$query = "DELETE FROM favorites WHERE id=$get_id and email='$G_ID'";
	$result = @mysql_query($query,$sql);
	header("Location: favorites.php");
}

//��ʾ�б�
$query = "SELECT count(*) as totalnum FROM favorites WHERE email='$G_ID'";
$result = @mysql_query($query,$sql);
$row = mysql_fetch_object($result);
$totalrow = $row->totalnum;
$totalpage = intval($totalrow /$CFG_ADDR_NUMPERPAGE);
if( $totalrow >$totalpage*$CFG_ADDR_NUMPERPAGE ) $totalpage++;
if ($get_page>$totalpage) $get_page = $totalpage;
$start_row = ($get_page - 1)*$CFG_ADDR_NUMPERPAGE;
$prevpage = $get_page - 1;
$nextpage = $get_page + 1;
if($get_page <=1) $prevpage = 1;
if($get_page >=$totalpage) $nextpage = $totalpage;

$query = "SELECT id,name,url,memo FROM favorites WHERE email='$G_ID' $sortby LIMIT $start_row, $CFG_ADDR_NUMPERPAGE";
$result = @mysql_query($query,$sql);
$ListOut = '';
while ($row = mysql_fetch_object($result)) {
    $ListOut .= "<TR height=20>\n\t".
    "<TD title=\"$row->id\" NOWRAP>".
   $row->id."</A></TD>\n".
   "\t<TD title=\"$row->name\" NOWRAP><A href=$row->url target='_blank'>".
	$row->name."</A></TD>\n".
	"\t<TD title=\"$row->url\" NOWRAP><A href=$row->url target='_blank'>".
	$row->url."</A></TD>\n".
	"\t<TD NOWRAP><A onClick=\"Go2Modi('$row->id','$row->name','$row->url','$row->memo')\" href=#Modify>".
	"<IMG src=images/edit.gif ALT='$LANG_POPSET_EDIT' width=14 height=14 border=0></A> ".
	"<A onClick=\"Del('$row->id','$row->name','$row->url');return false;\" href=#>".
	"<IMG src=images/trash.gif border=0 ALT='$LANG_POPSET_DELETE' width=14 height=14></A></TD>\n</TR>\n";
}

// ����page��������
function PageIndex($NumPerPage,$TotalNum,$CurPage,$URL){
	$PrevPage = $CurPage - 1;
	$NextPage = $CurPage + 1;

	$TotalPage = intval($TotalNum /$NumPerPage);
	if( $TotalNum >$TotalPage*$NumPerPage ) $TotalPage++;

	if( $PrevPage>0 ) $Out_Str .= "<A class=header href=?page=$PrevPage&$URL><<$LANG_LIST_PREV</A>";

	if( $NextPage <=$TotalPage ) $Out_Str .= " <A class=header href=?page=$NextPage&$URL>>>$LANG_LIST_NEXT</A>";
	return $Out_Str;
}
include "$CFG_BASEPATH/adv.php";
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�ղؼй���</title>
</head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus1.css" TYPE="TEXT/CSS">
<body bgcolor="#5A8C52" text="#000000">
<SCRIPT LANGUAGE="JavaScript" SRC="script/address.js">
</SCRIPT>
<SCRIPT>
<!--
function Del(id){
	if(confirm("�Ƿ�ɾ�������� ?")){
		document.List.action = "favorites.php?Cmd=Del&id="+id;
		document.List.submit();
	}
	else return false;
}

function Add(form){
	str = '';
	if(form.Name.value=='') str += "����\n";
	if(form.http.value=='http://') str += "��ַ\n";
	if(str!=''){
		str = "����д�����¸���:\n" + str;
		alert(str);
		return false;
	}
	form.action = "favorites.php?Cmd=Add";
	form.submit();
}

function Modify(form,id){
	str = "";
	if(form.Name2.value=='' || form.http2.value==''){
		alert("��Ч���޸�!");
		return false;
	}

	if(form.Name2.value=='') str += "����\n";
	if(form.http2.value=='') str += "��ַ\n";
	if(str!=''){
		str = "����д�����¸���:\n" + str;
		alert(str);
		return false;
	}
	form.action = "favorites.php?Cmd=Modify&id="+id;
	form.submit();
}

function Go2Modi(id,Name,http,memo){
	document.modifyForm.Name2.value = Name;
	document.modifyForm.Name3.value = Name;
	document.modifyForm.http2.value = http;
	document.modifyForm.http3.value = http;
	document.modifyForm.memo2.value = memo;
	document.modifyForm.memo3.value = memo;
	document.modifyForm.id.value = id;

	MMDIV.style.display = '';
	MMDIV2.style.display = 'none';
}

function CloseModi(){
	MMDIV2.style.display = '';
	MMDIV.style.display = 'none';
}
//-->
</SCRIPT>
<BODY BGCOLOR="#DE9C02" TEXT="#000000" LEFTMARGIN="4" TOPMARGIN="4" MARGINWIDTH="2" MARGINHEIGHT="2">
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR> 
    <TD><B><FONT COLOR="#000000">�����ղؼ�</FONT></B> 
    </TD>
    <TD ALIGN="RIGHT"><B> <INPUT TYPE="BUTTON" VALUE="�ر�" CLASS="myinput2" 
      onClick="window.close()"> </TD>
  </TR>
  <TR> 
    <TD colspan="2">
	<form action="#" method="post">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><B><FONT COLOR="#000000">�ؼ���</FONT></B> <INPUT TYPE="text" CLASS="myinput2" name="key"></td>
            <td><B> ��� </B></td>
          <td><select name="sr" CLASS="myinput2">
        <option value="1"> ���� </option>
        <option value="2"> ��ַ </option>
      </select></td>
          <td width="23%"><input type="submit" value="����" name="sl" CLASS="myinput2"></td>
        </tr>
      </table>
	 </form>
	   </TD>
  </TR>
</TABLE>
<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="100%" ALIGN="CENTER">
  <FORM NAME="List" METHOD="post" ACTION="">
    <TR BGCOLOR="#FFCC00" ALIGN="CENTER"> 
      <TD bgcolor="#5A8C52"> <B><A HREF='?sortby=id&page=1&direct=up'> 
        ���</A></B> </TD>
		
      <TD bgcolor="#5A8C52"><strong>����</strong></TD>
      <TD bgcolor="#5A8C52"><B><A HREF='?sortby=http&page=1&direct=up'> ����</A></B> 
      </TD>
      
      <TD bgcolor="#5A8C52"><B>����</B></TD>
    </TR>
    <?php echo $ListOut;?> 
  </FORM>
</TABLE>

<BR>
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR>
    <TD>&nbsp;</TD>
    <TD ALIGN="RIGHT"> 
          </TD>
  </TR>
</TABLE>
<TABLE WIDTH=100%>
  
    <TR ID="MMDIV" STYLE="DISPLAY:none"> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        <FORM NAME="modifyForm" METHOD="post" ACTION="javascript:return false;">
          <TR> 
            <TD><B><FONT COLOR="#FFFFFF"> <A NAME="Modify"></A><font color="#000000">�޸���ַ-&gt;&gt;&gt;</font>��</FONT></B></TD>
            <TD ALIGN="right"><FONT COLOR="#000000">����:</FONT></TD>
            <TD > <INPUT NAME="Name2" TYPE="text" CLASS="myinput2" id="Name2"> <INPUT TYPE="hidden" NAME="Name3"> 
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#000000">��ַ:</FONT></TD>
            <TD> <INPUT NAME="http2" TYPE="text" CLASS="myinput2" id="http2"> <INPUT TYPE="hidden" NAME="http3"> 
              <input name="BUTTON" type="BUTTON" class="myinput" 
              onClick="CloseModi();return false" value="ȡ��"> 
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#000000">��ע:</FONT></TD>
            <TD> <INPUT NAME="memo2" TYPE="text" CLASS="myinput2" id="memo2"> <INPUT TYPE="hidden" NAME="memo3"> 
              <INPUT TYPE="button" VALUE="�޸�" 
              onClick="Modify(this.form);return false" CLASS="myinput"> 
			 <INPUT TYPE=hidden name = id> </TD>
          </TR>
        </FORM>
      </TABLE>
      </TD>
    </TR>
    <TR ID="MMDIV2" STYLE="DISPLAY:">
      <TD>
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        <FORM NAME="addForm" METHOD="post" ACTION="javascript:return false;">
          <TR>
            <TD><B><FONT COLOR="#000000">������ַ-&gt;&gt;&gt;��</FONT></B></TD>
            <TD ALIGN="right"><font color="#000000">����:</font></TD>
            <TD> <input name="Name" type="text" class="myinput2" id="Name" value=''></TD>
          </TR>
          <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#000000">��ַ:</FONT></TD>
            <TD> <INPUT NAME="http" TYPE="text" CLASS="myinput2" id="http" VALUE='http://'> 
            </TD>
          </TR>
          <TR> 
            <TD ALIGN="right">&nbsp;</TD>
            <TD ALIGN="right"><FONT COLOR="#000000">��ע:</FONT></TD>
            <TD> <INPUT NAME="memo" TYPE="text" CLASS="myinput2" id="memo" VALUE=''> 
              <INPUT TYPE="button" VALUE="����" 
              onClick="Add(this.form);return false" CLASS="myinput"> </TD>
          </TR>
        </FORM>
      </TABLE>
      </TD>
    </TR>
</TABLE>
</body>
</html>
