<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: adv.php,v 1.13 2003/01/15 07:10:55 wuqiong Exp $
 */
?>

<HTML>
<HEAD>
<TITLE>iGENUS webmail Logout</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LEFTMARGIN="0" TOPMARGIN="0">
<TABLE WIDTH="100%" HEIGHT="50" cellspacing cellpadding BACKGROUND="images/line-bk.gif">
<FORM NAME="SendFlag" METHOD="post" ACTION="">
  <TR>
    <TD width=20></TD> 
    <TD><FONT color=#FFFFFF><B><?php echo $LANG_USERNAME;?>: </B><?php echo $G_NICKNAME;?>
    <BR><B><?php echo $LANG_USER_EMAIL;?>: </B><FONT STYLE='font-family:Tahoma'><U><?php echo "$G_USERNAME@$G_DOMAIN";?></U></FONT></FONT>
    </TD>
    <TD VALIGN="middle" ALIGN="center">
    <INPUT TYPE="hidden" NAME="flag" VALUE="1">
    </TD>
    <TD VALIGN="middle" ALIGN="center" STYLE='font-family:Tahoma'>
    <A HREF="http://www.igenus.org/" TARGET="_blank"><FONT color=#FFFFFF>What's 
      iGENUS?</FONT></A><BR>
      <A HREF="http://www.igenus.org/webmail/download/" TARGET="_blank"><FONT color=#FFFFFF>Download 
      Now!</FONT></A></TD>
  </TR>
</FORM>
</TABLE>
</BODY>
</HTML>