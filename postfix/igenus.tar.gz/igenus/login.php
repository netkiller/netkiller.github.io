<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: login.php,v 1.21 2003/02/10 08:51:33 wuqiong Exp $
 */

include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

$Cookies_Domain = $HTTP_COOKIE_VARS['LoginDomain'];

/*	$name
 *	$domain
 *	$passwd
 *	$Cmd
 */	

$name 	= $HTTP_POST_VARS['name'];
$domain = $HTTP_POST_VARS['domain'];
$passwd = $HTTP_POST_VARS['passwd'];
$Cmd 	= $HTTP_GET_VARS['Cmd'];

$errorlogin = 0;		//  0 - success
						// -1 - user not exist
						// -2 - password error
						// -3 - domain not exist

if (isset($name) && ($name!="") && isset($passwd) && ($passwd !="") &&
	isset($domain) && ($domain!="") && ($Cmd=="login") ){
		
	session_start();
	session_unset();
/*
echo $name;
echo $domain;
echo $passwd;
echo "<br>";
*/	
//	list($name,$domain) = split("@",$user,2);

	$conn = mysql_pconnect('localhost','postfix','6AJx9Nqv9x8hg')or die("Unable to connect to database");
	mysql_select_db("postfix")or die("Unable to select database");

//	$sql = mysql_pconnect($CFG_MYSQL_HOST, $CFG_MYSQL_USER, $CFG_MYSQL_PASS);
//	mysql_select_db($CFG_MYSQL_DB,$sql);
/*
	if ($CFG_VPOPMAIL_MYSQL_LARGE_SITE){
		$Vpopmail_Domain = ereg_replace("\.","_",$domain);
		#$query = "SELECT pw_id,pw_dir,pw_passwd,pw_name,pw_shell,pw_gecos FROM $Vpopmail_Domain WHERE pw_name='$name'";
	}else{
		$query = "SELECT pw_id,pw_dir,pw_passwd,pw_name,pw_shell,pw_gecos FROM vpopmail WHERE pw_name='$name' and pw_domain='$domain'";
	}
*/	
	$query = "SELECT user,maildir,passwd,name,quota,name FROM postfix_users WHERE user='$name@$domain'";
//	echo $query."<br>";
	$result = @mysql_query($query,$conn);
	$rows = @mysql_num_rows($result);
//	$data = mysql_fetch_array($result);

//	echo $data['maildir'];

	if($rows !=1 ) $errorlogin = -1;		// user not exist!

	if( $errorlogin==0 ){
		$data = mysql_fetch_array($result);
//		echo $data['maildir'];

		$home = $data['maildir'];
		$passwd2 = $data['passwd'];
		$pw_id = $data['user'];
		$pw_shell = $data['quota'];
		$pw_gecos = $data['name'];
		mysql_close($conn);	// Close mysql

		if ($home !="" && ($passwd2 == crypt($passwd,$passwd2))){
			$G_USERNAME = $name;
			$G_HOME = $home;

		switch($MTA){
		    case "postfix" :
		        $G_HOME = $virtual_mailbox_base.$G_HOME;
		        break;
		    case "qmail" :
			$G_HOME = "$home/Maildir/";
    			break;
		}

			$G_DOMAIN = $domain;
			$G_TIME = time();
			$G_LANG = $Lang;
			$G_ID = $pw_id;
			$G_QUOTA = $pw_shell;
			$G_NICKNAME = $pw_gecos;

			session_register(G_ID);
			session_register(G_USERNAME);
			session_register(G_HOME);
			session_register(G_DOMAIN);
			session_register(G_TIME);
			session_register(G_LANG);
			session_register(G_QUOTA);
			session_register(G_NICKNAME);
			
			// ���� cookies_LoginDomain
			setcookie("LoginDomain",$domain,time()+3600*24*365);
			
			// �����û���ʱ�ļ�Ŀ¼
			if ( !is_dir($CFG_TEMP) ){
				@mkdir($CFG_TEMP,$CFG_TEMP_MOD)||
				die("Error create directory $CFG_TEMP,you must make $CFG_TEMP directory manual.Please read the INSTALL file.");
			}
			if ( !is_dir("$CFG_TEMP/$G_DOMAIN") ) { 
				mkdir("$CFG_TEMP/$G_DOMAIN",$CFG_TEMP_MOD)||die("Error create directory $G_DOMAIN");
			}
			if ( !is_dir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME") ) {
				mkdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME",$CFG_TEMP_MOD)||die("Error create directory $G_USERNAME");
			}
			chdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME");

			header("Location: index.php");
			exit();
		}else{
			$errorlogin = -2;
		}
	}
}

switch($errorlogin){
	case 0:
		$mesg = $LANG_LOGIN_WELCOME;
		break;
	case -1:
		$mesg = $LANG_LOGIN_ERROR_USER_NOT_EXIST;
		break;
	case -2:
		$mesg = $LANG_LOGIN_ERROR_PASSWD;
		break;
}

?>
<HTML>
<HEAD>
<TITLE>iGENUS webmail Login</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
<STYLE TYPE="TEXT/CSS">
<!--
body { font-family: Tahoma}
-->
</STYLE>

</HEAD>
<SCRIPT>
<!--
//alert(screen.width + "x" + screen.height);
if(screen.width <800 )
	alert("Your screen");
if(screen.width == 800)
	Resolve = 800;
if(screen.width == 1024)
	Resolve = 1024;

var AlertInput = "������:\n\n";	
function Login(form){
	var mesg = "";
	if(form.name.value == "") mesg += "name\n";
	if(form.passwd.value == "") mesg += "passwd\n";
	if(mesg != ""){
		mesg = AlertInput + mesg;
		alert(mesg);
		return false;
	}

	if (form.language.value !="-") form.Lang.value = form.language.value;
	form.action = "login.php?Cmd=login";
	form.submit();
	
}

function SelectLang(form){
	language = form.language.value;
	if(language == "-") return false;
	form.Lang.value = language;
	form.action = "login.php?Lang=" + language;
	form.submit();
}
//-->
</SCRIPT>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000">
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0" HEIGHT="100%">
  <TR>
    <TD VALIGN="MIDDLE" ALIGN="CENTER">
      <FORM NAME="login" METHOD="post" ACTION="login.php">
        <TABLE WIDTH="324" cellspacing cellpadding>
          <TR> 
            <TD WIDTH="100%"><A HREF="http://www.igenus.org/"><IMG BORDER="0" SRC="images/loginphoto1.gif" WIDTH="324" HEIGHT="56"></A></TD>
          </TR>
          <TR> 
            <TD WIDTH="100%" BACKGROUND="images/loginphotobk.gif" VALIGN="middle" ALIGN="center" HEIGHT="35"> 
              <BR>
              <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="2">
                <TR>
                  <TD ALIGN="RIGHT"><B>E-Mail:</B> </TD>
                  <TD>
                    <INPUT CLASS=myinput2 TYPE="text" NAME="name" value="" SIZE="10" STYLE='font-family:Tahoma'>
                    @ 
                    <INPUT TYPE="text" NAME="domain" value="gomi.com.hk" VALUE="<?php echo $Cookies_Domain;?>" SIZE="19" CLASS="myinput2" STYLE='font-family:Tahoma'>
                  </TD>
                </TR>
                <TR>
                  <TD ALIGN="RIGHT"><B>Passwd:</B> </TD>
                  <TD>
                    <INPUT TYPE="password" NAME="passwd" CLASS=myinput2 SIZE="10" STYLE='font-family:Tahoma'>
                    <INPUT TYPE="SUBMIT" NAME="login" VALUE="-login-" onClick="Login(this.form)" CLASS=myinput2 STYLE='font-family:Tahoma'>
                    <SELECT SIZE="1" NAME="language" CLASS="myinput" onChange="SelectLang(this.form)" STYLE='font-family:Tahoma'>
                      <OPTION VALUE="-">Language</OPTION>
                      <OPTION VALUE="-">--------</OPTION>
                      <OPTION VALUE="gb">Chinese GB</OPTION>
                      <OPTION VALUE="big">Chinese big5</OPTION>
                      <OPTION VALUE="en">English</OPTION>
                    </SELECT>
                    <INPUT TYPE="hidden" NAME="Lang" VALUE="<?php echo $Lang;?>">
                  </TD>
                </TR>
              </TABLE>
              
            </TD>
          </TR>
          <TR>
            <TD WIDTH="100%">
              <TABLE WIDTH="100%" cellspacing cellpadding>
                <TR>
                  <TD WIDTH="50%" VALIGN="bottom" BACKGROUND="images/loginphotomlbk.gif">
                    <TABLE WIDTH="100%" cellspacing cellpadding>
                      <TR>
                        <TD WIDTH="238" BACKGROUND="images/loginphotom1.gif" HEIGHT="82" ALIGN="center"> 
                          <TABLE WIDTH="80%" HEIGHT="85%" cellspacing cellpadding STYLE="border: 1 solid #78B471">
                            <TR>
                              <TD WIDTH="100%" VALIGN="middle" ALIGN="center"> 
                                <?php echo $mesg;?>
                              </TD>
                            </TR>
                          </TABLE>
                        </TD>
                      </TR>
                      <TR> 
                        <TD WIDTH="100%"><IMG BORDER="0" SRC="images/loginphotom2.gif" WIDTH="238" HEIGHT="34"></TD>
                      </TR>
                    </TABLE>
                  </TD>
                  <TD WIDTH="50%" VALIGN="bottom" BACKGROUND="images/loginphotomrbk.gif"> 
                    <TABLE WIDTH="100%" cellspacing cellpadding>
                      <TR> 
                        <TD WIDTH="100%" BACKGROUND="images/loginphotomrbk.gif">&nbsp;</TD>
                      </TR>
                      <TR> 
                        <TD WIDTH="100%"><IMG BORDER="0" SRC="images/loginphotomr.gif" WIDTH="86" HEIGHT="116"></TD>
                      </TR>
                    </TABLE>
                  </TD>
                </TR>
              </TABLE>
            </TD>
          </TR>
        </TABLE>
        <P>&copy; 1999-2001 Copyright by<A HREF="http://www.igenus.org/"><B> iGENUS 
          Org.</B></A></P>
        </FORM>
    </TD>
  </TR>
</TABLE>
</BODY>
</HTML>
