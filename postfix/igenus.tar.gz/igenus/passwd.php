<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: passwd.php,v 1.6 2003/02/11 00:58:22 wuqiong Exp $
 */

include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

// post
$get_Cmd = trim($HTTP_GET_VARS['Cmd']);
$post_OldPasswd = trim($HTTP_POST_VARS['oldpasswd']);
$post_Passwd = trim($HTTP_POST_VARS['passwd']);
$post_Passwd2 = trim($HTTP_POST_VARS['passwd2']);

$Success = 0;
switch($get_Cmd){

case "Change":
	
	if( $post_OldPasswd=='' || $post_Passwd=='' || $post_Passwd2=='' || $post_Passwd!=$post_Passwd2
		|| $G_USERNAME == 'demo'){
		$ErrorMeg = "<?php echo $LANG_PASSWD_ERROR_PARAMETER;?>";
		break;
	}
	
	$sql = mysql_connect($CFG_MYSQL_HOST, $CFG_MYSQL_USER, $CFG_MYSQL_PASS);
	mysql_select_db($CFG_MYSQL_DB,$sql);

	//�˶�ԭ������
	$query = "SELECT pw_name,pw_passwd FROM vpopmail WHERE pw_id='$G_ID'";
	$result = @mysql_query($query,$sql);
	$row = mysql_fetch_object($result);
	if( $row->pw_passwd!=crypt($post_OldPasswd,$row->pw_passwd) ) {
		$ErrorMeg = "<?php echo $LANG_PASSWD_ERROR_BAD_OLD;?>";
		break;
	}
	// ��������
	$NewPasswd = crypt($post_Passwd);
	
	$query = "UPDATE vpopmail SET pw_passwd='$NewPasswd' WHERE pw_id='$G_ID'";
	$result = @mysql_query($query,$sql);	
	if(empty($result)){
		$ErrorMeg = "<?php echo $LANG_PASSWD_ERROR_SYSTEM_FAIL;?>";
		break;
	}
	//�ɹ�
	$Success = 1;
}
?>
<HTML>
<HEAD>
<TITLE><?php echo $LANG_PASSWD;?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#5A8C52" TEXT="#000000" LEFTMARGIN="4" TOPMARGIN="4" MARGINWIDTH="2" MARGINHEIGHT="2">
<?php if($Success==0){?>
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
<TR> 
    <TD><B><FONT COLOR="#FFFFFF"><?php echo $LANG_PASSWD;?>:</FONT></B></TD>
    <TD ALIGN="RIGHT"> <B> </B> 
      <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_DEFAULT_CLOSE;?>" CLASS="myinput2" onClick="window.close()">
</TD>
</TR>
</TABLE>
<SCRIPT>
<!--
function ChangePasswd(form){
	Meg = '';
	if(form.oldpasswd.value=='') Meg += "<?php echo $LANG_PASSWD_OLD;?>\n";
	if(form.passwd.value=='') Meg += "<?php echo $LANG_PASSWD_NEW;?>\n";
	if(form.passwd2.value=='' || form.passwd.value!=form.passwd2.value) 
		Meg += "<?php echo $LANG_PASSWD_NEW_CONFIRM;?>\n";
	if(form.passwd2.value.length<6) Meg += "<?php echo $LANG_PASSWD_SIZE;?>\n";
	
	if(Meg!=''){
		alert("<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>:\n\n" + Meg);
		return false;
	}
	form.Cmd.value = "Change";
	form.action = "passwd.php?Cmd=Change";
	form.submit();
}
//-->
</SCRIPT>
<CENTER>
  <FONT COLOR="#FFFF00"><B> 
  <?php echo $ErrorMeg;?>
  </B></FONT> 
</CENTER>     
<FORM NAME="Passwd" METHOD="post" ACTION="">
  <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="2">
    <TR> 
      <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_PASSWD_OLD;?>:</FONT></B></TD>
      <TD> 
        <INPUT TYPE="PASSWORD" NAME="oldpasswd" CLASS="myinput2">
      </TD>
    </TR>
    <TR> 
      <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_PASSWD_NEW;?>:</FONT></B></TD>
      <TD> 
        <INPUT TYPE="PASSWORD" NAME="passwd" CLASS="myinput2">
      </TD>
    </TR>
    <TR> 
      <TD ALIGN="RIGHT"><B><FONT COLOR="#FFFFFF"><?php echo $LANG_PASSWD_NEW_CONFIRM;?>:</FONT></B></TD>
      <TD> 
        <INPUT TYPE="PASSWORD" NAME="passwd2" CLASS="myinput2">
      </TD>
    </TR>
    <TR> 
      <TD ALIGN="RIGHT">&nbsp;</TD>
      <TD>
      <INPUT TYPE="Hidden" VALUE="" NAME="Cmd">
        <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_POPSET_NEXT_MODI;?>" CLASS="myinput" 
        onClick=ChangePasswd(this.form)>
      </TD>
    </TR>
  </TABLE>
  </FORM>
<?php
}
else{
?>
<DIV ALIGN="CENTER">
  <P>&nbsp;</P>
  <P><B><FONT COLOR="#FFFF00"><?php echo $LANG_PASSWD_OK;?></FONT></B></P>
  <P> 
    <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_DEFAULT_CLOSE;?>" CLASS="myinput2" 
    onClick="window.close()" NAME="BUTTON">
    <?php }?>
  </P>
</DIV>
</BODY>
<script>
self.focus();
</script>
</HTML>