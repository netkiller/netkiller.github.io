<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: writeagain.php,v 1.2 2002/11/21 09:16:31 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
include "include/reply_inc.php";

$listattachfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_attach";
$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";
if(!is_dir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach")) mkdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach",0755);

($FD_LIST_ATTACH = fopen($listattachfile,"w")) || die("Error open $listattachfile!");
if (file_exists($bodylistfile)){
	($FD_BODYLIST = fopen("$bodylistfile","r"))	|| die("Error open body list file");
	$line = fgets($FD_BODYLIST,1024);
	list($FromName,$From,$Subject,$Date,$Size,$Content_Type,$Content_Transfer_Encoding) = split("\t",$line,7);
	while(!feof($FD_BODYLIST)){
		$line = fgets($FD_BODYLIST,1024);
		if(trim($line)=='') break;
		
		list($filename,$type,$size,$disposition,$id,$location) = split("\t",$line,6);
		if(($disposition=='attachment' || ( empty($location) && empty($id)))
		 && file_exists("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$filename") ){
			fputs($FD_LIST_ATTACH,"$filename\t$size\n");
			copy("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$filename","$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach/$filename");	
		}
	}
	fclose($FD_BODYLIST);
}

$get_MailTo = $From;
$Subject = $Subject;

$Body = Format_body("");

include "adv.php";
include "include/send_form_inc.php";
?>
 