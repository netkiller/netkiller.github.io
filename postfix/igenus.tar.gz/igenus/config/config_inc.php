<?php
/*-
 * iGENUS webmail
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: config_inc.php,v 1.20 2003/05/09 03:25:00 solo Exp $
 */

$MTA = "postfix";
//$MTA = "qmail";
// User configure
if($MTA == "postfix") include "postfix.inc.php";


$CFG_BASEPATH = "/var/www/html/igenus";
#$CFG_BASEPATH = "/home/dengxuan/igenus";
#$CFG_BASEPATH = "/home/vhosts2/mail.sczg.com";
#$CFG_BASEPATH = "/home/www/mail.wz110.com/igenus";

// Mysql
$CFG_MYSQL_HOST = 'localhost';
$CFG_MYSQL_USER	= 'postfix';
$CFG_MYSQL_PASS = '6AJx9Nqv9x8hg';
$CFG_MYSQL_DB	= 'postfix';

// vpopmail configure
$CFG_VPOPMAIL_MYSQL_LARGE_SITE = 0;			// defualt is no. please see vpopmail configure help.

// default for Language 
$CFG_LANGUAGE = gb;		// gb 	- Chinese GB
						// big 	- Chinese Big5
						// en 	- English
						// jp	- Japanese
						// fr	- French
						// br   - Portuguese
						
$CFG_GMT = +8;			// GMT time local

$CFG_CHARSET['']	= "gb2312";
$CFG_CHARSET['gb']	= "gb2312";
$CFG_CHARSET['big']	= "big5";
$CFG_CHARSET['en']	= "";		// iso8859-1
$CFG_CHARSET['fr'] = "";
$CFG_CHARSET['br'] = "";
$CFG_CHARSET['it'] = "";


// default for web page Themes
$CFG_THEMES = "generic";

// Temp directory for maildir listing,mail body decodeing etc.
$CFG_TEMP = $CFG_BASEPATH."/tmp";
#$CFG_TEMP = "/tmp";

$CFG_TEMP_MOD = 0755;
$CFG_MAILBOX_MOD = 0700;

$CFG_MAILBOX['inbox'] = ".";
$CFG_MAILBOX['outbox'] = ".Outbox";
$CFG_MAILBOX['draft'] = ".Draft";
$CFG_MAILBOX['trash'] = ".Trash";

// Mailbox
$CFG_BOX_OUT	= '';
$CFG_BOX_TRASH	= '';
$CFG_BOX_DRAFT	= '';

//quota
$CFG_SIZEPERSECTOR = 1024;

// pop3 MailServer configure
$CFG_POP_FILE 		= "$G_HOME/.popconfig";
$CFG_USERBOX_LIST 	= "$G_HOME/.box_list";
$CFG_USERSIGN 		= "$G_HOME/.sign";
$CFG_USERCONFIG		= "$G_HOME/.config";

// User configure
if(is_file($CFG_USERCONFIG)) include "$CFG_USERCONFIG";

$get_Lang = trim($HTTP_GET_VARS['Lang']);
if($G_LANG!='') $CFG_LANGUAGE = $G_LANG;
if($get_Lang!='') $CFG_LANGUAGE = $get_Lang;

//
if($CFG_List_NumPerPage==0) $CFG_List_NumPerPage = 20;
if($CFG_List_AutoRefresh==0) $CFG_List_AutoRefresh = 120;
if( empty($CFG_Prev_Alternative) ) $CFG_Prev_Alternative = 'Html';
if( empty($CFG_Prev_IsRead) ) $CFG_Prev_IsRead = 'yes';
if( empty($CFG_Send_Encoding) ) $CFG_Send_Encoding = 'Base64';
if( empty($CFG_POP_NumPer) ) $CFG_POP_NumPer = 50;
if( empty($CFG_POP_Timeout) ) $CFG_POP_Timeout = 30;

$CFG_HTML_SIGN = "<p class='sign'>iGENUS is a free webmail interface, NO fee, FREE download<BR>\n".
				 "---------------------------------------------------------<BR>\n".
				 "please visit <A href=http://www.igenus.org target=_blank>http://www.igenus.org</A><br>".
				 "iGENUS for postfix <A href=mailto:netkiller@9812.net target=_blank>netkiller@9812.net</A>".
		 "</P>\n";
				 
$CFG_PAIN_SIGN = "iGENUS is a free webmail interface, NO fee, FREE download\n".
				 "---------------------------------------------------------\n".
				 "please visit http://www.igenus.org\n".
				 "iGENUS for postfix netkiller@9812.net\n".
				 "please visit http://linux.9812.net\n";
?>
