<?
/*-
 * iGENUS webmail
 *
 * Copyright (c) 2004-2008 by iGENUS for postfix.
 * All rights reserved.
 * Author: netkiller <netkiller@9812.net>
 *
 */

$virtual_mailbox_base = "/var/mail/";
$auth_sql="";
?>
