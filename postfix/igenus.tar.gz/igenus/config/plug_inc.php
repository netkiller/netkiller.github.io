<?php

/*Id*/

$PlugInc[0] = array (
    "image"  => "images/folder/card.gif",
    "name" => "��Ƭ��",
    "link"   => "A target='main' HREF='plug/card.php'"
);

$PlugInc[1] = array (
    "image"  => "images/folder/card.gif",
    "name" => "�ղؼ�",
    "link"   => "A target='main' HREF=favorites.php"
);

$PlugInc[2] = array (
    "image"  => "images/folder/board.gif",
    "name" => "ͨ����",
    "link"   => "A HREF=javascript:OpenWin2('disboard.php')"
);

$OutPlug = '';
for ($i=0;$i<3;$i++){
$OutPlug .= "<TR>\n";
$OutPlug .= "<TD>\n";
$OutPlug .= "<TABLE WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='0'>\n";
$OutPlug .= "<TR>\n";
$OutPlug .= "<TD WIDTH='38'><IMG SRC='images/folder/node.gif' WIDTH='16' HEIGHT='22'><IMG SRC=".$PlugInc[$i][image]." WIDTH='22' HEIGHT='21'></TD>\n";
$OutPlug .= "<TD><".$PlugInc[$i][link].">".$PlugInc[$i][name]."</A></TD>\n";
$OutPlug .= "</TR>\n";
$OutPlug .= "</TABLE>\n";
$OutPlug .= "</TD>\n";
$OutPlug .= "</TR>\n";
}


?>
