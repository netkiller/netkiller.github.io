<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: menu.php,v 1.22 2003/05/14 02:52:08 solo Exp $
 */
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
include "config/plug_inc.php";

$BOX_LIST = "$G_HOME/.box_list";

$i = 0;
if( is_file("$BOX_LIST") ){
	($FD_BOXLIST = fopen($BOX_LIST,"r")) || die("Error open .box_list!");
	while ( !feof($FD_BOXLIST) ) {
    	$buffer = fgets($FD_BOXLIST, 128);
    	$buffer = chop($buffer);
    	list($foldername,$boxname) = split("\t",$buffer);
       	if( $foldername!='' ){
       		$MailboxList[$i++] = "$foldername\t$boxname";
       	}
	}
	fclose($FD_BOXLIST);
}
if( $MailboxList!='' ){
	$BoxList_Out = "<TR>\n";
	$BoxList_Out .= '<TD><IMG SRC="images/folder/vertline.gif"><IMG SRC="images/folder/node.gif"><IMG SRC="images/folder/trash.gif"></TD>';
	$BoxList_Out .= '<TD><A HREF="list.php?Mailbox=trash&Cmd=Refresh" TARGET="main">'.$LANG_MAILBOX_NAME['trash'].'</A></TD>';
	$BoxList_Out .= '</TR>';
	for( $i=0;$i<count($MailboxList);$i++ ){
		list($foldername,$boxname) = split("\t",$MailboxList[$i]);
		$BoxList_Out .= "<TR>\n";
		$BoxList_Out .= "<TD><IMG SRC='images/folder/vertline.gif'>";
		if($i!=count($MailboxList)-1) $BoxList_Out .= "<IMG SRC='images/folder/node.gif'>";
		else $BoxList_Out .= "<IMG SRC='images/folder/lastnode.gif'>";
		$BoxList_Out .= "<IMG SRC='images/folder/person.gif'></TD>";
		$BoxList_Out .= "<TD><A HREF='list.php?Mailbox=".$boxname."&Cmd=Refresh' TARGET='main'>".$foldername."</A></TD>";
		$BoxList_Out .= "</TR>";
	}
}else {
	$BoxList_Out = "<TR>\n"; 
	$BoxList_Out .= '<TD><IMG SRC="images/folder/vertline.gif"><IMG SRC="images/folder/lastnode.gif"><IMG SRC="images/folder/trash.gif"></TD>';
	$BoxList_Out .= '<TD><A HREF="list.php?Mailbox=trash&Cmd=Refresh" TARGET="main">'.$LANG_MAILBOX_NAME['trash'].'</A></TD>';
	$BoxList_Out .= '</TR>';
}
?>
<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus1.css" TYPE="TEXT/CSS">
</HEAD>
<SCRIPT>
<!--
function CloseOther(List){
	if(List!='Folder'){
		FolderClose.style.display = '';
		FolderOpen.style.display = 'none';
	}	
	if(List!='Addr'){
		AddrClose.style.display = '';
		AddrOpen.style.display = 'none';
	}
	if(List!='Setup'){
		SetupClose.style.display = '';
		SetupOpen.style.display = 'none';
		
	}
}

//Mail Folder
function OpenFolder(){
	FolderOpen.style.display = '';
	FolderClose.style.display = 'none';
	CloseOther('Folder');
	return;
}
function CloseFolder(){
	FolderOpen.style.display = 'none';
	FolderClose.style.display = '';
	return;
}

// AddressBook
function OpenAddr(){
	AddrOpen.style.display = '';
	AddrClose.style.display = 'none';
	CloseOther('Addr');
	return;
}
function CloseAddr(){
	AddrOpen.style.display = 'none';
	AddrClose.style.display = '';
	return;
}

// Setup
function OpenSetup(){
	SetupOpen.style.display = '';
	SetupClose.style.display = 'none';
	CloseOther('Setup');
	return;
}

function CloseSetup(){
	SetupOpen.style.display = 'none';
	SetupClose.style.display = '';
	return;
}

var addrwin;
function OpenWin(URL){
	addrwin = window.open(URL,"CfgWin","width=400,height=300,scrollbars=yes");//
	addrwin.moveTo(200,250);
	return;
}

function OpenWin2(URL){
	addrwin = window.open(URL,"CfgWin","width=400,height=500,scrollbars=yes");//
	addrwin.moveTo(300,150);
	return;
}

function Logout(){
	top.location = 'logout.php';
	if(addrwin) addrwin.close();
}
//-->
</SCRIPT>
<BODY BGCOLOR="#78B471" TEXT="#000000" TOPMARGIN="0" LEFTMARGIN="0">

<A HREF="http://www.igenus.org" TARGET="_blank">
<IMG BORDER="0" SRC="images/mail-logos.gif" WIDTH="130" HEIGHT="120">
</A>
<TABLE>
<FORM NAME="SendFlag" METHOD="post" ACTION="">
<TR><TD>
<INPUT TYPE="hidden" NAME="flag" VALUE="1">
</TD></TR>
</FORM>
</TABLE>
<CENTER>
  <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0">
    <TR> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD><IMG SRC="images/folder/folderopen.gif" WIDTH="22" HEIGHT="20"></TD>
            <TD>iGENUS webmail</TD>
          </TR>
        </TABLE>
      </TD>
    </TR>
    <TR> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/new.gif" WIDTH="22" HEIGHT="21"></TD>
            <TD><A HREF="list.php?Mailbox=inbox&Cmd=Refresh" TARGET="main"><?php echo $LANG_MENU_CHECKIN;?></A></TD>
          </TR>
        </TABLE>
      </TD>
    </TR>
    <TR> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/write.gif" WIDTH="22" HEIGHT="21"></TD>
            <TD><A HREF="send.php" TARGET="main"><?php echo $LANG_MENU_SEND;?></A></TD>
          </TR>
        </TABLE>
      </TD>
    </TR>
    <TR> 
      <TD>
      <DIV ID='FolderClose' STYLE="DISPLAY:none"> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><A HREF="javascript:OpenFolder()"><IMG SRC="images/folder/pnode.gif" WIDTH="16" HEIGHT="22" BORDER="0"><IMG SRC="images/folder/folderclosed.gif" WIDTH="22" HEIGHT="20" BORDER="0"></A></TD>
            <TD><A HREF="mailbox.php" TARGET="main"><?php echo $LANG_MENU_MAILBOX;?></A></TD>
          </TR>
        </TABLE>
     </DIV>
     <DIV ID='FolderOpen' STYLE="DISPLAY:"> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><A HREF="javascript:CloseFolder()"><IMG SRC="images/folder/mnode.gif" WIDTH="16" HEIGHT="22" BORDER="0"><IMG SRC="images/folder/folderopen.gif" WIDTH="22" HEIGHT="20" BORDER="0"></A></TD>
            <TD><A HREF="mailbox.php" TARGET="main"><?php echo $LANG_MENU_MAILBOX;?></A></TD>
          </TR>
        </TABLE>
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="54"><IMG SRC="images/folder/vertline.gif"><IMG SRC="images/folder/node.gif"><IMG SRC="images/folder/inbox.gif" WIDTH="22" HEIGHT="21"></TD>
            <TD><A HREF="list.php?Mailbox=inbox&Cmd=Refresh" TARGET="main"><?php echo $LANG_MAILBOX_NAME['inbox'];?></A></TD>
          </TR>
          <TR> 
            <TD><IMG SRC="images/folder/vertline.gif"><IMG SRC="images/folder/node.gif"><IMG SRC="images/folder/sent.gif" WIDTH="22" HEIGHT="21"></TD>
            <TD><A HREF="list.php?Mailbox=outbox&Cmd=Refresh" TARGET="main"><?php echo $LANG_MAILBOX_NAME['outbox'];?></A></TD>
          </TR>
          <TR> 
            <TD><IMG SRC="images/folder/vertline.gif"><IMG SRC="images/folder/node.gif"><IMG SRC="images/folder/draft.gif" WIDTH="22" HEIGHT="21"></TD>
            <TD><A HREF="list.php?Mailbox=draft&Cmd=Refresh" TARGET="main"><?php echo $LANG_MAILBOX_NAME['draft'];?></A></TD>
          </TR>
          <?php echo $BoxList_Out;?>
        </TABLE>
      </DIV>
      </TD>
    </TR>
    <TR> 
      <TD>
      <DIV ID="AddrClose"> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><A HREF="javascript:OpenAddr()"><IMG SRC="images/folder/pnode.gif" WIDTH="16" HEIGHT="22" BORDER="0"><IMG SRC="images/folder/address.gif" WIDTH="22" HEIGHT="21" BORDER="0"></A></TD>
            <TD><A HREF="javascript:OpenAddr();OpenWin('add2addr.php')"><?php echo $LANG_MENU_ADDBOOK;?></A></TD>
          </TR>
        </TABLE>
      </DIV>
     <DIV ID="AddrOpen" STYLE="DISPLAY:none"> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD COLSPAN="2"> 
              <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
                <TR> 
                  <TD WIDTH="38"><A HREF="javascript:CloseAddr()"><IMG SRC="images/folder/mnode.gif" WIDTH="16" HEIGHT="22" BORDER="0"><IMG SRC="images/folder/address.gif" WIDTH="22" HEIGHT="21" BORDER="0"></A></TD>
                  <TD><A HREF="javascript:OpenWin('add2addr.php')"><?php echo $LANG_MENU_ADDBOOK;?></A></TD>
                </TR>
              </TABLE>
              <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
                <TR> 
                  <TD WIDTH="54"><IMG SRC="images/folder/vertline.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/person.gif" WIDTH="22" HEIGHT="21"></TD>
                  <TD><A HREF="javascript:OpenWin('public_address.php')"><?php echo $LANG_ADDBOOK_PUB;?></A></TD>
                </TR>
                <TR> 
                  <TD><IMG SRC="images/folder/vertline.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/lastnode.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/person.gif" WIDTH="22" HEIGHT="21"></TD>
                  <TD><A HREF="javascript:OpenWin('address.php')"><?php echo $LANG_ADDBOOK_PRI;?></A></TD>
                </TR>
              </TABLE>
            </TD>
          </TR>
        </TABLE>
     </DIV>
    </TR>
    <TR > 
      <TD>
      <DIV ID="SetupClose">
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><A HREF="javascript:OpenSetup()"><IMG SRC="images/folder/pnode.gif" WIDTH="16" HEIGHT="22" BORDER="0"><IMG SRC="images/folder/per_mbox.gif" WIDTH="22" HEIGHT="21"  BORDER="0"></A></TD>
            <TD><A HREF="javascript:OpenSetup()"><?php echo $LANG_MENU_SETUP;?></A></TD>
          </TR>
        </TABLE>
      </DIV>
      <DIV ID="SetupOpen" STYLE="DISPLAY:none">
              <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
                <TR> 
                  <TD WIDTH="38"><A HREF="javascript:CloseSetup()"><IMG SRC="images/folder/mnode.gif" WIDTH="16" HEIGHT="22" BORDER="0"><IMG SRC="images/folder/per_mbox.gif" WIDTH="22" HEIGHT="21" BORDER="0"></A></TD>
                  <TD><A HREF="javascript:CloseSetup()"><?php echo $LANG_MENU_SETUP;?></A></TD>
                </TR>
              </TABLE>
              <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
                <TR> 
                  <TD WIDTH="54"><IMG SRC="images/folder/vertline.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/usrreg.gif" WIDTH="22" HEIGHT="21"></TD>
                  <TD><A HREF="javascript:OpenWin('default.php')"><?php echo $LANG_MENU_SETUP_DEFAULT;?></A></TD>
                </TR>
                <TR> 
                  <TD WIDTH="54"><IMG SRC="images/folder/vertline.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/usrreg.gif" WIDTH="22" HEIGHT="21"></TD>
                  <TD><A HREF="javascript:OpenWin('setpopmail.php')"><?php echo $LANG_MENU_SETUP_POP;?></A></TD>
                </TR>
                <TR> 
                  <TD WIDTH="54"><IMG SRC="images/folder/vertline.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/person.gif" WIDTH="22" HEIGHT="21"></TD>
                  <TD><?php echo $LANG_MENU_SETUP_INFO;?></TD>
                </TR>
                <TR> 
                  <TD><IMG SRC="images/folder/vertline.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/password.gif" WIDTH="22" HEIGHT="21"></TD>
                  <TD><A HREF="javascript:OpenWin('chpasswd.php')"><?php echo $LANG_MENU_SETUP_PASSWD;?></A></TD>
                </TR>
                <TR> 
                  <TD><IMG SRC="images/folder/vertline.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/lastnode.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/admin.gif" WIDTH="22" HEIGHT="21"></TD>
                  <TD><A HREF="javascript:OpenWin('setsign.php')"><?php echo $LANG_MENU_SETUP_SIGN;?></A></TD>
                </TR>
              </TABLE>
      </DIV>  
      </TD>
    </TR>
    <?php echo $OutPlug;?>
    <TR> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><IMG SRC="images/folder/node.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/help.gif" WIDTH="22" HEIGHT="21"></TD>
            <TD><A HREF="#"><?php echo $LANG_MENU_HELP;?></A></TD>
          </TR>
        </TABLE>
      </TD>
    </TR>
    <TR> 
      <TD> 
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD WIDTH="38"><IMG SRC="images/folder/lastnode.gif" WIDTH="16" HEIGHT="22"><IMG SRC="images/folder/logout.gif" WIDTH="22" HEIGHT="21"></TD>
            <TD><A HREF="javascript:Logout()"><?php echo $LANG_MENU_LOGOUT;?></A></TD>
          </TR>
        </TABLE>
      </TD>
    </TR>
  </TABLE>
  <P><FONT SIZE="1">&copy;1999-2002<BR>
    iGENUS Org.</FONT></P>
  <P><FONT SIZE="1">&copy;2004-2008<BR>
    netkiller.</FONT></P>
</CENTER>
</BODY>
</HTML>
