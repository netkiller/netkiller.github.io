<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: send.php,v 1.5 2002/11/29 04:35:01 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
if(is_file($CFG_USERCONFIG)) include "$CFG_USERCONFIG";

//get
$get_MailTo = $HTTP_GET_VARS['to'];
$get_MailCc = $HTTP_GET_VARS['cc'];
$get_MailBcc = $HTTP_GET_VARS['bcc'];

DelAttach();
include "adv.php";
include "include/send_form_inc.php";
?>
