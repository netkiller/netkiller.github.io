<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: reply.php,v 1.5 2002/11/21 09:16:31 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
include "include/reply_inc.php";

$listattachfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_attach";
$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";
if(!is_dir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach")) mkdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach",0755);

DelAttach();

if (file_exists($bodylistfile)){
	($FD_BODYLIST = fopen("$bodylistfile","r"))	|| die("Error open body list file");
	$line = fgets($FD_BODYLIST,1024);
	list($FromName,$From,$Subject,$Date,$Size,$Content_Type,$Content_Transfer_Encoding) = split("\t",$line,7);
	fclose($FD_BODYLIST);
}
$get_MailTo = $From;
$Subject = "Re: ".$Subject;
$Body = "$LANG_REPLY_HELLO1$FromName$LANG_REPLY_HELLO2\n\n\n";
$Body .= "----$LANG_REPLY_AT $Date $LANG_REPLY_YOUSAID----\n\n"; 

$Body = $Body . Format_body("> ");

include "adv.php";
include "include/send_form_inc.php";
?>