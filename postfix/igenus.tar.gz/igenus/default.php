<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: default.php,v 1.6 2003/01/16 03:23:50 wuqiong Exp $
 */

include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

$End = '?>';
$Head = '<?php';
//get
$get_Cmd = trim($HTTP_GET_VARS['Cmd']);

//post
$post_Language 			= trim($HTTP_POST_VARS['Language']);
$post_GMT 			= trim($HTTP_POST_VARS['GMT']);
$post_List_NumPerPage 	= trim($HTTP_POST_VARS['List_NumPerPage']);
$post_List_AutoRefresh 	= trim($HTTP_POST_VARS['List_AutoRefresh']);
$post_List_AutoPOP 		= trim($HTTP_POST_VARS['List_AutoPOP']);
$post_List_MailTime 	= trim($HTTP_POST_VARS['List_MailTime']);
$post_List_SortBy 		= trim($HTTP_POST_VARS['List_SortBy']);
$post_Prev_Alternative 	= trim($HTTP_POST_VARS['Prev_Alternative']);
$post_Prev_IsRead		= trim($HTTP_POST_VARS['Prev_IsRead']);
$post_Send_ContentType	= trim($HTTP_POST_VARS['Send_ContentType']);
$post_Send_Encoding 	= trim($HTTP_POST_VARS['Send_Encoding']);
$post_Send_Charset 		= trim($HTTP_POST_VARS['Send_Charset']);
$post_POP_NumPer			= trim($HTTP_POST_VARS['POP_NumPer']);
$post_POP_Timeout 		= trim($HTTP_POST_VARS['POP_Timeout']);

if($get_Cmd=='Modify'){
	$Config_Out = '';
	( $FD_CONFIG = fopen($CFG_USERCONFIG,'w') ) || die ("Error open user configure file!");

	$Config_Out .= "$Head\n".
	"\$CFG_LANGUAGE		= '$post_Language';\n".
	"\$CFG_GMT		= '$post_GMT';\n".
	"\n".
	"\$CFG_List_NumPerPage	= $post_List_NumPerPage;\n".
	"\$CFG_List_AutoRefresh	= $post_List_AutoRefresh;\n".
	"\$CFG_List_AutoPOP	= '$post_List_AutoPOP';\n".
	"\$CFG_List_MailTime	= '$post_List_MailTime';\n".	
	"\$CFG_List_SortBy	= '$post_List_SortBy';\n".
	"\n".
	"\$CFG_Prev_Alternative	= '$post_Prev_Alternative';\n".
	"\$CFG_Prev_IsRead	= '$post_Prev_IsRead';\n".
	"\n".
	"\$CFG_Send_ContentType	= '$post_Send_ContentType';\n".
	"\$CFG_Send_Encoding	= '$post_Send_Encoding';\n".
	"\$CFG_Send_Charset	= '$post_Send_Charset';\n".
	"\n".
	"\$CFG_POP_NumPer		= $post_POP_NumPer;\n".
	"\$CFG_POP_Timeout	= $post_POP_Timeout;\n".
	"$End\n";

	fputs($FD_CONFIG,$Config_Out);
	fclose($FD_CONFIG);
	header("Location: default.php");
}

if($get_Cmd=='Default'){
	$Config_Out = '';
	( $FD_CONFIG = fopen($CFG_USERCONFIG,'w') ) || die ("Error open user configure file!");
	fputs($FD_CONFIG,$Config_Out);
	fclose($FD_CONFIG);
	header("Location: default.php");
}

function Selected($Vars,$Cur,$Default){
	if(empty($Vars) && $Cur==$Default) echo "Selected";
	else if($Vars==$Cur) echo "Selected";
	
}

function Checked($Vars,$Cur,$Default){
	if($Vars==$Cur) echo "Checked";
	else if($Vars=='' && $Cur==$Default) echo "Checked";	
}
?>
<HTML>
<HEAD>
<TITLE><?php echo $LANG_DEFAULT;?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#5A8C52" TEXT="#000000" LEFTMARGIN="4" TOPMARGIN="4" MARGINWIDTH="2" MARGINHEIGHT="2">
<CENTER>
  <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
    <TR> 
      <TD><B><FONT COLOR="#FFFFFF"><?php echo $LANG_DEFAULT;?>:</FONT></B></TD>
      <TD ALIGN="RIGHT"> <B> </B> 
        <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_DEFAULT_CLOSE;?>" CLASS="myinput2" onClick="window.close()">
      </TD>
    </TR>
  </TABLE>
  <BR>
</CENTER>
<FORM NAME="form1" METHOD="post" ACTION="" onSubmit="return false;">
  <CENTER>
    <TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="95%" ALIGN="CENTER">
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_LANGUAGE;?>:</B></TD>
        <TD> 
          <SELECT NAME="Language">
            <OPTION VALUE="gb" <?php Selected($CFG_LANGUAGE,gb,gb);?>><?php echo $LANG_LIST_CHINESE_GB;?> Chinese 
            simplified *</OPTION>
            <OPTION VALUE="big" <?php Selected($CFG_LANGUAGE,big,gb);?>><?php echo $LANG_LIST_CHINESE_BIG;?> Chinese 
            traditional</OPTION>
            <OPTION VALUE="en" <?php Selected($CFG_LANGUAGE,en,gb);?>><?php echo $LANG_LIST_ENGLISH;?>    English</OPTION>
          </SELECT>
        </TD>
      </TR>
      <TR BGCOLOR="#D0E6CE">
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_GMT;?>:</B></TD>
        <TD>
          <SELECT NAME="GMT">
          <OPTION VALUE="13">GMT+13:00</OPTION>
          <OPTION VALUE="12">GMT+12:00</OPTION>
          <OPTION VALUE="11">GMT+11:00</OPTION>
          <OPTION VALUE="10">GMT+10:00</OPTION>
          <OPTION VALUE="9">GMT+9:00</OPTION>
          <OPTION VALUE="8" selected>GMT+8:00 *</OPTION>
          <OPTION VALUE="7">GMT+7:00</OPTION>
          <OPTION VALUE="6">GMT+6:00</OPTION>
          <OPTION VALUE="5">GMT+5:00</OPTION>
          <OPTION VALUE="4">GMT+4:00</OPTION>
          <OPTION VALUE="3">GMT+3:00</OPTION>
          <OPTION VALUE="2">GMT+2:00</OPTION>
          <OPTION VALUE="1">GMT+1:00</OPTION>
          <OPTION VALUE="0">GMT</OPTION>
          <OPTION VALUE="-1">GMT-1:00</OPTION>
          <OPTION VALUE="-2">GMT-2:00</OPTION>
          <OPTION VALUE="-3">GMT-3:00</OPTION>
          <OPTION VALUE="-4">GMT-4:00</OPTION>
          <OPTION VALUE="-5">GMT-5:00</OPTION>
          <OPTION VALUE="-6">GMT-6:00</OPTION>
		  <OPTION VALUE="-7">GMT-7:00</OPTION>
		  <OPTION VALUE="-8">GMT-8:00</OPTION>
		  <OPTION VALUE="-9">GMT-9:00</OPTION>
		  <OPTION VALUE="-10">GMT-10:00</OPTION>
		  <OPTION VALUE="-11">GMT-11:00</OPTION>
<?php if($CFG_GMT!=8){
	if($CFG_GMT>0) echo "<OPTION VALUE='$CFG_GMT' selected>GMT+".$CFG_GMT.":00</OPTION>";
	if($CFG_GMT==0) echo "<OPTION VALUE='$CFG_GMT' selected>GMT</OPTION>";
	if($CFG_GMT<0) echo "<OPTION VALUE='$CFG_GMT' selected>GMT".$CFG_GMT.":00</OPTION>";
}
?>
          </SELECT>
        </TD>
      </TR>
    </TABLE>
    <BR>
    <B><FONT COLOR="#FFFFFF"><?php echo $LANG_DEFAULT_LIST;?></FONT></B><BR>
    <BR>
    <TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="95%" ALIGN="CENTER">
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_LIST_NUM;?>:</B></TD>
        <TD> 
          <SELECT NAME="List_NumPerPage">
            <OPTION VALUE="15" <?php Selected($CFG_List_NumPerPage,15,20);?>>15</OPTION>
            <OPTION VALUE="20" <?php Selected($CFG_List_NumPerPage,20,20);?>>20 *</OPTION>
            <OPTION VALUE="50" <?php Selected($CFG_List_NumPerPage,50,20);?>>50</OPTION>
			<OPTION VALUE="100" <?php Selected($CFG_List_NumPerPage,100,20);?>>100</OPTION>
			<OPTION VALUE="-1" <?php Selected($CFG_List_NumPerPage,-1,20);?>><?php echo $LANG_DEFAULT_ALL;?></OPTION>
           </SELECT>
        </TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_LIST_AUTOREFRESH;?>:</B></TD>
        <TD> 
          <SELECT NAME="List_AutoRefresh">
            <OPTION VALUE="0" <?php Selected($CFG_List_AutoRefresh,0,120);?>><?php echo $LANG_DEFAULT_NOREFRESH;?></OPTION>
			<OPTION VALUE="30" <?php Selected($CFG_List_AutoRefresh,30,120);?>>30 <?php echo $LANG_DEFAULT_SEC;?></OPTION>
            <OPTION VALUE="60" <?php Selected($CFG_List_AutoRefresh,60,120);?>>60 <?php echo $LANG_DEFAULT_SEC;?></OPTION>
            <OPTION VALUE="120" <?php Selected($CFG_List_AutoRefresh,120,120);?>>2 <?php echo $LANG_DEFAULT_MINUTE;?> *</OPTION>
            <OPTION VALUE="300" <?php Selected($CFG_List_AutoRefresh,300,120);?>>5 <?php echo $LANG_DEFAULT_MINUTE;?></OPTION>
          </SELECT>
        </TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT">&nbsp;</TD>
        <TD> 
          <INPUT TYPE="checkbox" VALUE="yes" NAME="List_AutoPOP" <?php Checked($CFG_List_AutoPOP,'yes','');?>>
          <?php echo $LANG_DEFAULT_LIST_AUTOPOP;?></TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_LIST_DATE;?>:</B></TD>
        <TD> 
          <INPUT TYPE="radio" NAME="List_MailTime" VALUE="Achieve" <?php Checked($CFG_List_MailTime,'Achieve','Write');?>>
          <?php echo $LANG_DEFAULT_LIST_ARRIVED_DATE;?> *
          <INPUT TYPE="radio" NAME="List_MailTime" VALUE="Write" <?php Checked($CFG_List_MailTime,'Write','Write');?>>
          <?php echo $LANG_DEFAULT_LIST_WRITE_DATE;?></TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_LIST_SORT;?>:</B></TD>
        <TD> 
          <SELECT NAME="List_SortBy">
            <OPTION VALUE='Date' <?php Selected($CFG_List_SortBy,'Date','Date');?>><?php echo $LANG_LIST_DATE;?> *</OPTION>
            <OPTION VALUE='From' <?php Selected($CFG_List_SortBy,'From','Date');?>><?php echo $LANG_DEFAULT_LIST_FROMTO;?></OPTION>
            <OPTION VALUE='Subject' <?php Selected($CFG_List_SortBy,'Subject','Date');?>><?php echo $LANG_HEADER_SUBJECT;?></OPTION>
            <OPTION VALUE='Size' <?php Selected($CFG_List_SortBy,'Size','Date');?>><?php echo $LANG_LIST_SIZE;?></OPTION>
          </SELECT>
        </TD>
      </TR>
    </TABLE>
    <BR>
    <B><FONT COLOR="#FFFFFF"><?php echo $LANG_DEFAULT_READ_PREV;?></FONT></B> <BR>
    <BR>
    <TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="95%" ALIGN="CENTER">
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_READ;?>:</B></TD>
        <TD> 
          <INPUT TYPE="radio" VALUE="Plain" NAME="Prev_Alternative" <?php Checked($CFG_Prev_Alternative,'Plain','Html');?>>
          <?php echo $LANG_DEFAULT_TEXT;?> 
          <INPUT TYPE="radio" NAME="Prev_Alternative" VALUE="Html" <?php Checked($CFG_Prev_Alternative,'Html','Html');?>>
          <?php echo $LANG_DEFAULT_HTML;?> *</TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT">&nbsp;</TD>
        <TD> 
          <INPUT TYPE="checkbox" NAME="Prev_IsRead" VALUE="yes" <?php Checked($CFG_Prev_IsRead,'yes','yes');?>>
          <?php echo $LANG_DEFAULT_AUTO_READED;?> *</TD>
      </TR>
    </TABLE>
    <BR>
    <BR>
    <B><FONT COLOR="#FFFFFF"><?php echo $LANG_DEFAULT_SEND;?></FONT></B><BR>
    <BR>
    <TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="95%" ALIGN="CENTER">
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_SEND_TYPE;?>:</B></TD>
        <TD> 
          <INPUT TYPE="radio" NAME="Send_ContentType" VALUE="Plain" <?php Checked($CFG_Send_ContentType,'Plain','Alternative');?>>
          <?php echo $LANG_DEFAULT_TEXT;?> 
          <INPUT TYPE="radio" NAME="Send_ContentType" VALUE="Html" <?php Checked($CFG_Send_ContentType,'Html','Alternative');?>>
          <?php echo $LANG_DEFAULT_HTML;?> 
          <INPUT TYPE="radio" NAME="Send_ContentType" VALUE="Alternative" <?php Checked($CFG_Send_ContentType,'Alternative','Alternative');?>>
          <?php echo $LANG_DEFAULT_TEXT."/".$LANG_DEFAULT_HTML;?>*</TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_SEND_CODE;?>:</B></TD>
        <TD>
          <INPUT TYPE="radio" NAME="Send_Encoding" VALUE="8bit" <?php Checked($CFG_Send_Encoding,'8bit','Base64');?>>
          <?php echo $LANG_DEFAULT_SEND_NOCODE;?> 
          <INPUT TYPE="radio" NAME="Send_Encoding" VALUE="Base64" <?php Checked($CFG_Send_Encoding,'Base64','Base64');?>>
          Base64 *
          <INPUT TYPE="radio" NAME="Send_Encoding" VALUE="Quoted-printable" <?php Checked($CFG_Send_Encoding,'Quoted-printable','Base64');?>>
          Quoted-printable</TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_SEND_LANG;?>:</B></TD>
        <TD> 
          <SELECT NAME="Send_Charset">
            <OPTION VALUE="gb" <?php Selected($CFG_Send_Charset,'gb','gb');?>><?php echo $LANG_LIST_CHINESE_GB;?> GB2312 *</OPTION>
            <OPTION VALUE="big" <?php Selected($CFG_Send_Charset,'big','gb');?>><?php echo $LANG_LIST_CHINESE_BIG;?> BIG5</OPTION>
            <OPTION VALUE="en" <?php Selected($CFG_Send_Charset,'en','gb');?>><?php echo $LANG_LIST_ENGLISH;?> ISO-8859-1</OPTION>
          </SELECT>
        </TD>
      </TR>
    </TABLE>
    <BR>
    <FONT COLOR="#FFFFFF"><B><?php echo $LANG_DEFAULT_POP;?></B></FONT><BR>
    <BR>
    <TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="95%" ALIGN="CENTER">
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_POP_NUM;?>:</B></TD>
        <TD>
          <SELECT NAME="POP_NumPer">
            <OPTION VALUE="50" <?php Selected($CFG_POP_NumPer,50,50);?>>50 *</OPTION>
            <OPTION VALUE="100" <?php Selected($CFG_POP_NumPer,100,50);?>>100</OPTION>
          </SELECT>
        </TD>
      </TR>
      <TR BGCOLOR="#D0E6CE"> 
        <TD ALIGN="RIGHT"><B><?php echo $LANG_DEFAULT_POP_TIMEOUT;?>:</B></TD>
        <TD>
          <SELECT NAME="POP_Timeout">
            <OPTION VALUE="30" <?php Selected($CFG_POP_Timeout,30,30);?>>30 *</OPTION>
            <OPTION VALUE="60" <?php Selected($CFG_POP_Timeout,60,30);?>>60</OPTION>
          </SELECT>
          <?php echo $LANG_DEFAULT_SEC;?> </TD>
      </TR>
    </TABLE>  
    <BR>
    <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_DEFAULT_OK;?>" CLASS="myinput2" onClick="Modify(this.form)">
    <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_DEFAULT_DEFAULT;?>" CLASS="myinput2" onClick="Default(this.form)">
    <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_DEFAULT_CLOSE;?>" CLASS="myinput2" onClick="window.close()">
  </CENTER>
  <P ALIGN="CENTER">&nbsp;</P>
</FORM>
</BODY>
<SCRIPT>
self.focus();
var Confirm_Ok = "<?php echo $LANG_DEFAULT_MESG_OK;?>";				//ȷ���޸�?
var Confirm_Default = "<?php echo $LANG_DEFAULT_MESG_DEFAULT;?>";	//�������ý��ָ�ΪϵͳĬ��,������?

function Modify(form){
	if(!confirm( Confirm_Ok )) return false;
	form.action = 'default.php?Cmd=Modify';
	form.submit();
}

function Default(form){
	if(!confirm( Confirm_Default )) return false;
	form.action = 'default.php?Cmd=Default';
	form.submit();
}
</SCRIPT>
</HTML>