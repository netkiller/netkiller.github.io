<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: header.php,v 1.19 2003/03/11 01:06:44 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

$DEBUG = 0;

/* ��ڲ���:
 *				Mailbox	����
 *				Num		�ʼ����
 *				Lang	����
 */
$get_Mailbox = trim($HTTP_GET_VARS['Mailbox']);
$get_Num     = trim($HTTP_GET_VARS['Num']);
$get_Lang    = trim($HTTP_GET_VARS['Lang']);

$PreNum = $get_Num - 1;
//if ($PreNum <= 0) $PreNum = 1;
$NextNum = $get_Num + 1;

$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";
($FD_BODYLIST = fopen($bodylistfile,"r"))|| die("Error open header file");
$line = fgets($FD_BODYLIST,1024);
list($FromName,$From,$Subject,$Date,$Size,$Content_Type,$Content_Transfer_Encoding) = split("\t",$line,7);
//list($null,$Date) = Date2Str($Date,$CFG_GMT);

// Read body listing and parase attachment

fseek($FD_BODYLIST,0,SEEK_SET);
$i = 0;
$line = fgets($FD_BODYLIST,1024);	// skip the first line
while(($line=fgets($FD_BODYLIST,1024)) && !feof($FD_BODYLIST)){
	list($filename,$type,$size,$disposition,$id,$location) = split("\t",$line,6);
	if($disposition=='attachment' || 
		($disposition=='inline' && substr_count($filename,'unkown')==1 ) ||
		($disposition=='inline' && $type=='application/x-msdownload') || 
		$type=='application/octet-stream' ||
		( empty($location) && empty($id)) ){
		$i++;
		$Attachlist .= "<option value='File=$filename&MimeType=$type&Size=$size'>$i ".TrimStr($filename,20)." ".FormatSize($size)."</option>\n";
	}
}
$AttachTotal = $i;

if($DEBUG){
	$Attachlist .= "<option value='-'></option>\n";
	$Attachlist .= "<option value='-'>-$LANG_HEADER_BODY_LIST-</option>\n";
	fseek($FD_BODYLIST,0,SEEK_SET);
	$i = 0;
	$line = fgets($FD_BODYLIST,1024);	// skip the first line
	while(($line=fgets($FD_BODYLIST,1024)) && !feof($FD_BODYLIST)){
		$i++;
		list($filename,$type,$size,$disposition,$id,$location) = split("\t",$line,6);
		$Attachlist .= "<option value='File=$filename&MimeType=$type'>$i ".TrimStr($filename,20).FormatSize($size)."</option>\n";
	}
}
fclose($FD_BODYLIST);
?>
<HTML>
<HEAD>
<TITLE></TITLE>
<META http-equiv="Content-Type" content="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK rel="stylesheet" href="css/igenus.css" type="TEXT/CSS">
</HEAD>
<SCRIPT src=script/header.js></SCRIPT>
<BODY bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<TABLE width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#78B471"><FORM name='header' method=POST> 
  <TR> 
    <TD width="50" bgcolor="#D0E6CE" background="images/bbk.gif" style="border: 1 solid #FFFFFF" align="CENTER"> 
      <B> 
      <?php if($get_Mailbox=='outbox'||$get_Mailbox=='draft') echo "$LANG_SENDFORM_TO:"; else echo "$LANG_HEADER_FROM:";?>
      </B> </TD>
    <TD style="color: #FFFFFF;">
	&nbsp;<?php echo TrimStr($FromName,40);?> <U><?php echo TrimStr($From,40);?></U>&nbsp;&nbsp;
	<INPUT type="button" onClick="AddToAddr('<?php echo $FromName;?>','<?php echo $From;?>')" 
	value="<?php echo $LANG_HEADER_ADD_TO_ADDRESS;?>" class="myinput">
      </TD>
  </TR>
  <TR> 
    <TD width="50" bgcolor="#D0E6CE" background="images/bbk.gif" style="border: 1 solid #FFFFFF" align="CENTER"> 
      <B>
      <?php echo "$LANG_HEADER_DATE:";?>
      </B> </TD>
    <TD style="color: #FFFFFF;" bgcolor="#73BA6B">
      <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
        <TR> 
          <TD style="color: #FFFFFF;" bgcolor="#73BA6B">&nbsp;<?php echo "$Date";?>
          </TD>
          <TD align="right">
            <INPUT type="button" value="<<-" class="myinput" title="<?php echo $LANG_HEADER_PREV;?>"
      onClick="Prev(<?php echo "'Mailbox=$get_Mailbox',$PreNum,'$LANG_HEADER_ALERT_PREV_STR1','$LANG_HEADER_ALERT_PREV_STR2'";?>)" name="button">
            <INPUT type="button" value="->>" class="myinput" title="<?php echo $LANG_HEADER_NEXT;?>"
      onClick="Next(<?php echo "'Mailbox=$get_Mailbox',$NextNum,'$LANG_HEADER_ALERT_NEXT_STR1','$LANG_HEADER_ALERT_NEXT_STR2'";?>)" name="button2">
          </TD>
          <TD align="right">&nbsp;</TD>
        </TR>
      </TABLE>
    </TD>
  </TR>
  <TR> 
    <TD width="50" bgcolor="#D0E6CE" background="images/bbk.gif" style="border: 1 solid #FFFFFF" align="CENTER"> 
      <B> 
      <?php echo "$LANG_HEADER_SUBJECT:";?>
      </B> </TD>
    <TD style="color: #FFFFFF;"> 
      &nbsp;<?php echo TrimStr($Subject,82);?>
    </TD>
  </TR>
</TABLE>
<TABLE width="100%" border="0" cellspacing="0" cellpadding="0" background="images/line-bk.gif" valign="middle" align="left" height="27">
  <TR ALIGN="center">
    <TD>
	  <?php
	  //����
	  $Reply_Out = '<INPUT type="button" value="';
	  if($get_Mailbox=='outbox') $Reply_Out .= "$LANG_HEADER_SENDAGAIN\" onClick=\"SendAgain";
	  else if($get_Mailbox=='draft') $Reply_Out .= "$LANG_HEADER_WRITEAGAIN\" onClick=\"WriteAgain";
	  else $Reply_Out .= $LANG_HEADER_REPLY.'" onClick="Reply';
	  $Reply_Out .= "('Mailbox=$get_Mailbox&Num=$get_Num&Type=$Content_Type')\" class='myinput'>";
	  echo $Reply_Out;
      ?>
      <INPUT type="button" value="<?php echo $LANG_HEADER_FORWARD;?>" class="myinput"
      onClick="Forward(<?php echo 
      "'Mailbox=$get_Mailbox&Num=$get_Num&Type=$Content_Type','$LANG_HEADER_ALERT_FORWARD_STR1'";?>)">
      <INPUT type="button" value="<?php echo $LANG_HEADER_SOURCE;?>" class="myinput" 
      onClick="ReadSource(this.form,<?php echo "'Mailbox=$get_Mailbox&Num=$get_Num','$LANG_HEADER_ALERT_SOURCEHEADONLY'";?>)">
      <INPUT type="button" value="<?php echo $LANG_HEADER_BODY;?>" class="myinput" 
      onClick="Read(this.form,'<?php echo "Mailbox=$get_Mailbox&Num=$get_Num&Type=$Content_Type";?>')">
            <SELECT name="Attach" class="myselect" onChange="DownloadAttach(this.form)" <?php if( $AttachTotal==0 ) echo "Disabled";?>>
              <OPTION value="-"><?php 
              if ( $AttachTotal==0 ) echo $LANG_HEADER_NOATTACH; else echo $LANG_HEADER_ATTACH;
              ?></OPTION>
              <OPTION value="-">----</OPTION>
              <?php echo $Attachlist;?>
            </SELECT>
    </TD>
  </TR>
</FORM>
</TABLE>
</BODY> 
</HTML>
