<?php
/*-
 * iGENUS webmail
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: attach.php,v 1.3 2003/02/11 03:16:06 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

// ��ڲ�����Cmd
// get
$get_Cmd = $HTTP_GET_VARS['Cmd'];
$get_filename = $HTTP_GET_VARS['filename'];

// post
// $HTTP_POST_FILES


chdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/");
$listattachfile = "list_attach";
if(!is_dir("attach")) mkdir("attach",0755);
switch($get_Cmd){
	case "add":
	if (file_exists("attach/".$HTTP_POST_FILES['attachfile']['name'])){
		$fileexists = $HTTP_POST_FILES['attachfile']['name'];
		break;
	}
	if ($HTTP_POST_FILES['attachfile']['size']==0 || $HTTP_POST_FILES['attachfile']['name']=="none"){
		break;
	}

	$tmp_filename = $HTTP_POST_FILES['attachfile']['tmp_name'];
	
	($FD_LIST_ATTACH = fopen($listattachfile,"a")) || die("Error open $listattachfile!");
		fputs($FD_LIST_ATTACH,	$HTTP_POST_FILES['attachfile']['name']."\t".
								$HTTP_POST_FILES['attachfile']['size']."\t".
								$HTTP_POST_FILES['attachfile']['type']."\n"
								);	
	fclose($FD_LIST_ATTACH);
	copy($tmp_filename,"attach/".$HTTP_POST_FILES['attachfile']['name']);
	
	header("Location: attach.php?Cmd=list");
	break;
	
	case "Del":
	// $filename
	$listattachfileTEMP = "list_attach_tmp";
	($FD_LIST_ATTACH = fopen($listattachfile,"r")) || die("Error open $listattachfile!");
	($FD_LIST_ATTACH_TEMP = fopen($listattachfileTEMP,"w")) || die("Error open $listattachfileTEMP!");
	while( $buff = fgets($FD_LIST_ATTACH,1024) ){
		list($name,$size,$type) = split("\t",$buff,3);
		if ($name!=$get_filename) fputs($FD_LIST_ATTACH_TEMP,$buff);
	}
	fclose($FD_LIST_ATTACH);
	fclose($FD_LIST_ATTACH_TEMP);
	if(file_exists("attach/$get_filename")) unlink("attach/".$get_filename);
	unlink($listattachfile);
	rename($listattachfileTEMP,$listattachfile);

	header("Location: attach.php?Cmd=list");
	break;
	
	case "list":
	default:
}

if (!file_exists($listattachfile)) exit();
($FD_LIST_ATTACH = fopen($listattachfile,"r")) || die("Error open $listattachfile!");
$i = 0;
while(($buff = chop(fgets($FD_LIST_ATTACH,1024))) && !feof($FD_LIST_ATTACH)){
	$i++;
	list($name,$size,$type) = split("\t",$buff,3);
	if($size>=1024){
		$size = intval($size/1024);
		$size = $size."kB";
	}else {
		$size = $size."Byte";
	}

/*	
	list($filename,$suffix) = split("\.",$name,2);
	$suffix = strtolower($suffix);
	$img = $suffix.".gif";
	
	if(!file_exists("$CFG_BASEPATH/images/suffix/$img")) $img = "unknown.gif";
	$StrAttach .= "<TD ALIGN=CENTER>";
	$StrAttach .= "<INPUT TYPE='checkbox' NAME='$i' VALUE='$i'>";
	$StrAttach .= "<A href=# class=attach onclick=\"DelAttach('$name')\"><img src='images/suffix/$img' border=0><BR>\n";
	$StrAttach .= "$name<BR>\n";
	$StrAttach .= "$size</A></TD>\n";
	$StrAttach .= "<TD width=10></TD>\n";
*/	
	$StrAttach2 .= "<option value='". rawurlencode($name) . "'>$i $name $size</option>\n";
}
fclose($FD_LIST_ATTACH);
?>
<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<SCRIPT>
<!--
var str = "<?php echo $fileexists; ?>";
if(str !="") alert( str+" <?php echo $LANG_SENDFORM_FILE_EXIST;?>");

function DelAttach(file){
	if(confirm("<?php echo $LANG_SENDFORM_FILE_DEL_CONFIRM;?>\""+ file +"\" ?")){
		url = "attach.php?Cmd=Del&filename="+file;
		window.location = url;
	}
}

function Delfile(form){
	file = form.list.value;
	filename = form.list.options[form.list.selectedIndex].text;
	if (file =="-") return false;
	if(confirm("<?php echo $LANG_SENDFORM_FILE_DEL_CONFIRM;?>" + filename +" ?")){
		url = "attach.php?Cmd=Del&filename="+file;
		window.location = url;
	}
}
//-->
</SCRIPT>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LEFTMARGIN="0" TOPMARGIN="0">
<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <FORM NAME="attachlist" METHOD="post">
  <TR>
<?php
if( $StrAttach2!="" ){
?>  
  <TD><SELECT NAME='list' CLASS=myselect>
  		<OPTION VALUE="-"><?php echo "$LANG_ATTACH_LIST ( $i )";?> </OPTION>
  		<OPTION VALUE="-">----</OPTION>
  		<?php echo $StrAttach2;?>
  	</SELECT>
  </TD>
  <TD WIDTH=10>
  </TD>
  <TD><INPUT TYPE='button' onClick="Delfile(this.form)" CLASS=myinput VALUE="<?php echo $LANG_ATTACH_DELETE;?>">
  </TD>
<?php }?>
  </TR>
</FORM>  
</TABLE>
</BODY>
</HTML>