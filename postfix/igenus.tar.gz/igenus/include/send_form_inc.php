<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: send_form_inc.php,v 1.14 2003/01/15 08:16:00 wuqiong Exp $
 */

//��ȡǩ���б�

if(is_file($CFG_USERSIGN)){
	($FD_CFG = fopen($CFG_USERSIGN,"r")) || die("Error open user sign file.");
	$i = 0;
	while(!feof($FD_CFG)){
		$line = trim(fgets($FD_CFG,512));
		if(empty($line)) continue;
		if( $line!='# -end-' ){
			$Sign .= $line."\n";
			continue;
		}
		$i++;
	}
	$Total = $i--;
	fclose($FD_CFG);
	
	$List_Sign = '';
	for($i=1;$i<=$Total;$i++)
		$List_Sign .= "<OPTION VALUE='$i'>$LANG_SENDFORM_SIGN $i</OPTION>\n";
}
?>
<SCRIPT>
<!--
document.SendFlag.flag.value = 0;

function CloseWin(){
	if(addrwin) addrwin.close();
}

var Confirm_Save_Continue = "<?php echo $LANG_SENDFORM_SAVETODRAFT;?>";	//��Ϊ�ݸ壬������
var Mesg_To = "<?php echo $LANG_SENDFORM_TO;?>";	//�����˵�ַ
var Mesg_Subject = "<?php echo $LANG_SENDFORM_SUBJECT;?>";	//����
var Mesg_Body = "<?php echo $LANG_SENDFORM_BODY;?>";	//����
var Mesg_Input = "<?php echo $LANG_SENDFORM_SEND_ALERT_STR4;?>";	//����д�����¸���

//-->
</SCRIPT>
<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<SCRIPT SRC=script/send.js></SCRIPT>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" onunload="CloseWin()">
<TABLE CELLPADDING="10">
  <TR><TD>
      
      <FORM NAME="send" METHOD="post" ACTION="">
        <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0" WIDTH="626">
          <TR> 
            <TD > 
              <INPUT TYPE="button" VALUE="<?php echo $LANG_SENDFORM_TO;?>:" CLASS=myinput onClick=Addr(this.form)>
            </TD>
            <TD WIDTH="5" >&nbsp;</TD>
            <TD> 
              <INPUT TYPE="text" NAME="To" CLASS="myinput2"  SIZE="36" VALUE="<?php echo $get_MailTo;?>">
            </TD>
            <TD WIDTH="20" >&nbsp;</TD>
            <TD > 
              <INPUT TYPE="button" VALUE="<?php echo $LANG_SENDFORM_REPLYTO;?>:" CLASS=myinput>
            </TD>
            <TD WIDTH="5" >&nbsp;</TD>
            <TD> 
              <INPUT TYPE="text" NAME="ReplyTo" CLASS="myinput2" SIZE="37">
            </TD>
          </TR>
          <TR>
            <TD> 
              <INPUT TYPE="button" VALUE="<?php echo $LANG_SENDFORM_CC;?>:" CLASS=myinput onClick=Addr(this.form)>
            </TD>
            <TD>&nbsp;</TD>
            <TD> 
              <INPUT TYPE="text" NAME="Cc" CLASS="myinput2" SIZE="36" VALUE="<?php echo $get_MailCc;?>">
            </TD>
            <TD >&nbsp;</TD>
            <TD > 
              <INPUT TYPE="button" VALUE="<?php echo $LANG_SENDFORM_BCC;?>:" CLASS=myinput onClick=Addr(this.form)>
            </TD>
            <TD >&nbsp;</TD>
            <TD> 
              <INPUT TYPE="text" NAME="Bcc" CLASS="myinput2" SIZE="37" VALUE="<?php echo $get_MailBcc;?>">
            </TD>
          </TR>
          <TR> 
            <TD> 
              <INPUT TYPE="button" VALUE="<?php echo $LANG_SENDFORM_SUBJECT;?>:" CLASS=myinput>
            </TD>
            <TD>&nbsp;</TD>
            <TD COLSPAN="5"> 
              <INPUT TYPE="TEXT" NAME="Subject" SIZE="90" CLASS="myinput2" VALUE="<?php echo $Subject;?>">
            </TD>
          </TR>
        </TABLE>
        <BR>
        <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0">
          <TR> 
            <TD><B><?php echo $LANG_SENDFORM_BODY;?>:</B></TD>
            <TD ALIGN="RIGHT"> 
              <INPUT TYPE="checkbox" NAME="Backup" VALUE="Backup" CHECKED>
              <?php echo $LANG_SENDFORM_BACKUP;?>              �� 
              <SELECT NAME="Sign"  CLASS="myselect">
                <OPTION VALUE='0'> 
                <?php echo $LANG_SENDFORM_USE_SIGN;?>
                </OPTION>
                <?php echo $List_Sign;?>
              </SELECT>
              �� 
              <?php echo $LANG_SENDFORM_PRIORITY;?>
              <SELECT NAME="Priority" CLASS="myselect">
                <OPTION VALUE="1">
                <?php echo $LANG_SENDFORM_PRIORITY_VALUE[1];?>
                </OPTION>
                <OPTION VALUE="3" SELECTED> 
                <?php echo $LANG_SENDFORM_PRIORITY_VALUE[3];?>
                </OPTION>
                <OPTION VALUE="5"> 
                <?php echo $LANG_SENDFORM_PRIORITY_VALUE[5];?>
                </OPTION>
              </SELECT>
            </TD>
          </TR>
          <TR> 
            <TD COLSPAN="2"> 
              <TEXTAREA NAME="Body" COLS="101" ROWS="20" CLASS=mytextarea><?php echo $Body;?></TEXTAREA>
            </TD>
          </TR>
        </TABLE>
        <TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        </TABLE>
      </FORM>
      <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0" WIDTH="626">
        <FORM NAME="Attach" METHOD="post" ACTION="attach.php?Cmd=add" ENCTYPE="multipart/form-data" TARGET="Attach">
          <TR> 
            <TD> 
              <INPUT TYPE="button" CLASS=myinput VALUE="<?php echo $LANG_SENDFORM_ATTACH;?>">
              <INPUT TYPE="file" NAME="attachfile" CLASS=myinput2>
              <INPUT TYPE="button" CLASS=myinput VALUE="<?php echo $LANG_SENDFORM_ADD;?>" onClick="AddAttach(this.form,<?php echo "'$LANG_SENDFORM_ADD_ALERT_STR1','$LANG_SENDFORM_ATTACH_MESG'";?>)">
            </TD>
            <TD WIDTH="20">&nbsp;</TD>
            <TD ALIGN="RIGHT"> 
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_SENDFORM_SEND;?>"
        onClick="Send(document.send,<?php
        echo "'$LANG_SENDFORM_SEND_ALERT_STR1','$LANG_SENDFORM_SEND_ALERT_STR2','$LANG_SENDFORM_SEND_ALERT_STR3','$LANG_SENDFORM_SEND_ALERT_STR4'";
        ?>)" CLASS="myinput" NAME="BUTTON">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_SENDFORM_SAVE;?>" CLASS="myinput"
		onClick="SaveToDraft(document.send)">
              <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_SENDFORM_RESET;?>" CLASS="myinput" onClick="document.send.reset()">
            </TD>
          </TR>
        </FORM>
      </TABLE>
      <BR>
      <TABLE WIDTH="620" BORDER="0" CELLSPACING="0" CELLPADDING="0">
        <TR> 
          <TD><IFRAME NAME=Attach SRC="attach.php?Cmd=list" WIDTH=100% SCROLLING=NO HEIGHT=20 FRAMEBORDER=0 ALIGN="RIGHT"></IFRAME> 
          </TD>
        </TR>
      </TABLE>
</TD></TR>
</TABLE>
</BODY>
</HTML>