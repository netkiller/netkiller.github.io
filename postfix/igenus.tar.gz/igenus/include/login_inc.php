<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: login_inc.php,v 1.8 2003/03/06 03:09:52 wuqiong Exp $
 */

if(!defined("INCLUDE_LOGIN_OK")) {
	
	defined("INCLUDE_LOGIN_OK");
	
	session_start();
	$G_USERNAME = $HTTP_SESSION_VARS['G_USERNAME'];
	$G_DOMAIN = $HTTP_SESSION_VARS['G_DOMAIN'];
	$G_HOME = $HTTP_SESSION_VARS['G_HOME'];
	$G_TIME = $HTTP_SESSION_VARS['G_TIME'];
	$G_QUOTA = $HTTP_SESSION_VARS['G_QUOTA'];
	$G_NICKNAME = $HTTP_SESSION_VARS['G_NICKNAME'];
	$G_ID = $HTTP_SESSION_VARS['G_ID'];
	$G_LANG = $HTTP_SESSION_VARS['G_LANG'];
	
 	if ( 	!session_is_registered(G_USERNAME) || $G_USERNAME == "" ||
 			!session_is_registered(G_DOMAIN)   || $G_DOMAIN == "" ||
 			!session_is_registered(G_HOME)     || $G_HOME == "" ||
 			!session_is_registered(G_TIME)     || $G_TIME == "" ||
 			!session_is_registered(G_QUOTA)    || $G_QUOTA == "" ||
 			!session_is_registered(G_NICKNAME) || $G_NICKNAME == ""
 			 ){
		header("Location: login.php");
		exit();
	}
		
} // End of INCLUDE_LOGIN_OK
?>