<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: reply_inc.php,v 1.5 2002/12/12 07:50:26 wuqiong Exp $
 */
 

// Return $Body
function Format_body($Token){
	global $CFG_TEMP,$G_DOMAIN,$G_USERNAME,$CFG_Prev_Alternative;
	$HtmlDone = 0;

	if($CFG_Prev_Alternative=='Html'){
		$bodyfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/unknown.html";
		if ( file_exists($bodyfile) ){
			($FD_BODY = fopen($bodyfile,"r"))||die("Error open $bodyfile!");
		
			do{
				$line = fgets($FD_BODY,2048);
				$Html_Body .= trim($line);
			}while(!feof($FD_BODY));
			//html��ɴ�д
			$Html_Body = preg_replace ("/(<\/?)(\w+)([^>]*>)/e", 
              "'\\1'.strtolower('\\2').'\\3'", 
              $Html_Body);
			// <br><p> -> \n
			$Html_Body = preg_replace("/<br>|<p>/","\n",$Html_Body);
		
			$search = array ("'<script[^>]*?>.*?</script>'si",  // Strip out javascript
				 "'<style[^>]*?>.*?</style>'si",
                 "'<[\/\!]*?[^<>]*?>'si",           // Strip out html tags
                 "'([\r\n])[\s]+'",                 // Strip out white space
                 "'&(quot|#34);'i",                 // Replace html entities
                 "'&(amp|#38);'i",
                 "'&(lt|#60);'i",
                 "'&(gt|#62);'i",
                 "'&(nbsp|#160);'i",
                 "'&(iexcl|#161);'i",
                 "'&(cent|#162);'i",
                 "'&(pound|#163);'i",
                 "'&(copy|#169);'i",
                 "'&#(\d+);'e");                    // evaluate as php

			$replace = array ("",
                  "",
                  "",
                  "\\1",
                  "\"",
                  "&",
                  "<",
                  ">",
                  " ",
                  chr(161),
                  chr(162),
                  chr(163),
                  chr(169),
                  "chr(\\1)");

			$Html_Body = preg_replace ($search, $replace, $Html_Body);

			$Html_Body = wordwrap($Html_Body,90,"\n");
	//		$Html_Body = StrWrap($Html_Body,90,'',"\n");
			$Html_Body = preg_replace ("/\n/", "\n$Token", $Html_Body);
			$Body = $Body .$Token. $Html_Body;
			$HtmlDone = 1;
		}
	}
	if( $HtmlDone !=1 ){
		
		$bodyfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/unknown.txt";
	
		if ( file_exists($bodyfile) ){
			($FD_BODY = fopen($bodyfile,"r"))||die("Error open $bodyfile!");
			do{
				$line = fgets($FD_BODY,2048);
				$Body .= $Token.$line;
			}while(!feof($FD_BODY));
		}
	}
	return $Body;
}

// �����ַ���Ϊָ�����ȣ������޳�������֣�����س�
function StrWrap($string,$length,$Token,$Break){
	$Out = '';
	$len = strlen($string);
	if($len <= $length)	return $Token.$string.$Break;
	$k = 0;
	while( $k+$length<=$len ){
		$checkchar = "";
		for($i=0;$i<$length;$i++){
			$ac = ord($string[$i+$k]);
			if($ac >= 161){
				$checkchar .= chr($ac);
				$checkchar .= chr(ord($string[$i+$k+1]));
				$i++;
			}else{
				$checkchar .= chr($ac);
			}
		}
		$Out .= $Token. $checkchar.$Break;
		$k = $i + $k;
	}
	return $Out;
} 
?>