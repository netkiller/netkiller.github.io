<?php
/*-
 * iGENUS webmail
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: fun_inc.php,v 1.20 2003/01/14 00:57:38 wuqiong Exp $
 */

if(!defined("INCLUDE_FUN_OK")){
	
	defined("INCLUDE_FUN_OK");

function Parse_head($FD_MAIL){

	$HeaderField = array();
	$HeaderField['content-type'] = 1;
	$HeaderField['charset'] = 1;
	$HeaderField['boundary'] = 1;
	$HeaderField['name'] = 1;
	$HeaderField['filename'] = 1;
	$HeaderField['content-transfer-encoding'] = 1;
	$HeaderField['content-location'] = 1;	
	$HeaderField['content-id'] = 1;
	$HeaderField['content-disposition'] = 1;
		
	$header = array();
	$linepre = "";
	while(($line = chop(fgets($FD_MAIL,1024))) && $line !=""){
		if(preg_match("/^\s+/",$line)){
			$line = preg_replace("/^\s+/"," ",$line);
			$line = $linepre.$line;
		} else {
			$linepre = "";
		}
		list($name,$value) = split(":",$line,2);
		$linepre = $line;
		$name = trim(strtolower($name));
		$value = trim($value);
		
		// �޳����õ���Ϣ
		if( $name!='' && $HeaderField[$name] ) $header["$name"] = $value;
		
		//�����������͵� content-type ������� charset / boundary
		if($name=='content-type') $header = SplitSubType($header,$name);
		if($name=='content-disposition') $header = SplitSubType($header,$name);
	}
	if(!empty($header['name'])) $header['name'] = Decode_mime($header['name']);
	if(!empty($header['filename'])) $header['filename'] = Decode_mime($header['filename']);
	if(!empty($header['content-id'])) $header['content-id'] = ChopQuota2($header['content-id']);
	return $header;
}

// �����ʼ�ͷ��Ϣ��������� $header array ����
// 
function Parse_head_List($FD_MAIL){

	$HeaderField = array();
	$HeaderField['from'] = 1;
	$HeaderField['to']   = 1;
	$HeaderField['cc']   = 1;
	$HeaderField['bcc']   = 1;
	$HeaderField['reply-to'] = 1;
	$HeaderField['subject'] = 1;
	$HeaderField['content-type'] = 1;
	$HeaderField['charset'] = 1;
	$HeaderField['boundary'] = 1;
	$HeaderField['date'] = 1;
	$HeaderField['content-transfer-encoding'] = 1;

	$header = array();
	
	$linepre = "";
	while(($line = chop(fgets($FD_MAIL,1024))) && $line !=""){
		if(preg_match("/^\s+/",$line)){
			$line = preg_replace("/^\s+/"," ",$line);
			$line = $linepre.$line;
		} else {
			$linepre = "";
		}
		list($name,$value) = split(":",$line,2);
		$linepre = $line;
		$name = trim(strtolower($name));
		$value = trim($value);
		
		// �޳����õ���Ϣ
		if( $name!='' && $HeaderField[$name] ) $header["$name"] = $value;
		
		//�����������͵� content-type ������� charset / boundary
		if($name=='content-type') $header = SplitSubType($header,$name);
	}

	$header['from'] = Decode_mime($header['from']);
	$header['to'] = Decode_mime($header['to']);
	$header['subject'] = Decode_mime($header['subject']);

	//���� from ��ʽ����֮Ϊ FromName FromEmail
	list($name,$from) = split("<",$header['from'],2);
	$name = TrimQuota($name);
	if ( $from=="" ) { $from = $name; $name =""; }
	if (substr($from,strlen($from)-1,1)==">") $from = substr($from,0,strlen($from)-1);
	if ( $name=="" ) list($name,) = split('@',$from);
	$header['fromname'] = $name;
	$header['fromemail'] = $from;
	return $header;
}

// �ֽ�ͷ��Ϣ�������� content-type
//
function SplitSubType($header,$name){
	list($newvalue,$value) = split(";",$header["$name"],2);
	$header["$name"] = trim($newvalue);
	$value = trim($value);
	if ( !empty($value) ){
		list($name,$value) = split("=",$value,2);
		$name = trim(strtolower($name));
		$value = trim($value);
	}
	if ( !empty($value) && !empty($name) ){
		list($prevalue,$value) = split(";",$value,2);
		$header["$name"] = TrimQuota($prevalue);
		
		list($name,$value) = split("=",$value,2);
		$name = trim(strtolower($name));
		if( $name!='' )$header["$name"] = TrimQuota($value);
	}
	return $header;
}


// ���������ַ���
function Num2Str($num,$bitlen){
	$mylen = strlen($num);
	$mylen = $bitlen - $mylen; 
	if ( $mylen > 0 ) $num = str_repeat("0",$mylen).$num;
	return $num;
}

//
/*
function Decode_mime($str){
	$result = imap_mime_header_decode($str);
	for($i=0;$i<count($result);$i++) {
		$temp = trim($result[$i]->text);
		if ($temp!=""){
			$out .= $temp;
		}
	}
	return $out;
}
*/

function Decode_mime($Str){
	if( substr_count($Str,'=?')==0 ) return $Str;
	list($Token,$Charset,$Encoding,$Str,$End) = split('\?',$Str,5);
	$End = preg_replace("/^\=/","",$End);
	$Token = preg_replace("/\=/","",$Token);
	$Encoding = strtolower($Encoding);
	switch($Encoding){
		case 'b':
			$Text = trim(base64_decode($Str));
			break;
		case 'q':
			$Text = trim(quoted_printable_decode($Str));
	}
	if( substr_count($End,'=?')!=0 ) $End = Decode_mime($End);
	return $Token.$Text.$End;
}

// 
function Date2stamp($dateStr){
	list($dateStr,$null) = split(',',$dateStr);
	if ($null !="" ) $dateStr = $null;
	$dateStr = trim($dateStr);
	list($day,$month,$year,$time,$gmt ) = split(' ',$dateStr,5);
//	print $day."|".$month."|".$year."|".$time."|".$gmt;
	$month = strtolower($month);
	$monthof = array(	'jan'=>1,
					'feb'=>2,
					'mar'=>3,
					'apr'=>4,
					'may'=>5,
					'jun'=>6,
					'jul'=>7,
					'aug'=>8,
					'sep'=>9,
					'oct'=>10,
					'nov'=>11,
					'dec'=>12);
	$month = $monthof[$month];
	list($hour,$minute,$second) = split(':',$time);
	if ($gmt =="GMT") $gmt = 0;
	$gmt = $gmt /100;
	$hour = $hour - $gmt;
//	print $hour."|".$minute."|".$second;
	return mktime($hour,$minute,$second,$month,$day,$year);
}

// �޳��ַ�����β������
function TrimQuota($str){
	$str = str_replace('"','',$str);
//	$str = str_replace("'",'',$str);
	return trim($str);
}

function ChopQuota2($str){
	if(substr($str,0,1)=='<' && substr($str,strlen($str)-1,1)=='>'){
		$str = substr($str,1,strlen($str)-2);
	}
	return $str;
}

// �����ַ���Ϊָ�����ȣ������޳��������
function TrimStr($string,$length){
	$len = strlen($string);
	if($len <= $length) return $string;
	$checkchar = "";
	for($i=0;$i<$length;$i++){
		$ac = ord($string[$i]);
		if($ac >= 161){
			$checkchar .= chr($ac);
			$checkchar .= chr(ord($string[$i+1]));
			$i++;
		}else{
			$checkchar .= chr($ac);
		}
	}
	return trim($checkchar);
} 

function Date2Str($TimeStamp,$gmt){
	$TimeStamp = $TimeStamp + 60 * 60  * $gmt;
	$date = getdate($TimeStamp);
	$ret[0] = $date['mon']."/".$date['mday']." ".
			$date['hours'].":".$date['minutes'];
	$ret[1] = $date['year']."/".$date['mon']."/".$date['mday']." ".
			$date['hours'].":".$date['minutes'].":".$date['seconds'];
	return $ret;
}

function FormatSize($size){
	if ($size <1024) return $size."B";
	$size = intval($size / 1024)+ 1;
	return $size."KB";
}

// remove the attachment list file
function DelAttach(){
	global $CFG_TEMP,$G_DOMAIN,$G_USERNAME;
	
	$listattachfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_attach";
	if (file_exists($listattachfile)){
/*
		($FD_LIST_ATTACH = fopen($listattachfile,"r")) || die("Error open $listattachfile!");
		while( $buff = chop(fgets($FD_LIST_ATTACH,1024)) ){
			list($name,$size,$type) = split("\t",$buff,3);
			$name = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach/$name";
			if (file_exists($name)) unlink($name);
		}
		fclose($FD_LIST_ATTACH);
*/
		unlink($listattachfile);
	}
	if(!is_dir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach")) return;
	$dir = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach";
	$DIR_HANDLE = opendir($dir);
	if($DIR_HANDLE){
		while (($file = readdir($DIR_HANDLE))!==false) {
    	if($file !="." && $file !="..")
    		unlink("$dir/$file");
		}
		closedir($DIR_HANDLE);
	}
}

// ��� $get_Mailbox �����Ŀɿ��ԣ����������б��ļ���
// ����ֵ��list_mailbox .mailbox

function GetMailboxFolder($Mailbox){

	global	$CFG_MAILBOX, $G_HOME, $CFG_USERBOX_LIST;
		
	if($CFG_MAILBOX[$Mailbox]!='') return array("list_$Mailbox",$CFG_MAILBOX[$Mailbox]);

	if( is_file($CFG_USERBOX_LIST) ){
		($FD_BOXLIST = fopen($CFG_USERBOX_LIST,"r")) || die("Open .box_list error!");
		while ( !feof($FD_BOXLIST) ) {
    		$buffer = fgets($FD_BOXLIST, 128);
    		$buffer = chop($buffer);
    		list($UserBoxName,$UserBox) = split("\t",$buffer);
    		if( $UserBox==$Mailbox ){
    			fclose($FD_BOXLIST);
    			return array("list_$Mailbox",".$Mailbox");
    		}
		}
		fclose($FD_BOXLIST);
	}
}

function bit2qp($string){
	$len = strlen($string);
	$hex = "0123456789ABCDEF";
	$out = "";
	for($i=0;$i<$len;$i++){
		$ac = ord($string[$i]);
		$next = ord($string[$i+1]);
		if( ($ac==015 && $next==012)){
			$out .= "\n";
			$i++;
		}else{
			if($ac==015 || $ac==012) $out .= "\n";
			else 
			if( is_cntrl($ac) || ( $ac==0x7f) || ($ac & 0x80) || ($ac ==0x3D ) ||
			(($ac == ' ') && ($next== 015) )  ){
				$out .= '=';
				$out .= $hex[$ac >> 4];
				$out .= $hex[$ac & 0xf];
			}
			else $out .= chr($ac);
		}
	}
	return $out;
}

function is_cntrl($c){
	if( ( $c>=00 && $c<=037 ) || ($c==0177) ) return true;
	return false;
}

function encode_mime($string,$encoding,$charset){

	switch($encoding){
		case 'quoted-printable':
			return "=?".$charset."?Q?".bit2qp($string)."?=";
			break;
				
		case 'base64':
			return "=?".$charset."?B?".base64_encode($string)."?=";
			break;
		default:
			return $string;
	}
}

} // End of INCLUDE_FUN_OK
?>