<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: prev_inc.php,v 1.4 2003/01/15 02:36:00 wuqiong Exp $
 */

/* body list file format:
 * filename  content-type/MIME-type  size disposition(NULL) content-id(NULL) content-location(NULL)
 */

function Decode_multipart($FD_MAIL,$FD_BODYLIST,$Boundary, $Content_Type){

	global $CFG_TEMP, $G_DOMAIN, $G_USERNAME;

	// seek the first Boundary
	$PartEnd = 0;
	while( $line=fgets($FD_MAIL,256) ){
		if(trim($line) == "--".$Boundary ) break;
		if(trim($line) == "--".$Boundary."--") break;
	}
	$i = 0;
	do {
		$alternative = 0;
		$PartHeader = Parse_head($FD_MAIL);
//		print_r($PartHeader);		
		// ȡ�ļ������ַ
		$filename = $PartHeader['name'];
		if(empty($filename)) $filename = $PartHeader['filename'];
		if(empty($filename)) $filename = $PartHeader['content-location'];
		
		//ȡid
		if(!empty($PartHeader['content-id'])) $content_id = $PartHeader['content-id'];

		if( empty($filename)) {
			$filename = "unknown";
//			if ($i !=0) $filename .= $i;
			$PartHeader["content-type"] = strtolower($PartHeader["content-type"]);
		
			switch( $PartHeader["content-type"] ){

				case 'text/html':
					$filename .= '.html';
					break;
					
				case "multipart/mixed":
				case "multipart/related":
				case "multipart/alternative":
				case "multipart/report":
					Decode_alternative($FD_MAIL,$FD_BODYLIST,$PartHeader['boundary'],$PartHeader['content-type']);
//					Decode_multipart($FD_MAIL,$FD_BODYLIST,$PartHeader['boundary'],$PartHeader['content-type']);
					$alternative = 1;
					// skip to next Boundary
					while( $line=fgets($FD_MAIL,2048) ){
						if(trim($line) == "--".$Boundary ) break;
						if(trim($line) == "--".$Boundary."--") break;
					}
					break;
					
				case "":
				case 'text/plain':
				default:
					$filename .= '.txt';
					break;
			}
		}

		if( substr_count($filename,"\\" ) != 0){
			$pos = strrpos($filename,"\\");
			$filename = substr($filename,$pos+1);
		}
		if( substr_count($filename,"\/" ) != 0){
			$pos = strrpos($filename,"\/");
			$filename = substr($filename,$pos+1);
		}

		// if not multipart/alternative etc. type
		if(!$alternative){
			if(!empty($PartHeader['content-disposition']) ) $Disposition = $PartHeader['content-disposition'];
			if(!empty($PartHeader['content-location']) ) $Location = $PartHeader['content-location'];
			list($Size,$PartEnd,$filename) = Decode_part($FD_MAIL,$filename,$PartHeader["content-transfer-encoding"],$Boundary);

			$listStr = $filename."\t".$PartHeader['content-type']."\t".$Size."\t".$Disposition."\t".$content_id."\t".$Location."\n";
			fputs($FD_BODYLIST,$listStr);
		}
		$i++;
		
	} while (!feof($FD_MAIL) && $PartEnd!=1);
}

function Decode_alternative($FD_MAIL,$FD_BODYLIST,$Boundary, $Content_Type){

	global $CFG_TEMP, $G_DOMAIN, $G_USERNAME;

	// seek the first Boundary
	while( $line=fgets($FD_MAIL,2048) ){
		if( trim($line) == "--".$Boundary ) break;
		if( trim($line) == "--".$Boundary."--") return;
	}
	$i = 0;
	$PartEnd = 0;
	do {
		$i++;
		$PartHeader = Parse_head($FD_MAIL);

		if ( feof($FD_MAIL) || empty($PartHeader['content-type']) ) break;
		$PartHeader['content-type'] = strtolower($PartHeader['content-type']);
		$Content_Transfer_Encoding = $PartHeader['content-transfer-encoding'];
		
		switch($PartHeader['content-type']){
			case "multipart/alternative":
				
				Decode_alternative($FD_MAIL,$FD_BODYLIST,$PartHeader['boundary'], "multipart/alternative");
				break;
			case "text/html":
				$file = "unknown.html";
				break;
			case "":
			case "text/plain":
			default:
				$file = "unknown.txt";
		}
		
		if($PartHeader['name']!="") $file = $PartHeader['name'];
		if($PartHeader['filename']!="") $file = $PartHeader['filename'];
//		print_r($PartHeader);
		list($Size,$PartEnd,$file) = Decode_part($FD_MAIL,$file,$Content_Transfer_Encoding,$Boundary);
		
		$listStr = $file."\t".$PartHeader['content-type']."\t".$Size."\t".$Disposition."\t".$PartHeader['content-id']."\t".$PartHeader['content-location']."\n";
		fputs($FD_BODYLIST,$listStr);

	} while (!feof($FD_MAIL) && $PartEnd !=1);
}


function Decode_part($FD_MAIL,$file,$Content_Transfer_Encoding,$Boundary){
	global $CFG_TEMP, $G_DOMAIN, $G_USERNAME;

	$PartEnd = 0;
	$filename = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$file";
	$i = 0;
	list($base,$ext) = split("\.",$file);
	while(file_exists($filename)){
		$i++;
		$file = $base.$i.".".$ext;
		$filename = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$file";
	}
	$FD_BODY = @fopen("$filename","w");
	if(!$FD_BODY) return;
	$buff = "";
	switch($Content_Transfer_Encoding){
		case "quoted-printable":
			while( $line=fgets($FD_MAIL,2048) ){
				if( trim($line) == "--".$Boundary ) break;
				if( trim($line) == "--".$Boundary."--" ){
					$PartEnd = 1;
					break;
				}
				$buff .= $line;
			}
			$buff = quoted_printable_decode($buff);
			fwrite($FD_BODY,$buff);
			$Size = strlen($buff);
			break;
					
		case "base64":
			while( $line=fgets($FD_MAIL,2048) ){
				if( trim($line) == "--".$Boundary ) break;
				if( trim($line) == "--".$Boundary."--" ){
					$PartEnd = 1;
					break;
				}
				$buff .= base64_decode($line);
			}
			fwrite($FD_BODY,$buff);
			$Size = strlen($buff);

		break;

		case "binary":
		case "8bit":
		case "":
		default:
			while( $line=fgets($FD_MAIL,2048) ){
				if( trim($line) == "--".$Boundary ) break;
				if( trim($line) == "--".$Boundary."--" ){
					$PartEnd = 1;
					break;
				}
				$buff .= $line;
			}
			fwrite($FD_BODY,$buff);
			$Size = strlen($buff);
	}
	fclose($FD_BODY);
	$ret[0] = $Size;
	$ret[1] = $PartEnd;
	$ret[2] = $file;
	return $ret;
}

// ������ı���ʽ
function Decode_text($FD_MAIL,$FD_BODYLIST,$file,$Content_Transfer_Encoding,$Content_Type){
	global $CFG_TEMP, $G_DOMAIN, $G_USERNAME;
	
	$FD_BODY = fopen("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$file","w");
	$buff = "";
	switch($Content_Transfer_Encoding){
		case "quoted-printable":
			while( ($line = fgets($FD_MAIL,2048)) && !feof($FD_MAIL)){
				$line = quoted_printable_decode($line);
				$buff .= $line;
			}
			break;
					
		case "base64":
			while( ($line = fgets($FD_MAIL,2048)) && !feof($FD_MAIL)){
				$line = base64_decode($line);
				$buff .= $line;
			}
		break;
						
		case "binary":
		case "8bit":
		case "":
		default:
			while( ($line = fgets($FD_MAIL,2048)) && !feof($FD_MAIL)){
				$buff .= $line;
			}
	}
	$Size = strlen($buff);
	fwrite($FD_BODY,$buff);
	fclose($FD_BODY);

	$listStr = $file."\t".$Content_Type."\t".$Size."\t".$Disposition."\t".$content_id."\t".$Location."\n";
	fputs($FD_BODYLIST,$listStr);
}

function RemoveBody($bodylistfile){
	global	$CFG_TEMP,$G_DOMAIN,$G_USERNAME;
	
	if (file_exists($bodylistfile)){
		($FD_BODYLIST = fopen("$bodylistfile","r"))	|| die("Error open body list file");
		$line = fgets($FD_BODYLIST,1024);
		while( ($line = fgets($FD_BODYLIST,1024)) && !feof($FD_BODYLIST)){
			list($filename,$type,$size,$disposition,$id,$location) = split("\t",$line,6);
			$filename = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$filename";
			if (file_exists($filename)) @unlink($filename);
		}
		fclose($FD_BODYLIST);
	}
}
?>