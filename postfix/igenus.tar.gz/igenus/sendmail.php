<?php
/*-
 * iGENUS webmail
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: sendmail.php,v 1.16 2003/02/14 02:05:35 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
include "include/send_fun.php";

// post
$post_To = trim($HTTP_POST_VARS['To']);
$post_Cc = trim($HTTP_POST_VARS['Cc']);
$post_Bcc = trim($HTTP_POST_VARS['Bcc']);
$post_Subject = trim($HTTP_POST_VARS['Subject']);
$post_ReplyTo = trim($HTTP_POST_VARS['ReplyTo']);

$post_Backup = trim($HTTP_POST_VARS['Backup']);
$post_Sign = trim($HTTP_POST_VARS['Sign']);
$post_Body = trim($HTTP_POST_VARS['Body']);
$post_Priority = trim($HTTP_POST_VARS['Priority']);

//get
$get_Cmd = trim($HTTP_GET_VARS['Cmd']);

$Charset = $CFG_CHARSET[$CFG_Send_Charset];

// ȡ�û�ǩ��
if($post_Sign!=0 && is_file($CFG_USERSIGN) ){
	($FD_CFG = fopen($CFG_USERSIGN,"r")) || die("���û�ǩ���ļ�ʧ�ܣ�");
	$i = 1;
	$SignArray = array();
	while(!feof($FD_CFG)){
		$line = trim(fgets($FD_CFG,512));
		if( $line!='# -end-' ){
			$SignArray[$i].= $line."\n";
			continue;
		}
		$i++;
	}
	fclose($FD_CFG);
	$HtmlSign = preg_replace("/\n/","<BR>\n",$SignArray[$post_Sign]);
	$TextSign = $SignArray[$post_Sign];
	$TextSign = preg_replace ("/(<\/?)(\w+)([^>]*>)/e", "",$TextSign);
}

if($get_Cmd!='Backup' && $get_Cmd!='Draft') $get_Cmd = '';


$Html_body = $post_Body;
$Html_body = preg_replace("/(ftp:\/\/[\w|\.|\/|\?|\%|\&|\=|\-|\;|\,|\+|\~]+)/i","<A href=$1 target=_blank>$1</A>",$Html_body);
$Html_body = preg_replace("/(http:\/\/[\w|\.|\/|\?|\%|\&|\=|\-|\;|\,|\+|\~]+)/i","<A href=$1 target=_blank>$1</A>",$Html_body);
$Html_body = preg_replace("/([\w|\.|\-]+@[\w|\-|\.]+\.[a-z]+)/i","<A href=mailto:$1>$1</A>",$Html_body);
$Html_body = eregi_replace("\n","<BR>\n",$Html_body);
$Html_body = eregi_replace("> ","</FONT><FONT color=#444444>> ",$Html_body);

$Htmlbody = "<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=$Charset'>
<STYLE TYPE='TEXT/CSS'>
<!--
body { color:#5A8C52; font-size: 12px; line-height: 120%}
.mybody { color:#000000; font-size: 14px; line-height: 150%}
.sign { color:#cccccc; font-size: 12px; line-height: 120%}
-->
</STYLE>
</HEAD>
<BODY BGCOLOR='#FFFFFF' TEXT='#000000'>
<TABLE WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
	<TR>
	<TD class='mybody'>$Html_body</TD>
	</TR>
</TABLE>
<BR>
----
<BR>
$HtmlSign
<BR>
$CFG_HTML_SIGN
</BODY>
</HTML>";

$Htmlbody_NoSign = "<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=$Charset'>
<STYLE TYPE='TEXT/CSS'>
<!--
body { color:#5A8C52; font-size: 12px; line-height: 120%}
.mybody {  color:#000000; font-size: 14px; line-height: 150%}
.sign { color:#555555; font-size: 12px; line-height: 120%}
-->
</STYLE>
</HEAD>
<BODY BGCOLOR='#FFFFFF' TEXT='#000000'>
<TABLE WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
	<TR>
	<TD class='mybody'>$Html_body</TD>
	</TR>
</TABLE>
</BODY>
</HTML>";

$TextBody = $post_Body . "\n\n----\n" . $TextSign ."\n".$CFG_PAIN_SIGN;

$TextBody_NoSign = $post_Body;

$tempdir = ("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/");
chdir($tempdir);
$listattachfile = "list_attach";
if (file_exists($listattachfile)){
	($FD_LIST_ATTACH = fopen($listattachfile,"r")) || die("Error open $listattachfile!");
	while( $buff = trim(fgets($FD_LIST_ATTACH,1024)) ){
		list($name,$size,$type) = split("\t",$buff,3);
		$Attach .= $tempdir."attach/$name,";
	}
	fclose($FD_LIST_ATTACH);
	$Attach = substr( $Attach,0,strlen($Attach)-1 );
}

$Mail = new Email;
$Mail->setEncoding($CFG_Send_Encoding);	//quoted-printable base64
$Mail->setCharset($Charset);
$Mail->setFrom("$G_USERNAME@$G_DOMAIN");
$Mail->setTo($post_To);
$Mail->setCC($post_Cc);
$Mail->setBCC($post_Bcc);
$Mail->setSubject($post_Subject);

switch($CFG_Send_ContentType){
	default:
	case 'Alternative':
		$Mail->setText($TextBody);
		$Mail->setHTML($Htmlbody);
		break;	
	case 'Plain':
		$Mail->setText($TextBody);
		break;
	case 'Html':
		$Mail->setHTML($Htmlbody);
}

$Mail->setPriority($post_Priority);
$Mail->setAttachments($Attach);

$MailBack = new Email;
$MailBack->setEncoding($CFG_Send_Encoding);	//quoted-printable base64
$MailBack->setCharset($Charset);
$MailBack->setFrom("$G_USERNAME@$G_DOMAIN");
$MailBack->setTo($post_To);
$MailBack->setCC($post_Cc);
$MailBack->setBCC($post_Bcc);
$MailBack->setSubject($post_Subject);

switch($CFG_Send_ContentType){
	default:
	case 'Alternative':
		$MailBack->setText($TextBody_NoSign);
		$MailBack->setHTML($Htmlbody_NoSign);
		break;	
	case 'Plain':
		$MailBack->setText($TextBody_NoSign);
		break;
	case 'Html':
		$MailBack->setHTML($Htmlbody_NoSign);
}

$MailBack->setPriority($post_Priority);
$MailBack->setAttachments($Attach);

switch($get_Cmd){
	case 'Backup':
	$Path = $get_Cmd.'.'.time().".localhost";
	$Path = $G_HOME.$CFG_MAILBOX['outbox']."/new/" . $Path;
	$MailBack->send('Backup',$Path);
	$Mail->send('','');
	break;
	
	case 'Draft':
	$Path = $get_Cmd.'.'.time().".localhost";
	$Path = "$G_HOME".$CFG_MAILBOX['draft']."/new/" . $Path;
	$MailBack->send('Backup',$Path);
	break;
	
	case '':
	default:
	$Mail->send("","");
}
DelAttach();
header("Location: sendok.php?MailTo=$post_To&Cmd=$get_Cmd");
?>
