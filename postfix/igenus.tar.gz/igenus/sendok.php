<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: sendok.php,v 1.4 2003/01/15 08:16:00 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
include "adv.php";

//get 
$get_Cmd = trim($HTTP_GET_VARS['Cmd']);
$get_MailTo = trim($HTTP_GET_VARS['MailTO']);

if($get_Cmd=='Draft') $Meg = $LANG_DRAFTOK_OK;
else $Meg = $LANG_SENDOK_OK;
?>
<HTML>
<HEAD>
<TITLE>send</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000">
<P>&nbsp;</P>
<TABLE WIDTH="366" cellspacing cellpadding HEIGHT="0" ALIGN="CENTER">
  <TR> 
    <TD WIDTH="100%"><IMG BORDER="0" SRC="images/mailphoto1.gif" WIDTH="139" HEIGHT="149"><IMG BORDER="0" SRC="images/mailphoto2.gif" WIDTH="125" HEIGHT="149"><IMG BORDER="0" SRC="images/mailphoto3.gif" WIDTH="102" HEIGHT="149"></TD>
  </TR>
  <TR> 
    <TD WIDTH="100%" BACKGROUND="images/mailphoto4.gif" HEIGHT="50">�� 
      <P ALIGN="CENTER">
        <?php echo $Meg;?>
      </P>
      <P ALIGN="CENTER"><A HREF="mailbox.php"><?php echo $LANG_SENDOK_BACK;?></A></P>
      </TD>
  </TR>
  <TR> 
    <TD WIDTH="100%"><IMG BORDER="0" SRC="images/mailphoto5.gif" WIDTH="366" HEIGHT="18"></TD>
  </TR>
</TABLE>
<P ALIGN="CENTER" STYLE='font-family:Tahoma'>&copy;1999-2001 Copyright by <A HREF="http://www.igenus.org/" TARGET="_parent"><B>iGENUS 
  Org.</B></A></P>
</BODY>
</HTML>