<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: mailbox.php,v 1.13 2003/01/21 02:59:31 wuqiong Exp $
 */
$DEBUG = 1;
if($DEBUG) $timebegin = gettimeofday();
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

$BOX_LIST = "$G_HOME/.box_list";

//get
$get_Cmd = $HTTP_GET_VARS['Cmd'];
$get_folder = $HTTP_GET_VARS['folder'];

//post
$post_mailbox = trim($HTTP_POST_VARS['mailbox']);
$post_oldboxname = trim($HTTP_POST_VARS['oldboxname']);

if (!(is_dir($CFG_TEMP))){
	mkdir($CFG_TEMP,$CFG_TEMP_MOD)||die("Error create directory $CFG_TEMP");
}
chdir($CFG_TEMP);

if (!(is_dir($G_DOMAIN))) { 
	mkdir($G_DOMAIN,$CFG_TEMP_MOD)||die("Error create directory $G_DOMAIN");
}
chdir($G_DOMAIN);
if (!(is_dir($G_USERNAME))) {
	mkdir($G_USERNAME,$CFG_TEMP_MOD)||die("Error create directory $G_USERNAME");
}
chdir($G_USERNAME);

// Create Mailbox

if( $get_Cmd=='Create'){
	if ($post_mailbox=='') header("Location: index.php");
	$foldername = time();
	$Mailbox = ".".$foldername;
	if(!is_dir("$G_HOME$Mailbox")){
		mkdir("$G_HOME$Mailbox",0700);
		mkdir("$G_HOME$Mailbox/new",0700);
		mkdir("$G_HOME$Mailbox/cur",0700);
		mkdir("$G_HOME$Mailbox/tmp",0700);
	
	($FD_BOXLIST = fopen("$BOX_LIST","a+")) || die("Error open .box_list!");
	fputs( $FD_BOXLIST,"$post_mailbox\t$foldername\n" );
	fclose($FD_BOXLIST);
	}
	header("Location: index.php");
}

// Delete Mailbox

if( $get_Cmd=='Delete' && $get_folder!='' ){
	$Mailbox = ".$get_folder";
	if(is_dir("$G_HOME$Mailbox/new")) rmdir("$G_HOME$Mailbox/new");
	if(is_dir("$G_HOME$Mailbox/cur")) rmdir("$G_HOME$Mailbox/cur");
	if(is_dir("$G_HOME$Mailbox/tmp")) rmdir("$G_HOME$Mailbox/tmp");
	if(is_dir("$G_HOME$Mailbox")) rmdir("$G_HOME$Mailbox");	

	$buffer = '';
	($FD_BOXLIST = fopen("$BOX_LIST","r")) || die("Error open .box_list!");
	while ( !feof($FD_BOXLIST) ){
    	$boxname = chop(fgets($FD_BOXLIST, 128));
    	list($foldername,$boxname) = split("\t",$boxname);
		if( $boxname!=$get_folder && $boxname!='' ) $buffer .= "$foldername\t$boxname\n";
	}
	fclose($FD_BOXLIST);
	($FD_BOXLIST = fopen("$BOX_LIST","w")) || die("Error open .box_list!");
	fputs($FD_BOXLIST,$buffer);
	fclose($FD_BOXLIST);
	header("Location: index.php");
}

// Rename Mailbox

if( $get_Cmd=='Rename' && $post_mailbox!='' ){

	$buffer = '';
	($FD_BOXLIST = fopen("$BOX_LIST","r")) || die("Error open .box_list!");
	while ( !feof($FD_BOXLIST) ){
    	$boxname = chop(fgets($FD_BOXLIST, 128));
    	list($foldername,$boxname) = split("\t",$boxname);
		if( $boxname==$post_oldboxname && $boxname!='' ) $buffer .= "$post_mailbox\t$boxname\n";
		else $buffer .= "$foldername\t$boxname\n";
	}
	fclose($FD_BOXLIST);
	($FD_BOXLIST = fopen("$BOX_LIST","w")) || die("Error open .box_list!");
	fputs($FD_BOXLIST,$buffer);
	fclose($FD_BOXLIST);
	header("Location: index.php");
}

// Clear trash

if( $get_Cmd=='ClearTrash'){

	$Mailbox=".Trash";
		
	$home = $G_HOME.$Mailbox."/new";
	$handle=opendir($home);

	while (($file = readdir($handle))!==false) {
    	if ($file !='.' && $file !='..' && is_file("$home/$file"))
    		unlink("$home/$file");
	}
	closedir($handle); 

	$home = $G_HOME.$Mailbox."/cur";
	$handle=opendir($home);

	while (($file = readdir($handle))!==false) {
    	if ($file !='.' && $file !='..' && is_file("$home/$file"))
    		unlink("$home/$file");
	}
	closedir($handle);
	header("Location: index.php");
}

// main

$TotalMail = 0;
$TotalNew = 0;
$TotalSize = 0;
$List_Out = '';
foreach ( $CFG_MAILBOX as $key => $value ) {
	list( $Mail,$NewMail,$Size ) = MailboxInfo($CFG_MAILBOX[$key]);
	$Size = floor(round($Size/1024));
	$List_Out .= "<TR ALIGN='CENTER'>\n";
	$List_Out .= "\t<TD><A href='list.php?Mailbox=$key&Cmd=Refresh' tagert='main'>$LANG_MAILBOX_NAME[$key]</A></TD>\n";
	$List_Out .= "\t<TD>$Mail</TD>\n";
	$List_Out .= "\t<TD>$NewMail</TD>\n";
	$List_Out .= "\t<TD>$Size</TD>\n";
	//��ʾ�����������
	if($key=='trash'&& $Size!=0) $List_Out .= "\t<TD><A href=# onClick='ClearTrash(document.CreateMailbox);return false' target=_top ><IMG src='images/trash.gif' border=0 ALT='���������'></A></TD>\n";
	else $List_Out .= "\t<TD>&nbsp;</TD>\n";
	$List_Out .= "</TR>\n";
	
	$TotalMail += $Mail;
	$TotalNew += $NewMail;
	$TotalSize += $Size;
}

//ͳ���û��Զ�������

if( is_file("$BOX_LIST") ){
	($FD_BOXLIST = fopen("$BOX_LIST","r")) || die("Error open .box_list!");
	while ( !feof($FD_BOXLIST) ) {
    	$buffer = fgets($FD_BOXLIST, 128);
    	$buffer = chop($buffer);
    	list($foldername,$Mailbox) = split("\t",$buffer);
       	if( $Mailbox!='' && $foldername!='' ){
	   		list($Mail,$NewMail,$Size) = MailboxInfo(".$Mailbox");
			$Size = floor(round($Size/1024));
			$My_Out .= "<TR ALIGN='CENTER'>\n";
			$My_Out .= "\t<TD><A href='list.php?Mailbox=$Mailbox&Cmd=Refresh' tagert='main'>$foldername</A></TD>\n";
			$My_Out .= "\t<TD>$Mail</TD>\n";
			$My_Out .= "\t<TD>$NewMail</TD>\n";
			$My_Out .= "\t<TD>$Size</TD>\n";
			if($Size!=0) $My_Out .= "\t<TD>&nbsp;</TD>\n";
			else $My_Out .= "\t<TD><A href='mailbox.php?Cmd=Delete&folder=$Mailbox' target=_top><IMG src='images/trash.gif' border=0></A></TD>\n";
			$My_Out .= "</TR>\n";
	
			$TotalMail += $Mail;
			$TotalNew += $NewMail;
			$TotalSize += $Size;
		}
	}
	fclose($FD_BOXLIST);
}

//ͳ���ܵ�����������

$MQuota = intval($G_QUOTA/(1024*1024)*10)/10;
$MTotalSize = intval($TotalSize/1024*10)/10;
if( $TotalSize%1024>0 ) $MTotalSize += 0.1;

//ȡ�û���������
$UserFolder_Out = '';
if( is_file("$BOX_LIST") ){
	($FD_BOXLIST = fopen("$BOX_LIST","r")) || die("Error open .box_list!");
	while ( !feof($FD_BOXLIST) ) {
    	$buffer = fgets($FD_BOXLIST, 128);
    	$buffer = chop($buffer);
    	list($foldername,$Mailbox) = split("\t",$buffer);
       	if( $Mailbox!='' && $foldername!='' ){
          	$UserFolder_Out .= "<OPTION VALUE='$Mailbox'>$foldername</OPTION>\n";
		}
	}
	fclose($FD_BOXLIST);
}

// exit

function MailboxInfo($Mailbox){
	global	$CFG_MAILBOX, $CFG_LIST, $G_HOME,$CFG_SIZEPERSECTOR;
	
	$TotalSize = 0;
	$list = array();
	$Newfile = 0;
	if(!is_dir("$G_HOME$Mailbox")){
		mkdir("$G_HOME$Mailbox",0700);
		mkdir("$G_HOME$Mailbox/new",0700);
		mkdir("$G_HOME$Mailbox/cur",0700);
		mkdir("$G_HOME$Mailbox/tmp",0700);
	}

	// �����ʼ��嵥
	$home = $G_HOME.$Mailbox."/new";
#echo $home."<br>";
	$handle=opendir($home);
	$i = 0;
	while (($file = readdir($handle))!==false) {
    	if ($file !='.' && $file !='..'){
		$Stat = stat($home."/".$file);
//		$TotalSize += $Stat[blocks]/2;
//		$TotalSize += floor(round($Stat[size]/1024));
		$TotalSize += $Stat[size];
//		$TotalSize += filesize($home."/".$file)/1024;
// echo $file.":".$TotalSize."<br>";
    		$i ++;
    	}
	}
	closedir($handle); 
	$Newfile = $i;

	$home = $G_HOME.$Mailbox."/cur";
	$handle=opendir($home);

	while (($file = readdir($handle))!==false) {
    	if ($file !='.' && $file !='..'){
		$Stat = stat($home."/".$file);
//		echo $Stat[blocks]/2;
//		$TotalSize += $Stat[blocks]/2;
                $TotalSize += $Stat[size];
//		$TotalSize += floor(round($Stat[size]/1024));
//                $TotalSize += filesize($home."/".$file)/1024;
    		$i ++;
    	}
	}
	closedir($handle);
	$totalmail = $i;
	
	return array($totalmail,$Newfile,$TotalSize);
}

include "$CFG_BASEPATH/adv.php";
?>
<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=<?php echo $CFG_CHARSET[$CFG_LANGUAGE];?>">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LEFTMARGIN="0" TOPMARGIN="0">
<TABLE WIDTH="100%" cellspacing cellpadding HEIGHT="24">
  <TR> 
    <TD WIDTH="100%" ALIGN="center" VALIGN="top" BGCOLOR="#000000"> 
      <TABLE WIDTH="100%" HEIGHT="22" cellspacing cellpadding>
        <FORM NAME="head" METHOD=post>
          <TR BGCOLOR="#5A8C52" STYLE="color: #FFFFFF;" ALIGN="center"> 
            <TD> </TD>
          </TR>
        </FORM>
      </TABLE>
    </TD>
  </TR>
</TABLE>
<BR>
<SCRIPT>
<!--
var Alert_Invid_Mailbox = "<?php echo $LANG_MAILBOX_INVALID_BOXNAME;?>";	//��Ч���������ƣ�
var Confirm_Create = "<?php echo $LANG_MAILBOX_CONFIRM_CREATE;?> ";			//�½�
var Confirm_Continue = " <?php echo $LANG_MAILBOX_CONFIRM_CONTINUE;?>";		//����,������?
var Alert_Select_mailbox = "<?php echo $LANG_MAILBOX_ALERT_SELECT;?>";	//��ѡ���û��Զ����������ƣ�
var Alert_Mailbox_NewName = "<?php echo $LANG_MAILBOX_ALERT_NEWNAME;?>";	//���������������ƣ�
var Confirm_Mailbox_ReName = "<?php echo $LANG_MAILBOX_CONFIRM_RENAME;?> ";	//��
var Confirm_Mailbox_To = " <?php echo $LANG_MAILBOX_CONFIRM_TO;?> ";		//����Ϊ
var Confirm_Mailbox_CLEAR = " <?php echo $LANG_MAILBOX_CONFIRM_CLEAR;?> ";		//����������գ�������?

function Create(form){
	mailbox = form.mailbox.value;
	if(mailbox==''){
		alert(Alert_Invid_Mailbox);
		return false;
	}
	if(!confirm(Confirm_Create + mailbox + Confirm_Continue))return false;
	form.action = "?Cmd=Create";
	form.target="_top";
	form.submit();
}

function Rename(form){
	mailbox = form.mailbox.value;
	oldbox = form.oldboxname.options[form.oldboxname.selectedIndex].text;
	if(form.oldboxname.value==''){
		alert(Alert_Select_mailbox);
		return false;
	}	
	if(mailbox==''){
		alert(Alert_Mailbox_NewName);
		form.mailbox.focus();
		return false;
	}
	if(!confirm(Confirm_Mailbox_ReName + oldbox + Confirm_Mailbox_To + mailbox+ Confirm_Continue )) return false;
	form.action = "?Cmd=Rename";
	form.target="_top";
	form.submit();
}

function ClearTrash(form){
	if(!confirm(Confirm_Mailbox_CLEAR)) return false;
	form.action = "?Cmd=ClearTrash";
	form.target="_top";
	form.submit();	
}
//-->
</SCRIPT>
<TABLE WIDTH="95%" BORDER="0" ALIGN="CENTER">
  <TR> 
    <TD WIDTH="62%">
    <?php if($MQuota>0){?>
    <P><B><?php echo $LANG_MAILBOX_QUOTA;?>: </B><?php echo $MQuota;?>MB <B>
    <?php echo $LANG_MAILBOX_USED;?>: </B><?php echo $MTotalSize;?>MB <B>
    <?php echo $LANG_MAILBOX_REMAIN;?>: </B><?php echo $MQuota-$MTotalSize;?>MB</P>
    <?php }?>
      <TABLE WIDTH="90%" BORDER="0" CELLPADDING="0" CELLSPACING="0" ALIGN="CENTER">
        <TR> 
          <TD BGCOLOR="#FFFFFF" WIDTH="3%"><B><?php echo intval($MTotalSize/$MQuota*100)."%";?></B></TD>
          <TD BGCOLOR="#D0E6CE" WIDTH="93%"> 
            <TABLE WIDTH="<?php echo intval($MTotalSize/$MQuota*100)."%";?>" BORDER="0" CELLPADDING="0" CELLSPACING="0">
              <TR> 
                <TD HEIGHT=20 BGCOLOR="#FF0000"></TD>
              </TR>
            </TABLE>
          </TD>
          <TD BGCOLOR="#FFFFFF" WIDTH="4%">
            <DIV ALIGN="RIGHT"><B>100%</B></DIV>
          </TD>
        </TR>
      </TABLE>
      <P>&nbsp;</P>
    </TD>
  </TR>
  <TR> 
    <TD WIDTH="62%"> 
      <TABLE BORDER="1" CELLSPACING="0" CELLPADDING="2" BGCOLOR="#EAF3E9" BORDERCOLOR="#FFFFFF" WIDTH="98%" ALIGN="CENTER">
        <TR ALIGN="CENTER" BGCOLOR="#D0E6CE"> 
          <TD WIDTH="22%" HEIGHT="22"><B><?php echo $LANG_MAILBOX_SYSTEM;?></B></TD>
          <TD WIDTH="23%"><B><?php echo $LANG_LIST_TOTAL;?></B></TD>
          <TD WIDTH="23%"><B><?php echo $LANG_LIST_NEWMAIL;?></B></TD>
          <TD WIDTH="22%"><B><?php echo $LANG_MAILBOX_SIZE;?> (KB)</B></TD>
          <TD WIDTH="10%"><B><?php echo $LANG_MAILBOX_DELETE;?></B></TD>
        </TR>
        <?php echo $List_Out;?>
        <TR ALIGN="CENTER" BGCOLOR="#D0E6CE"> 
          <TD WIDTH="22%" HEIGHT="22"><B><?php echo $LANG_MAILBOX_PRIVATE;?></B></TD>
          <TD WIDTH="23%"><B><?php echo $LANG_LIST_TOTAL;?></B></TD>
          <TD WIDTH="23%"><B><?php echo $LANG_LIST_NEWMAIL;?></B></TD>
          <TD WIDTH="22%"><B><?php echo $LANG_MAILBOX_SIZE;?> (KB)</B></TD>
          <TD WIDTH="10%">&nbsp;</TD>
        </TR>
        <?php echo $My_Out;?>
        <TR ALIGN="CENTER" BGCOLOR="#D0E6CE"> 
          <TD WIDTH="22%" HEIGHT="22"><B><?php echo $LANG_MAILBOX_TOTAL_ALL;?></B></TD>
          <TD WIDTH="23%"> 
            <?php echo $TotalMail;?>
          </TD>
          <TD WIDTH="23%"> 
            <?php echo $TotalNew;?>
          </TD>
          <TD WIDTH="22%"> 
            <?php echo $TotalSize;?>
          </TD>
          <TD WIDTH="10%">&nbsp;</TD>
        </TR>
      </TABLE>
    </TD>
  </TR>
  <TR> 
    <TD WIDTH="62%" ALIGN="CENTER"> 
      <FORM NAME="CreateMailbox" METHOD="post" ACTION="" onSubmit="return false;">
        <SELECT NAME="oldboxname" CLASS="myselect" <?php if(empty($UserFolder_Out)) echo "Disabled";?>>
		<OPTION VALUE=''><?php echo $LANG_MAILBOX_SELECT;?></OPTION>
		<OPTION VALUE=''>-</OPTION>
		<?php echo $UserFolder_Out;?>
        </SELECT>
        <INPUT TYPE="BUTTON" VALUE="<?php echo $LANG_MAILBOX_RENAME;?>-&gt;" CLASS="myinput" onClick="Rename(this.form);return false;" <?php if(empty($UserFolder_Out)) echo "Disabled";?>>
        <INPUT TYPE="text" NAME="mailbox" SIZE="10" MAXLENGTH="10" CLASS="myinput2">
        <INPUT TYPE="button" VALUE="<?php echo $LANG_MAILBOX_CREATE;?>" CLASS="myinput" onClick="Create(this.form);return false;">
      </FORM>
    </TD>
  </TR>
</TABLE>
<?php
if ($DEBUG){
	$timeend = gettimeofday();
	$time = $timeend['sec'] - $timebegin['sec'];
	$time3 = $time + ($timeend['usec']-$timebegin['usec'])/1000000;
	echo "<CENTER><FONT color=#EEEEEE>"."Refresh Time:$time3"."</FONT></CENTER>";
}
?>
</BODY>
</HTML>
