<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: mime.php,v 1.8 2003/05/16 00:36:29 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";

//get
$get_File = $HTTP_GET_VARS['File'];
$get_MimeType = $HTTP_GET_VARS['MimeType'];
$get_Size = $HTTP_GET_VARS['Size'];
$get_Cmd = $HTTP_GET_VARS['Cmd']; 

$get_File = basename(trim($get_File));      // �������ܴ��ڵİ�ȫ������

if ($get_Cmd=="Show"){
	$file = $File;
	$filename = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$get_File";
	($FD_ATTACH = fopen($filename,"r"))	|| die("Error open !filename");
	
	if(substr_count($file,'.pif') || substr_count($file,'.exe') || substr_count($file,'.scr') ||
		substr_count($file,'.com') || substr_count($file,'.bat') ){
		$buff = "<Script>\n";
		$buff .= "alert('���棺���ʼ��п���Я���в�������')\n";
		$buff .= "</Script>";
		echo $buff;
		exit();
	}

	$buff = "";
	while($line = fread($FD_ATTACH,4096)){
		
		$buff .= $line;
	}
	fclose($FD_ATTACH);
	
	header("Content-type: $get_MimeType; nmae=\"$File\"\n");
	header("Content-Disposition: filename=\"$get_File\"\n\n");
	echo $buff;
	exit();
}

if ($get_Cmd=="Download"){
	$filename = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$get_File";
	($FD_ATTACH = fopen($filename,"r"))	|| die("Error open !filename");

	$buff = "";
	while($line = fread($FD_ATTACH,4096)){
		
		$buff .= $line;
	}
	fclose($FD_ATTACH);
	
	header("Content-type: $get_MimeType; nmae=\"$get_File\"\n");
	header("Accept-Ranges: bytes\n");
	header("Content-Length: $get_Size\n");
	header("Content-Disposition: attachment; filename=\"$get_File\"\n\n");
	header("Pragma: public"); // for SSL 
	echo $buff;
	exit();
}

if ($get_Cmd=="ListAttach"){
	$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";
	($FD_BODYLIST = fopen("$bodylistfile","r"))	|| die("Error open body list file");
	$line = fgets($FD_BODYLIST,1024);
	while( ($line = fgets($FD_BODYLIST,1024)) && !feof($FD_BODYLIST)){
		list($filename,$type,$size,$disposition,$id) = split("\t",$line,5);
		$url = "mime.php?Cmd=Show&File=".rawurlencode($filename)."&MimeType=$type";
		$list .= "\t<td><a href='$url' target=Body>$filename</td>\n";
		
	}
	fclose($FD_BODYLIST);
}
?>
<HTML>
<HEAD>
<TITLE></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=gb2312">
<LINK REL="stylesheet" HREF="css/igenus.css" TYPE="TEXT/CSS">
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LEFTMARGIN="2" TOPMARGIN="2">
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0">
  <TR>
    <?php echo $list;?>
  </TR>
</TABLE>
</BODY>
</HTML>