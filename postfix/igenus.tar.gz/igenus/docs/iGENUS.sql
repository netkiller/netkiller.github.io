# $Id: iGENUS.sql,v 1.1 2003/03/06 03:00:45 wuqiong Exp $
#
# `address`
#

CREATE TABLE address (
  id int(11) unsigned NOT NULL auto_increment,
  pw_id int(5) NOT NULL default '0',
  name varchar(64) NOT NULL default '',
  email varchar(128) NOT NULL default '',
  UNIQUE KEY id (id),
  KEY pw_id (pw_id)
) TYPE=MyISAM PACK_KEYS=1;
# --------------------------------------------------------

#
# `admin`
#

CREATE TABLE admin (
  id tinyint(3) unsigned NOT NULL auto_increment,
  domain varchar(128) NOT NULL default '',
  quota smallint(5) unsigned NOT NULL default '0',
  total smallint(5) unsigned NOT NULL default '0',
  createtime timestamp(14) NOT NULL,
  login char(1) NOT NULL default '',
  cur_total smallint(5) NOT NULL default '0',
  cur_quota smallint(5) NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY domain (domain)
) TYPE=MyISAM PACK_KEYS=1;
# --------------------------------------------------------

#
# `vpopmail`
#

CREATE TABLE vpopmail (
  pw_id int(5) unsigned NOT NULL auto_increment,
  pw_name varchar(32) NOT NULL default '',
  pw_domain varchar(64) NOT NULL default '',
  pw_passwd varchar(40) NOT NULL default '',
  pw_uid int(11) default NULL,
  pw_gid int(11) default NULL,
  pw_gecos varchar(48) default NULL,
  pw_dir varchar(255) default NULL,
  pw_shell varchar(20) default NULL,
  PRIMARY KEY  (pw_id),
  KEY pw_name (pw_name,pw_domain)
) TYPE=MyISAM PACK_KEYS=1;

