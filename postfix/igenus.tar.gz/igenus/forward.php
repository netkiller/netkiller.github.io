<?php
/*-
 * iGENUS webmail 
 * 
 * Copyright (c) 1999-2001 by iGENUS network system Inc.
 * All rights reserved.
 * Author: Wu Qiong <wuqiong@sczg.com>
 *
 * $Id: forward.php,v 1.8 2003/02/13 00:24:50 wuqiong Exp $
 */
 
include "include/login_inc.php";
include "config/config_inc.php";
include "include/fun_inc.php";
include "language/$CFG_LANGUAGE"."_inc.php";
include "include/reply_inc.php";


//get
$get_Attach = trim($HTTP_GET_VARS['Attach']);
$get_Mailbox = trim($HTTP_GET_VARS['Mailbox']);
$get_Num = trim($HTTP_GET_VARS['Num']);
$get_Tpye = trim($HTTP_GET_VARS['Type']);

// ��� $get_Mailbox �����Ŀɿ��ԣ����������б��ļ���
if( !(list($listfile,$SMailbox) = GetMailboxFolder($get_Mailbox)) ) die("��Ч��Դ�������!");

//chdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/");
$listattachfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_attach";
$bodylistfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/list_body";

if(!is_dir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach")) mkdir("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach",0755);

DelAttach();

($FD_LIST_ATTACH = fopen($listattachfile,"w")) || die("Error open $listattachfile!");
($FD_BODYLIST = fopen("$bodylistfile","r"))	|| die("Error open body list file");
$line = fgets($FD_BODYLIST,1024);
list($FromName,$From,$Subject,$Date,$Size,$Content_Type,$Content_Transfer_Encoding) = split("\t",$line,7);

$Body = "$LANG_REPLY_HELLO1$FromName$LANG_REPLY_HELLO2\n\n\n";
$Body .= "----- Original Message -----\n";
$Body .= "From: $FromName <$From>\n";
$Body .= "Date: $Date\n";
$Body .= "Subject: $Subject\n\n";

if($get_Attach==1){
	$Body .= "Original Message is in attachment\n";
	$listfile = "$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$listfile";
	($FD_LIST = fopen($listfile,"r"))||die("Error open $Mailbox list file!");
	for($i=0;$i<$get_Num;$i++){
		$line = fgets($FD_LIST,1024);
	}
	fclose($FD_LIST);
	chop($line);
	list($n,$Key,$IsNew,$File,$FromName,$From,$Subject,$Date,$Size) = split("\t",$line,9);
	$Size = chop($Size);
	$mailfile = "$G_HOME$SMailbox/$IsNew/$File";
	if(!file_exists($mailfile)) $mailfile = "$G_HOME$SMailbox/cur/$File";
	fputs($FD_LIST_ATTACH,"message.eml\t$Size\n");
	
	// copy($mailfile,"$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach/message.eml");
	
	// ת�� unix->dos ��� outlook ���Ķ�����ʱ������
	($FD_MAILSOURCE = fopen($mailfile,"r"))|| dir("Error open mail source file!");
	($FD_MESSAGE = fopen("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach/message.eml","w"))|| dir("Error create message.eml file!");
	do {
		$line = fgets($FD_MAILSOURCE,1024);
		$line = rtrim($line)."\r\n";
		fputs($FD_MESSAGE,$line);
	}while(!feof($FD_MAILSOURCE));
	fclose($FD_MESSAGE);
	fclose($FD_MAILSOURCE);
} else {
	$Body = $Body . Format_body("> ");

	while(($line=fgets($FD_BODYLIST,1024)) && !feof($FD_BODYLIST)){
		$i++;
		list($filename,$type,$size,$disposition,$id,$location) = split("\t",$line,6);
		if (
			$filename!="unknown.txt" && $filename!="unknown.html"
			&& ($id == "" || $location=="" )
			){
			fputs($FD_LIST_ATTACH,"$filename\t$size\t$type\n");
			link("$CFG_TEMP/$G_DOMAIN/$G_USERNAME/$filename","$CFG_TEMP/$G_DOMAIN/$G_USERNAME/attach/$filename");
		}
	}
}

fclose($FD_LIST_ATTACH);
fclose($FD_BODYLIST);
$Subject = "Fw: ".$Subject;

include "adv.php";
include "include/send_form_inc.php";
?> 
