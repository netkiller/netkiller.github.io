<?

include "config/config.php";
include "lang/$lang.inc";


if($flag=="email")
	{
	echo "<p><span>".$menu['000']."</span>";
	echo "<blockquote>\n";
	echo "<a href=logon.php?flag=email&&action=add>=> ".$menu['001']."</a><br>\n";	
	echo "<a href=logon.php?flag=email&&action=ver>=> ".$menu['002']."</a><br>\n";
	echo "<a href=logon.php?flag=email&&action=rem>=> ".$menu['003']."</a><br>\n";
	echo "</blockquote>\n";
}
if($flag=="alias")
	{
	echo "<p><span>".$menu['004']."</span>";
	echo "<blockquote>\n";
	echo "<a href=logon.php?flag=alias&&action=add>=> ".$menu['005']."</a><br>\n";
	echo "<a href=logon.php?flag=alias&&action=ver>=> ".$menu['006']."</a><br>\n";
	echo "<a href=logon.php?flag=alias&&action=rem>=> ".$menu['007']."</a><br>\n";
	echo "</blockquote>\n";
}

?>
