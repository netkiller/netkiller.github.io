<?

session_start();

include "include/conn.inc";
include "include/header_noimage.inc";

if(empty($alias) or empty($alias_to))
	{
		echo "<br><center><a><b>Faltando Alias ou Redirecionamento</b></a><br><br>\n
		      <input type=submit value=Voltar onclick=history.back()></center>";

	}else{
		$query="SELECT address FROM alias WHERE address='".$alias."@".$_SESSION['domain']."'";
		$res=pg_query($query)or die("SELECT Err");
		$row=pg_fetch_row($res);
		if($alias==$row[0]) 
			{
				echo "<br><center><a><b>Alias j� existe</b></a><br><br>\n
				      <input type=submit value=Voltar onclick=history.back()></center>";
			}else{
				$alias=$alias."@".$_SESSION['domain'];
				$alias_to=$alias_to."@".$_SESSION['domain'];
				$create=date("Y-m-t H:i:s");
				$insert_alias="INSERT INTO alias(address,goto,domain,created) VALUES('$alias','$alias_to','".$_SESSION['domain']."','$create')";
				if(pg_query($insert_alias)or die("Erro ao adicinar dominio"))
					{
						include "include/header.inc";
						echo "<br><center><a><b>Alias criado com sucesso</b></a><br><br>\n
							      <input type=submit value=Voltar onclick=location=\"logon.php\"></center>";
					}else{
						echo "<br><center><a><b>Erro ao adicionar Alias</b></a><br><br>\n
	    					      <input type=submit value=Voltar onclick=history.back()></center>";
					}

			}
	}
?>
	
