<?

session_start();

$_SESSION['login']=$login;
$_SESSION['senha']=$senha;
$dom=explode("@",$login);
$_SESSION['domain']=$dom[1];

//echo $login.$senha;

if($destroy=="s"){

		session_destroy();
		header("location:index.php");

	}else{
		include "include/logon.inc";
	}

?>
