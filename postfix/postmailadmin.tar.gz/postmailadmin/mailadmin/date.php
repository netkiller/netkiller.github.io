<?

echo date("Y-m-t H:i:s");
?>
