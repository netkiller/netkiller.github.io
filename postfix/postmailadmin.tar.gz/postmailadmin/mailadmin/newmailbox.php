<?

include "include/conn.inc";
include "include/header_noimage.inc";

if(empty($login) or empty($senha) or empty($name)) 
	{
		echo "<br><center><a><b>Faltando Usu�rio, Senha ou nome</b></a><br><br>\n
		      <input type=submit value=Voltar onclick=history.back()></center>";

	}else{
		$query="SELECT username FROM mailbox WHERE username='".$login."@".$domain."'";
		$res=pg_query($query)or die("SELECT Err");
		$row=pg_fetch_row($res);
		if($domain==$row[0]) 
			{
				echo "<br><center><a><b>Usuario j� existe</b></a><br><br>\n
				      <input type=submit value=Voltar onclick=history.back()></center>";
			}else{
				$login=$login."@".$domain;
				$quota=($quota*1024)*1024;
				$pass=crypt($senha);
//				echo $num."<br>";
//				echo $login."<br>";
//				echo $pass."<br>";
				$create=date("Y-m-t H:i:s");
				$insert_mailbox="INSERT INTO mailbox (username,password,name,maildir,quota,domain,created) VALUES('$login','$pass','$name','$login/',$quota,'$domain','$create')";
				if(pg_query($insert_mailbox)or die("Erro ao adicinar dominio"))
					{
						include "include/header.inc";
						echo "<br><center><a><b>E-mail criado com sucesso</b></a><br><br>\n
							      <input type=submit value=Voltar onclick=location=\"logon.php\"></center>";
					}else{
						echo "<br><center><a><b>Erro ao adicionar E-mail</b></a><br><br>\n
	    					      <input type=submit value=Voltar onclick=history.back()></center>";
					}

			}
	}
?>
	
