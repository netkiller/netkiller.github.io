<?

include "include/conn.inc";
include "include/header_noimage.inc";

if(empty($login) or empty($senha) or empty($domain)) 
	{
		echo "<br><center><a><b>Faltando Usu�rio, Senha ou flag Admin</b></a><br><br>\n
		      <input type=submit value=Voltar onclick=history.back()></center>";

	}else{
		$query="SELECT domain FROM domain WHERE domain='$domain'";
		$res=pg_query($query)or die("SELECT Err");
		$row=pg_fetch_row($res);
		if($domain==$row[0]) 
			{
				echo "<br><center><a><b>Dominio j� existe</b></a><br><br>\n
				      <input type=submit value=Voltar onclick=history.back()></center>";
			}else{
				
				$pass=crypt($senha);
//				echo $num."<br>";
//				echo $login."<br>";
//				echo $pass."<br>";
				$create=date("Y-m-t H:i:s");
				$insert_domain="INSERT INTO domain (domain,description,created) VALUES('$domain','$domain','$create')";
				$insert_admin="INSERT INTO admin (username,password,created) VALUES('".$login."@".$domain."','$pass','$create')";
				$insert_domain_admins="INSERT INTO domain_admins (username,domains,created) VALUES('".$login."@".$domain."','$domain','$create')";
				if(pg_query($insert_domain)or die("Erro ao adicinar dominio"))
					{
						pg_query($insert_admin)or die("Erro ao adicionar admin"); 
						pg_query($insert_domain_admins)or die("Erro ao adicionar domain_admins");
							include "include/header.inc";
							echo "<br><center><a><b>Dominio criado com sucesso</b></a><br><br>\n
							      <input type=submit value=Voltar onclick=location=\"logon.php\"></center>";
					}else{
						echo "<br><center><a><b>Erro ao adicionar dominio</b></a><br><br>\n
	    					      <input type=submit value=Voltar onclick=history.back()></center>";
					}

			}
	}
?>
	
