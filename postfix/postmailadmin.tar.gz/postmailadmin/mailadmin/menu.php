<?
//width=260,height=180,scrollbars=no
if($flag=="domain")
	{
	echo "<blockquote>\n";
	echo "<a href=logon.php?flag=domain&&action=add>=> Adicionar Dom&iacute;nios</a><br>\n";
	echo "<a href=logon.php?flag=domain&&action=rem>=> Remover Dom&iacute;nios</a><br>\n";
	echo "<a href=logon.php?flag=domain&&action=list>=> Listar Dom&iacute;nios</a><br>\n";
//	echo "<a href=# onclick=window.open('system/adduser.php','','scrollbars=no')> => Editar Dom&iacute;nios</a><br>\n";
	echo "</blockquote>\n";
}
?>
