function check_form() {

        if(document.alias.email.value=="") {
                alert("Preencha o e-mail")
	}else{
		document.alias.submit()
        }
}

function check_alias_form() {

        if(document.alias.alias.value=="" ||
	   document.alias.alias_to.value=="") {
                alert("Preencha corretamente os campos")
	}else{
		document.alias.submit()
        }
}

function check_mailbox_form() {

        if(document.mailbox.login.value=="" ||
           document.mailbox.senha.value=="" ||
           document.mailbox.name.value=="") {
                alert("Preencha corretamente os campos")
        }else{
                document.mailbox.submit()
        }
}
