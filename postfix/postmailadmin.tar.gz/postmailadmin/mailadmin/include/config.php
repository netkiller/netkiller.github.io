<?

$temp=array(
	'default' => "style/default/",
	'LMBlack' => "style/default/",
	'LMWhite' => "style/default/"
//Adicione aqui novos estilos
	);

$style=$temp['default'];

?>
