<?

session_start();

include "include/conn.inc";
include "include/header.inc";


if(empty($remove)){

	$query="SELECT username,name,domain FROM mailbox WHERE username like '%$email%' and domain='".$_SESSION['domain']."'";
	
	$res=pg_query($query)or die("Err");
	
	echo "<form action=\"remmailbox.php\" method=\"POST\">\n";
	echo "<input type=hidden name=remove value=s><br>\n";
	echo "<table border=\"1\" bordercolor=\"green\" align=\"center\">\n";
	echo " <tr>";
	echo "  <td>";
	echo "   <table border=\"0\" width=\"500\">\n";

	while($row=pg_fetch_row($res)){
		
			$vlr=array(
			"EMAIL"  => $row[0],
			"NAME"  => $row[1],
			"DOMAIN"  => $row[2]
			);
			
				echo "   <tr>\n";
				echo "    <td>\n";
				echo "     <a><b>E-mail:</b> ".$vlr[EMAIL]."</a>"."<input type=hidden name=del_user value=".$vlr[EMAIL].">\n";
				echo "    </td>\n";
				echo "    </tr>\n";
				echo "    <tr>\n";
				echo "	    <td width=292><a><b>Nome: </b>".$vlr[NAME]."</a></td>\n";
				echo "	  </tr>\n";
				echo "	  <tr>\n";
				echo "	    <td colspan=2><a><b>Dom&iacute;nio: </b> $vlr[DOMAIN]</a></td>\n";
//				echo "	  </tr>\n";
//				echo "	  <tr>\n";
//				echo "	    <td><a><b>Admin:</b>". $vlr[ADMIN]."</a><input type=hidden name=admin value=".$vlr[ADMIN]."></td>\n";
				echo "    <td align=right>\n";
				echo "     <input type=submit value=Remover>\n";
				echo "     <input type=button value=Voltar onclick=location=\"logon.php?flag=email&&action=rem\"><br>\n";
				echo "    </td>\n";
				echo "   </tr>\n"; 
				echo "    <td  bgcolor=green align=center colspan=2>\n";
				echo "    </td>\n";
				echo "   </tr>\n";
	}

}elseif($remove=="s"){

	$query="DELETE FROM mailbox WHERE username='".$del_user."'";
	if(pg_query($query)) {
		echo "<a>E-mail excluido com sucesso excluido com sucesso";
	}else{
		echo "problema";
	}
}

	

echo "   </table>\n";
echo "  </td>\n";
echo " </tr>\n";
echo "</table>\n";
echo "</form>\n";

?>
