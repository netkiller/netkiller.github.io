<?

//Banco de Dados

$host="localhost";
$db="postfix";
$user="postfix";
$lang="pt_BR";


//STYLES

$temp=array(
        'default' => "styles/default/",
        'LMblue' => "styles/LMblue/",
        'LMWhite' => "styles/default/"
//Adicione aqui novos estilos
        );

//Altere o estilo aqui!

#$style=$temp['default'];
$style=$temp['LMblue'];

?>
