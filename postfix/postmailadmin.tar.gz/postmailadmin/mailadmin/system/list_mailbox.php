<?

session_start();

include "include/conn.inc";

$query="SELECT username,name,quota,active FROM mailbox WHERE domain='".$_SESSION['domain']."'";

echo "<td class=\"menu\" valign=top width=550>\n";
echo " <table border=\"1\" bordercolor=\"3366cc\" width=500 align=center>\n";
echo "  <tr>\n";
echo "   <td>\n";
echo "    <table border=0 width=400 align=\"center\">\n";
echo "<tr><td  height=\"30\" align=\"center\"><b> Lista de Usu�rios</b></td></tr>";

$res=pg_query($query);
while($row=pg_fetch_row($res)) {

if($row[3]=="t") {
	$active="Sim";
}else{
	$active="N�o";
}
//	$vlr=array(
//	"NOME" => $row[0],
//	"MAIL" => $row[0],
//	"CARGO" => $row[0]
//	);
	
	echo "<tr><td><b>Login:</b> ". $row[0]."</b></td></tr>";
	echo "<tr><td><a><b>Nome:</b> ". $row[1]."</a></td></tr>";
	echo "<tr><td><a><b>Quota:</b> ". $row[2]." bytes</a></td></tr>";
	echo "<tr><td><a><b>Conta ativa:</b> ". $active."</a></td></tr>";
	echo "<tr><td >&nbsp;</td></tr>";
}
echo "</table>";
echo "</td></tr>\n";
echo "</table>";
echo "</td>";
?>
