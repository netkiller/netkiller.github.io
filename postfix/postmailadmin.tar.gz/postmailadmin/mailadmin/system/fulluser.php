<?

include "include/conn.inc";

$query="select a.descr,b.nome,b.e_mail,b.cargo from users a, user_info b where a.codigo=b.codigo and b.codigo=$cod";
//$query="SELECT nome,e_mail,cargo FROM user_info where codigo=$cod";

echo "<td valign=top width=550>\n";
echo "<table border=1 bordercolor=green width=500 align=center>\n";
echo "<tr><td>\n";
echo "<table border=0 width=400>\n";

$res=pg_query($query);
$row=pg_fetch_row($res);

//	$vlr=array(
//	"NOME" => $row[0],
//	"MAIL" => $row[0],
//	"CARGO" => $row[0]
//	);
	
	echo "<tr><td><font size=2 color=#00ff00 face=verdana>Login:<b> ". $row[0]."</b></td></tr>";
	echo "<tr><td><a>Nome: ". $row[1]."</a></td></tr>";
	echo "<tr><td><a>E-mail: ". $row[2]."</a></td></tr>";
	echo "<tr><td><a>Cargo: ". $row[3]."</a></td></tr>";

echo "</table>";
echo "</td></tr>\n";
echo "</table>";
echo "</td>";
?>
