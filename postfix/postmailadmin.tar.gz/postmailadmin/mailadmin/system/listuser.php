<?

include "include/conn.inc";

$query="SELECT COUNT(*) FROM domain_admins";
$res=pg_query($query);
$row=pg_fetch_row($res);
$num=$row[0];

$query="SELECT domains,username FROM domain_admins";

echo "<td class=\"menu\" valign=top width=550>\n";
echo "<table border=1 bordercolor=green width=500 align=center>\n";
echo "<tr><td>\n";
echo "<table align=center border=0 width=490>\n";
echo "<tr><td colspan=2>\n";
echo "<b>Existem $num dom&iacute;nios registrados</b>\n";
echo "</td></tr>\n";
echo "<tr><td width=300 bgcolor=#005500><b>Dom&iacute;nio</b></td>\n";
echo "<td bgcolor=#005500 ><b>Admin</a></b></td></tr>\n";

$res=pg_query($query);
while($row=pg_fetch_row($res)) {

	$vlr=array(
	"DOMAIN" => $row[0],
	"DESCR" => $row[1],
	"CREATE" => $row[2]
	);

	echo "<tr><td><a class=\"list\" href=logon.php?flag=domain&&action=list&&info=all&&domain=$vlr[DOMAIN]>". $vlr[DOMAIN]."</a></td>\n";
	echo "<td><a class=\"list\">".$vlr[DESCR]."</a></td></tr>";
}
echo "</table>";
echo "</td></tr>\n";
echo "</table>";
echo "</td>";
?>
